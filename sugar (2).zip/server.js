var window = global ;

var start = function() {
  window.player = new this.Player(function(event) {
    if (event.name == "started") {
      // signal that the game is started
    }
    else if (event.name == "log") {
      // console.info(event.data) ;
    }
  }) ;
}

var resources = "var resources = {\"images\":[],\"assets\":[],\"maps\":{},\"sounds\":[],\"music\":[]};\nvar graphics = \"M1\";\n";
var graphics = "M1";

global.location = {
  pathname: "",
  hash: ""
}
global.navigator = {
  language: "en"
}

window.ms_libs = [] ;

server_code = `



// file: main.ms
function()
// =====================================================
// SUGAR & SPOOKS - Chapter 1: The Hollow Sweets   (v2)
// microStudio / MicroScript - PORTRAIT mobile game
// Options: Orientation = Portrait, Aspect = 9x16, Resolution = 360x640
// =====================================================

G = object end

C_INK = "#160a2e"
C_DEEP = "#2a1250"
C_PURPLE = "#4a2a8a"
C_PURPLE2 = "#7b4bd6"
C_ORANGE = "#ff8a1f"
C_ORANGE2 = "#c2560a"
C_PINK = "#ff5fa2"
C_MINT = "#5fe3a8"
C_CREAM = "#fff1d6"
C_GOLD = "#ffc94a"

// ================= basic drawing helpers (top-left coords, y DOWN) =================
rect = function(x,y,w,h,c)
  screen.fillRect(x+w/2-screen.width/2, screen.height/2-y-h/2, w, h, c)
end

rrect = function(x,y,w,h,r,c)
  screen.fillRoundRect(x+w/2-screen.width/2, screen.height/2-y-h/2, w, h, r, c)
end

oval = function(cx,cy,w,h,c)
  screen.fillRound(cx-screen.width/2, screen.height/2-cy, w, h, c)
end

ring = function(cx,cy,w,h,lw,c)
  screen.setLineWidth(lw)
  screen.drawRound(cx-screen.width/2, screen.height/2-cy, w, h, c)
end

seg = function(x1,y1,x2,y2,lw,c)
  screen.setLineWidth(lw)
  screen.drawLine(x1-screen.width/2, screen.height/2-y1, x2-screen.width/2, screen.height/2-y2, c)
end

tri = function(x1,y1,x2,y2,x3,y3,c)
  local hw = screen.width/2
  local hh = screen.height/2
  screen.setColor(c)
  screen.fillPolygon(x1-hw,hh-y1,x2-hw,hh-y2,x3-hw,hh-y3)
end

orr = function(x,y,w,h,r,c)
  local o = screen.width*0.007
  rrect(x-o,y-o,w+2*o,h+2*o,r+o,C_INK)
  rrect(x,y,w,h,r,c)
end

oov = function(cx,cy,w,h,c)
  local o = screen.width*0.007
  oval(cx,cy,w+2*o,h+2*o,C_INK)
  oval(cx,cy,w,h,c)
end

rgb = function(r,g,b)
  return "rgb("+floor(r)+","+floor(g)+","+floor(b)+")"
end

vgrad = function(y,h,r1,g1,b1,r2,g2,b2,n)
  local bh = h/n
  for gi=0 to n-1
    local k = gi/(n-1)
    rect(0,y+gi*bh,screen.width,bh+1,rgb(r1+(r2-r1)*k,g1+(g2-g1)*k,b1+(b2-b1)*k))
  end
end

txtC = function(t,cx,y,s,c)
  screen.drawText(t, cx-screen.width/2, screen.height/2-y, s, c)
end

txtL = function(t,x,y,s,c)
  screen.drawText(t, x+screen.textWidth(t,s)/2-screen.width/2, screen.height/2-y, s, c)
end

txtO = function(t,cx,y,s,c,oc)
  local o = s*0.07
  if o < 1 then o = 1 end
  txtC(t,cx,y+o*2.2,s,oc)
  txtC(t,cx-o,y,s,oc)
  txtC(t,cx+o,y,s,oc)
  txtC(t,cx,y-o,s,oc)
  txtC(t,cx,y+o,s,oc)
  txtC(t,cx-o,y-o,s,oc)
  txtC(t,cx+o,y-o,s,oc)
  txtC(t,cx-o,y+o,s,oc)
  txtC(t,cx+o,y+o,s,oc)
  txtC(t,cx,y,s,c)
end

wrapText = function(t,maxw,s)
  local out = []
  local paras = t.split("|")
  for pIdx=0 to paras.length-1
    local words = paras[pIdx].split(" ")
    local cur = ""
    for wIdx=0 to words.length-1
      local cand = words[wIdx]
      if cur != "" then cand = cur + " " + words[wIdx] end
      if cur != "" and screen.textWidth(cand,s) > maxw then
        out.push(cur)
        cur = words[wIdx]
      else
        cur = cand
      end
    end
    out.push(cur)
  end
  return out
end

twinkle = function(cx,cy,s)
  local a = s*(0.6+0.4*sin(G.t*0.12+cx))
  rect(cx-a,cy-a*0.16,a*2,a*0.32,"#fff3b0")
  rect(cx-a*0.16,cy-a,a*0.32,a*2,"#fff3b0")
  oval(cx,cy,a*0.6,a*0.6,"#ffe45e")
end

star5 = function(cx,cy,r,c)
  for ki=0 to 4
    local a = -PI/2 + ki*2*PI/5
    local a1 = a - PI/5
    local a2 = a + PI/5
    local a3 = a + 3*PI/5
    tri(cx+cos(a1)*r*0.45,cy+sin(a1)*r*0.45,cx+cos(a)*r,cy+sin(a)*r,cx+cos(a2)*r*0.45,cy+sin(a2)*r*0.45,c)
    tri(cx,cy,cx+cos(a2)*r*0.45,cy+sin(a2)*r*0.45,cx+cos(a3-PI/5*2)*r*0.45,cy+sin(a3-PI/5*2)*r*0.45,c)
  end
end

// ================= props & characters =================
candy = function(cx,cy,s,c1,c2)
  tri(cx-s*2.0,cy-s*0.9,cx-s*2.0,cy+s*0.9,cx-s*0.6,cy,c2)
  tri(cx+s*2.0,cy-s*0.9,cx+s*2.0,cy+s*0.9,cx+s*0.6,cy,c2)
  oov(cx,cy,s*1.9,s*1.5,c1)
  rect(cx-s*0.2,cy-s*0.7,s*0.4,s*1.4,"#ffffff")
  oval(cx-s*0.5,cy-s*0.3,s*0.4,s*0.3,"#ffffff")
end

bat = function(cx,cy,s)
  local f = sin(G.t*0.25+cx)*s*0.6
  tri(cx-s*0.2,cy,cx-s*2.2,cy-s*0.9+f,cx-s*1.2,cy+s*0.6,"#0d0620")
  tri(cx+s*0.2,cy,cx+s*2.2,cy-s*0.9+f,cx+s*1.2,cy+s*0.6,"#0d0620")
  oval(cx,cy,s*0.9,s*1.1,"#0d0620")
  tri(cx-s*0.4,cy-s*0.3,cx-s*0.25,cy-s*0.9,cx,cy-s*0.4,"#0d0620")
  tri(cx,cy-s*0.4,cx+s*0.25,cy-s*0.9,cx+s*0.4,cy-s*0.3,"#0d0620")
end

pumpkin = function(cx,cy,s)
  oov(cx-s*0.45,cy,s*1.0,s*1.5,"#ff7a14")
  oov(cx+s*0.45,cy,s*1.0,s*1.5,"#ff7a14")
  oov(cx,cy,s*1.1,s*1.6,"#ff9a2e")
  rect(cx-s*0.08,cy-s*1.05,s*0.16,s*0.35,"#3a8a4a")
  tri(cx-s*0.6,cy-s*0.05,cx-s*0.15,cy-s*0.05,cx-s*0.38,cy-s*0.5,"#ffe86a")
  tri(cx+s*0.15,cy-s*0.05,cx+s*0.6,cy-s*0.05,cx+s*0.38,cy-s*0.5,"#ffe86a")
  tri(cx-s*0.1,cy+s*0.05,cx+s*0.1,cy+s*0.05,cx,cy+s*0.2,"#ffe86a")
  rrect(cx-s*0.55,cy+s*0.3,s*1.1,s*0.25,s*0.1,"#ffe86a")
  rect(cx-s*0.15,cy+s*0.3,s*0.12,s*0.1,"#ff9a2e")
  rect(cx+s*0.15,cy+s*0.45,s*0.12,s*0.1,"#ff9a2e")
end

web = function(x,y,dx,dy,s)
  for ri=1 to 3
    for ai=0 to 3
      local a1 = ai*PI/6
      local a2 = (ai+1)*PI/6
      seg(x+dx*cos(a1)*s*ri/3,y+dy*sin(a1)*s*ri/3,x+dx*cos(a2)*s*ri/3,y+dy*sin(a2)*s*ri/3,1,"#d9c8ff")
    end
  end
  for ai2=0 to 3
    local a3 = ai2*PI/6
    seg(x,y,x+dx*cos(a3)*s,y+dy*sin(a3)*s,1,"#d9c8ff")
  end
end

jar = function(cx,baseY,w,h,col)
  orr(cx-w/2,baseY-h,w,h,w*0.28,"#cfe8ff")
  rrect(cx-w/2+w*0.08,baseY-h*0.7,w*0.84,h*0.66,w*0.2,col)
  oval(cx-w*0.15,baseY-h*0.5,w*0.14,w*0.14,"#ffffff")
  oval(cx+w*0.14,baseY-h*0.3,w*0.1,w*0.1,"#ffffff")
  orr(cx-w*0.38,baseY-h-h*0.14,w*0.76,h*0.2,w*0.08,C_GOLD)
end

bust = function(kind,cx,baseY,s)
  local skin = "#f6c9a4"
  local hair = "#3a2230"
  local cloth = "#4a6fa5"
  if kind == "Tilly" then
    hair = "#ff5fa2"
    cloth = "#ffcf4a"
  elsif kind == "You" then
    skin = "#e8b48a"
    hair = "#2a1a3a"
    cloth = "#3a3f7a"
  elsif kind == "Odette" then
    skin = "#f2d6e8"
    hair = "#9b5de5"
    cloth = "#3a1f6a"
  elsif kind == "Cass" then
    skin = "#d9a066"
    hair = "#2fb5a8"
    cloth = "#2a8fc4"
  elsif kind == "BarnabaseY" then
    hair = "#b8b8c8"
    cloth = "#6a4a2a"
  end
  orr(cx-27*s,baseY-32*s,54*s,38*s,16*s,cloth)
  if kind == "Tilly" then
    rrect(cx-15*s,baseY-28*s,30*s,32*s,8*s,"#4cc38a")
  elsif kind == "You" then
    tri(cx-14*s,baseY-34*s,cx,baseY-14*s,cx-4*s,baseY-34*s,"#22265a")
    tri(cx+14*s,baseY-34*s,cx,baseY-14*s,cx+4*s,baseY-34*s,"#22265a")
    rrect(cx-14*s,baseY-36*s,28*s,8*s,4*s,C_ORANGE)
  end
  rect(cx-6*s,baseY-40*s,12*s,12*s,skin)
  if kind == "Tilly" then
    oov(cx-25*s,baseY-78*s,19*s,19*s,hair)
    oov(cx+25*s,baseY-78*s,19*s,19*s,hair)
  end
  oov(cx,baseY-58*s,46*s,50*s,hair)
  oov(cx,baseY-54*s,38*s,42*s,skin)
  oval(cx,baseY-69*s,40*s,15*s,hair)
  oval(cx-12*s,baseY-64*s,16*s,10*s,hair)
  oval(cx-8*s,baseY-52*s,10*s,12*s,"#ffffff")
  oval(cx+8*s,baseY-52*s,10*s,12*s,"#ffffff")
  oval(cx-8*s,baseY-51*s,6*s,8*s,"#2a1a3a")
  oval(cx+8*s,baseY-51*s,6*s,8*s,"#2a1a3a")
  oval(cx-6.5*s,baseY-54*s,2.4*s,2.4*s,"#ffffff")
  oval(cx+9.5*s,baseY-54*s,2.4*s,2.4*s,"#ffffff")
  screen.setAlpha(0.5)
  oval(cx-14*s,baseY-44*s,8*s,5*s,"#ff8fb0")
  oval(cx+14*s,baseY-44*s,8*s,5*s,"#ff8fb0")
  screen.setAlpha(1)
  rrect(cx-3*s,baseY-42*s,6*s,2*s,1*s,"#8a2a3a")
  if kind == "BarnabaseY" then
    oval(cx,baseY-45*s,16*s,4*s,"#6a6a7a")
  end
  if kind == "You" then
    oov(cx,baseY-72*s,58*s,10*s,"#4a2a8a")
    orr(cx-17*s,baseY-94*s,34*s,24*s,8*s,"#4a2a8a")
    rect(cx-17*s,baseY-78*s,34*s,5*s,C_ORANGE)
  elsif kind == "Odette" then
    oov(cx,baseY-72*s,58*s,10*s,"#4a2a8a")
    tri(cx-20*s,baseY-72*s,cx+20*s,baseY-72*s,cx+6*s,baseY-122*s,"#4a2a8a")
    rect(cx-19*s,baseY-80*s,38*s,5*s,C_PINK)
  elsif kind == "Cass" then
    oov(cx,baseY-70*s,44*s,8*s,"#d62850")
    orr(cx-18*s,baseY-86*s,36*s,18*s,9*s,"#d62850")
  end
end

drawClue = function(id,cx,cy,s)
  if id == "voice" then
    orr(cx-s,cy-s*0.6,s*2,s*1.2,s*0.2,"#2b2745")
    oov(cx-s*0.45,cy,s*0.7,s*0.7,"#d8d0f0")
    oov(cx+s*0.45,cy,s*0.7,s*0.7,"#d8d0f0")
    oval(cx+s*0.8,cy-s*0.4,s*0.2,s*0.2,"#ff3b3b")
  elsif id == "receipts" then
    orr(cx-s*0.6,cy-s*0.9,s*1.2,s*1.8,s*0.1,C_CREAM)
    for ri=0 to 3
      rect(cx-s*0.4,cy-s*0.6+ri*s*0.35,s*0.8,s*0.1,"#b8a47a")
    end
  elsif id == "recipe" then
    orr(cx-s*0.95,cy-s*0.7,s*1.9,s*1.4,s*0.15,"#b03040")
    rrect(cx-s*0.8,cy-s*0.55,s*0.75,s*1.1,s*0.1,C_CREAM)
    rrect(cx+s*0.05,cy-s*0.55,s*0.75,s*1.1,s*0.1,C_CREAM)
    oval(cx,cy,s*0.35,s*0.35,C_GOLD)
  elsif id == "jars" then
    jar(cx,cy+s*0.9,s*1.1,s*1.6,"#d62850")
  elsif id == "calendar" then
    orr(cx-s*0.8,cy-s*0.9,s*1.6,s*1.8,s*0.12,C_CREAM)
    rect(cx-s*0.8,cy-s*0.9,s*1.6,s*0.45,"#d62e2e")
    txtC("31",cx,cy+s*0.2,s*0.9,"#d62e2e")
  else
    oov(cx,cy-s*0.1,s*1.8,s*1.4,"#ffffff")
    tri(cx-s*0.5,cy+s*0.4,cx-s*0.1,cy+s*0.4,cx-s*0.6,cy+s*0.9,"#ffffff")
    txtC("!",cx,cy-s*0.1,s*1.0,C_PINK)
  end
end

// ================= UI components =================
btn = function(label,x,y,w,h,col,lip,s)
  local hot = false
  if G.tap and G.tx >= x and G.tx <= x+w and G.ty >= y and G.ty <= y+h then hot = true end
  local u = screen.width/100
  rrect(x,y+1.2*u,w,h,h*0.35,C_INK)
  rrect(x,y+0.6*u,w,h,h*0.35,lip)
  rrect(x,y,w,h,h*0.35,col)
  screen.setAlpha(0.25)
  rrect(x+u,y+0.5*u,w-2*u,h*0.4,h*0.2,"#ffffff")
  screen.setAlpha(1)
  txtC(label,x+w/2,y+h/2+0.4*u,s,C_INK)
  txtC(label,x+w/2,y+h/2-0.2*u,s,"#fffaf0")
  if hot then G.tap = false end
  return hot
end

glyph = function(kind,cx,cy,r)
  if kind == "pause" then
    rrect(cx-r*0.45,cy-r*0.5,r*0.3,r*1.0,r*0.1,"#ffffff")
    rrect(cx+r*0.15,cy-r*0.5,r*0.3,r*1.0,r*0.1,"#ffffff")
  elsif kind == "back" then
    tri(cx-r*0.6,cy,cx+r*0.1,cy-r*0.55,cx+r*0.1,cy+r*0.55,"#ffffff")
    rect(cx,cy-r*0.2,r*0.55,r*0.4,"#ffffff")
  elsif kind == "bulb" then
    oval(cx,cy-r*0.12,r*0.9,r*0.9,C_GOLD)
    rrect(cx-r*0.22,cy+r*0.28,r*0.44,r*0.3,r*0.06,"#d0d0e0")
    seg(cx-r*0.7,cy-r*0.5,cx-r*0.9,cy-r*0.6,2,C_GOLD)
    seg(cx+r*0.7,cy-r*0.5,cx+r*0.9,cy-r*0.6,2,C_GOLD)
  elsif kind == "folder" then
    rrect(cx-r*0.6,cy-r*0.5,r*0.55,r*0.3,r*0.08,"#e0982a")
    rrect(cx-r*0.6,cy-r*0.35,r*1.2,r*0.85,r*0.1,"#f2b84a")
    rect(cx-r*0.3,cy-r*0.05,r*0.6,r*0.1,"#ffffff")
  elsif kind == "board" then
    rrect(cx-r*0.65,cy-r*0.55,r*1.3,r*1.1,r*0.1,"#b8864e")
    rect(cx-r*0.45,cy-r*0.35,r*0.4,r*0.35,"#fff1d6")
    rect(cx+r*0.1,cy,r*0.4,r*0.35,"#fff1d6")
    seg(cx-r*0.25,cy-r*0.3,cx+r*0.3,cy+r*0.1,2,"#ff3b3b")
  else
    seg(cx-r*0.4,cy-r*0.4,cx+r*0.4,cy+r*0.4,3,"#ffffff")
    seg(cx+r*0.4,cy-r*0.4,cx-r*0.4,cy+r*0.4,3,"#ffffff")
  end
end

ibtn = function(kind,cx,cy,r)
  local hot = false
  local dx = G.tx-cx
  local dy = G.ty-cy
  if G.tap and dx*dx+dy*dy <= r*r*1.3 then hot = true end
  oval(cx,cy+r*0.12,r*2.1,r*2.1,C_INK)
  oval(cx,cy,r*2,r*2,C_GOLD)
  oval(cx,cy,r*1.72,r*1.72,C_DEEP)
  glyph(kind,cx,cy,r*0.85)
  if hot then G.tap = false end
  return hot
end

say = function(t)
  G.toast = t
  G.toastT = 220
end

drawToast = function()
  if G.toastT <= 0 then return end
  local W = screen.width
  local H = screen.height
  local fs = W*0.04
  local lines = wrapText(G.toast, W*0.78, fs)
  local bh = lines.length*fs*1.4 + W*0.05
  local ty = H*0.77 - bh
  orr(W*0.05,ty,W*0.9,bh,W*0.04,C_DEEP)
  local k = 0
  for ln in lines
    txtC(ln,W/2,ty+W*0.03+fs*0.7+k*fs*1.4,fs,"#fff7e6")
    k += 1
  end
end

// ================= backgrounds =================
drawNight = function(menu)
  local W = screen.width
  local H = screen.height
  vgrad(0,H,22,10,62,98,48,150,28)
  for si=0 to 17
    twinkle((si*61.3)%W,(si*43.7)%(H*0.45),W*0.012)
  end
  local mx = W*0.5
  local my = H*0.2
  screen.setAlpha(0.10)
  oval(mx,my,W*0.8,W*0.8,"#ffd36b")
  screen.setAlpha(0.14)
  oval(mx,my,W*0.64,W*0.64,"#ffd36b")
  screen.setAlpha(1)
  oval(mx,my,W*0.46,W*0.46,"#ffd36b")
  oval(mx-W*0.03,my-W*0.03,W*0.38,W*0.38,"#ffe39a")
  screen.setAlpha(0.35)
  oval(mx+W*0.08,my+W*0.06,W*0.1,W*0.08,"#ffb02e")
  oval(mx-W*0.1,my-W*0.07,W*0.07,W*0.06,"#ffb02e")
  oval(mx+W*0.02,my-W*0.12,W*0.06,W*0.05,"#ffb02e")
  screen.setAlpha(1)
  for ci=0 to 2
    local cx = ((ci*140 + G.t*0.15) % (W+120)) - 60
    local cy = H*(0.1+ci*0.07)
    oval(cx,cy,W*0.22,H*0.035,"#6a38a8")
    oval(cx+W*0.07,cy-H*0.012,W*0.14,H*0.035,"#6a38a8")
  end
  oval(W*0.8,H*0.5,W*0.9,H*0.3,"#241047")
  local hx = W*0.8
  local hb = H*0.4
  rect(hx-W*0.08,hb-H*0.1,W*0.16,H*0.1,"#120824")
  tri(hx-W*0.1,hb-H*0.1,hx+W*0.1,hb-H*0.1,hx,hb-H*0.21,"#120824")
  rect(hx-W*0.19,hb-H*0.06,W*0.08,H*0.06,"#120824")
  tri(hx-W*0.2,hb-H*0.06,hx-W*0.1,hb-H*0.06,hx-W*0.15,hb-H*0.13,"#120824")
  rect(hx+W*0.1,hb-H*0.07,W*0.08,H*0.07,"#120824")
  tri(hx+W*0.09,hb-H*0.07,hx+W*0.19,hb-H*0.07,hx+W*0.14,hb-H*0.14,"#120824")
  local wc = "#ffd36b"
  if floor(G.t/40)%5 == 0 then wc = "#b8863a" end
  rect(hx-W*0.03,hb-H*0.085,W*0.025,H*0.03,wc)
  rect(hx+W*0.01,hb-H*0.085,W*0.025,H*0.03,"#ffd36b")
  rect(hx-W*0.16,hb-H*0.045,W*0.02,H*0.025,"#ffd36b")
  rect(hx+W*0.13,hb-H*0.055,W*0.02,H*0.025,wc)
  rrect(hx-W*0.02,hb-H*0.035,W*0.04,H*0.035,W*0.02,"#ffd36b")
  seg(W*0.02,H*0.42,W*0.1,H*0.2,6,"#0d0620")
  seg(W*0.07,H*0.3,W*0.2,H*0.24,4,"#0d0620")
  seg(W*0.08,H*0.27,W*0.03,H*0.17,4,"#0d0620")
  seg(W*0.05,H*0.35,W*0.17,H*0.33,4,"#0d0620")
  for bi=0 to 2
    local bx = ((W*0.2*bi + G.t*(0.5+bi*0.2)) % (W+60)) - 30
    bat(bx,H*(0.12+bi*0.07)+sin(G.t*0.05+bi)*H*0.02,W*0.025)
  end
  oval(W*0.4,H*1.0,W*1.8,H*0.8,"#120828")
  if menu then
    pumpkin(W*0.14,H*0.66,W*0.1)
    pumpkin(W*0.86,H*0.68,W*0.1)
    web(0,0,1,1,W*0.3)
    web(W,0,-1,1,W*0.3)
  end
end

drawShopArt = function()
  local W = screen.width
  local H = screen.height
  vgrad(0,H*0.6,108,66,168,74,42,128,16)
  screen.setAlpha(0.1)
  for si=0 to 4
    rect(si*W/5,0,W/10,H*0.6,"#ffffff")
  end
  screen.setAlpha(1)
  rect(0,H*0.5,W,H*0.1,"#3a2060")
  rect(0,H*0.5,W,H*0.008,C_GOLD)
  vgrad(H*0.6,H*0.4,150,100,64,96,58,44,12)
  for pi2=0 to 6
    rect(0,H*0.6+pi2*H*0.06,W,1.5,"#5a3624")
  end
  rect(0,H*0.6,W,H*0.012,"#2a1648")
  screen.setAlpha(0.12)
  tri(W*0.4,H*0.6,W*0.6,H*0.6,W*0.78,H*0.9,"#fff3b0")
  tri(W*0.4,H*0.6,W*0.78,H*0.9,W*0.3,H*0.9,"#fff3b0")
  screen.setAlpha(1)
  orr(W*0.37,H*0.15,W*0.26,H*0.17,W*0.03,"#d9a05a")
  rrect(W*0.385,H*0.165,W*0.23,H*0.14,W*0.02,"#1a1244")
  oval(W*0.5,H*0.225,W*0.1,W*0.1,"#ffe58a")
  rect(W*0.495,H*0.165,W*0.01,H*0.14,"#d9a05a")
  rect(W*0.385,H*0.232,W*0.23,H*0.008,"#d9a05a")
  twinkle(W*0.42,H*0.19,W*0.012)
  twinkle(W*0.58,H*0.27,W*0.01)
  orr(W*0.32,H*0.145,W*0.06,H*0.19,W*0.02,C_PINK)
  orr(W*0.62,H*0.145,W*0.06,H*0.19,W*0.02,C_PINK)
  orr(W*0.065,H*0.19,W*0.17,H*0.15,W*0.015,C_CREAM)
  rect(W*0.065,H*0.19,W*0.17,H*0.04,"#d62e2e")
  oval(W*0.1,H*0.19,W*0.015,W*0.015,"#888")
  oval(W*0.2,H*0.19,W*0.015,W*0.015,"#888")
  ring(W*0.15,H*0.285,W*0.1,W*0.1,3,"#d62e2e")
  txtC("31",W*0.15,H*0.285,W*0.06,"#d62e2e")
  orr(W*0.74,H*0.335,W*0.24,H*0.014,W*0.005,"#a0683a")
  orr(W*0.77,H*0.265,W*0.18,H*0.07,W*0.015,"#2b2745")
  oov(W*0.82,H*0.3,W*0.045,W*0.045,"#d8d0f0")
  oov(W*0.89,H*0.3,W*0.045,W*0.045,"#d8d0f0")
  local led = "#661a1a"
  if floor(G.t/20)%2 == 0 then led = "#ff3b3b" end
  oval(W*0.93,H*0.278,W*0.014,W*0.014,led)
  orr(W*0.22,H*0.45,W*0.56,H*0.016,W*0.005,"#a0683a")
  tri(W*0.26,H*0.466,W*0.3,H*0.466,W*0.26,H*0.49,"#8a5a30")
  tri(W*0.7,H*0.466,W*0.74,H*0.466,W*0.74,H*0.49,"#8a5a30")
  jar(W*0.36,H*0.45,W*0.12,H*0.075,"#d62850")
  jar(W*0.5,H*0.45,W*0.12,H*0.075,"#3a3a52")
  jar(W*0.64,H*0.45,W*0.12,H*0.075,"#e8c020")
  orr(W*0.74,H*0.42,W*0.2,H*0.19,W*0.02,"#6b3b1f")
  rrect(W*0.76,H*0.44,W*0.07,H*0.15,W*0.01,"#58300f")
  rrect(W*0.85,H*0.44,W*0.07,H*0.15,W*0.01,"#58300f")
  oval(W*0.835,H*0.52,W*0.02,W*0.02,C_GOLD)
  txtC("CELLAR",W*0.84,H*0.405,W*0.03,C_GOLD)
  if not hasD("p2") then
    orr(W*0.805,H*0.5,W*0.06,H*0.04,W*0.01,C_GOLD)
    ring(W*0.835,H*0.495,W*0.04,W*0.04,3,C_GOLD)
  else
    screen.setAlpha(0.5)
    rect(W*0.78,H*0.59,W*0.12,H*0.01,"#ffd36b")
    screen.setAlpha(1)
  end
  orr(W*0.03,H*0.585,W*0.5,H*0.125,W*0.02,"#a0522d")
  rrect(W*0.05,H*0.615,W*0.2,H*0.07,W*0.01,"#8a4020")
  rrect(W*0.28,H*0.615,W*0.2,H*0.07,W*0.01,"#8a4020")
  orr(W*0.02,H*0.555,W*0.52,H*0.03,W*0.01,"#f3d9a0")
  for ci2=0 to 9
    local sc = C_PINK
    if ci2%2 == 1 then sc = C_CREAM end
    rect(W*0.03+ci2*W*0.05,H*0.585,W*0.025,H*0.012,sc)
  end
  orr(W*0.38,H*0.5,W*0.12,H*0.055,W*0.01,"#5a6a8a")
  rect(W*0.395,H*0.508,W*0.09,H*0.015,"#9fe8c0")
  orr(W*0.16,H*0.515,W*0.1,H*0.038,W*0.005,"#fff8e6")
  rect(W*0.18,H*0.525,W*0.06,2,"#b8a47a")
  tri(W*0.23,H*0.515,W*0.27,H*0.5,W*0.26,H*0.53,"#fff8e6")
  rect(W*0.725,H*0.665,W*0.03,H*0.1,"#6b3b1f")
  oov(W*0.74,H*0.66,W*0.2,H*0.03,"#a0683a")
  orr(W*0.645,H*0.595,W*0.19,H*0.06,W*0.012,"#b03040")
  rrect(W*0.655,H*0.6,W*0.08,H*0.05,W*0.008,C_CREAM)
  rrect(W*0.745,H*0.6,W*0.08,H*0.05,W*0.008,C_CREAM)
  oval(W*0.74,H*0.625,W*0.03,W*0.03,C_GOLD)
  oval(W*0.5,H*0.8,W*0.56,H*0.08,"#7a3a8a")
  ring(W*0.5,H*0.8,W*0.44,H*0.06,3,C_PINK)
  pumpkin(W*0.1,H*0.83,W*0.09)
  web(0,H*0.1,1,1,W*0.2)
  web(W,H*0.1,-1,1,W*0.2)
end

drawCellarArt = function()
  local W = screen.width
  local H = screen.height
  vgrad(0,H,32,26,70,14,12,38,16)
  for cr=0 to 11
    for cc=0 to 6
      local off = (cr%2)*W/12
      local col = "#241f46"
      if (cr+cc)%3 == 0 then col = "#2c2656" end
      rect(cc*W/6-off,cr*H*0.055,W/6-2,H*0.055-2,col)
    end
  end
  vgrad(H*0.6,H*0.4,62,54,100,26,22,56,10)
  for fi=0 to 5
    rect(0,H*0.6+fi*H*0.07,W,2,"#17132f")
  end
  for ti=0 to 1
    local tx = W*0.08
    if ti == 1 then tx = W*0.92 end
    screen.setAlpha(0.15)
    oval(tx,H*0.33,W*0.35,W*0.35,"#ff9a2e")
    screen.setAlpha(1)
    rect(tx-W*0.015,H*0.34,W*0.03,H*0.07,"#4a3a2a")
    local fl = sin(G.t*0.3+ti*2)*W*0.008
    oov(tx,H*0.325,W*0.05+fl,W*0.07,"#ff8a1f")
    oval(tx,H*0.33,W*0.025,W*0.04,"#ffe45e")
  end
  orr(W*0.2,H*0.28,W*0.4,H*0.012,W*0.004,"#6b4a2a")
  jar(W*0.28,H*0.28,W*0.07,H*0.04,"#5fe3a8")
  jar(W*0.4,H*0.28,W*0.07,H*0.04,"#c86bff")
  jar(W*0.52,H*0.28,W*0.07,H*0.04,C_PINK)
  orr(W*0.24,H*0.64,W*0.22,H*0.11,W*0.01,"#6b4a2a")
  txtC("BLACK",W*0.35,H*0.675,W*0.035,C_GOLD)
  txtC("SUGAR",W*0.35,H*0.71,W*0.035,C_GOLD)
  orr(W*0.07,H*0.44,W*0.17,H*0.025,W*0.005,"#7a5a3a")
  orr(W*0.09,H*0.465,W*0.13,H*0.13,W*0.004,"#7a5a3a")
  tri(W*0.075,H*0.44,W*0.15,H*0.44,W*0.075,H*0.38,"#c8a050")
  txtC("UP",W*0.15,H*0.41,W*0.04,"#fff1d6")
  seg(W*0.15,H*0.37,W*0.15,H*0.34,4,C_GOLD)
  tri(W*0.12,H*0.35,W*0.18,H*0.35,W*0.15,H*0.31,C_GOLD)
  if hasD("p3") then
    orr(W*0.28,H*0.69,W*0.44,H*0.16,W*0.03,"#2a1a10")
    oval(W*0.5,H*0.77,W*0.38,H*0.1,"#0a0518")
    screen.setAlpha(0.35)
    oval(W*0.5,H*0.77,W*0.44,H*0.14,C_PINK)
    screen.setAlpha(1)
    oov(W*0.5,H*0.79,W*0.28,H*0.07,"#1b1730")
    oval(W*0.5,H*0.765,W*0.24,H*0.035,C_PINK)
    oval(W*0.46+sin(G.t*0.1)*W*0.02,H*0.755,W*0.025,W*0.025,"#ffe0f0")
  else
    orr(W*0.28,H*0.69,W*0.44,H*0.16,W*0.03,"#6b4a2a")
    rect(W*0.28,H*0.74,W*0.44,H*0.012,"#2b2b3a")
    rect(W*0.28,H*0.8,W*0.44,H*0.012,"#2b2b3a")
    for tt=0 to 4
      oov(W*0.34+tt*W*0.08,H*0.77,W*0.04,W*0.06,C_CREAM)
    end
    orr(W*0.45,H*0.7,W*0.1,H*0.035,W*0.008,"#2b2b3a")
  end
  web(0,0,1,1,W*0.25)
  web(W,0,-1,1,W*0.25)
end

// ================= story data =================
EV = []
EV.push(["voice","Answering Machine","Voicemail - 3 new messages.|#1 (Oct 26, 9:12 PM) Supplier: 'Marrow, your black sugar crates are in the back. Don't open them after dark.'|#2 (Oct 26, 11:52 PM) A voice memo Odette left for herself: 'If anyone asks, I took the Last Batch down. Don't follow. The sugar remembers every name.'|#3: static, then a child giggling."])
EV.push(["receipts","Order Receipts","Three signed slips from Oct 26, the times smudged with syrup:|- Barnaby Gloam (landlord): 'Rent talk. I came right after the delivery girl.'|- Tilly Penn (florist): 'Flowers for the window. Not the first one in.'|- Cass Hollis (delivery): black sugar, 12 crates.|In the margin, Odette wrote: 'Last Batch tonight. Lock up after the last one leaves.'"])
EV.push(["recipe","Recipe Book","Odette's recipe book. The last page is torn: THE LAST BATCH.|Grave-dust sherbet, three crates of black sugar, one tooth of rock candy. Never stir clockwise on the 31st.|Scribbled below: 'The jars guard the stair. Lemon never greets the door. Licorice walks before Cherry. Cherry never sleeps in the middle.'"])
EV.push(["jars","Candy Jars","Three jars bolted to the shelf, each on a little turntable: Cherry, Licorice and Lemon. The candies inside look like tiny teeth, and they are warm.|Behind the shelf, a keyhole-shaped gap breathes cold air. A label reads: ORDER MATTERS."])
EV.push(["calendar","Wall Calendar","A stack of old calendars is pinned to the wall. Every October 31st is circled in red wax, year after year.|The taped flyer: MAPLE HOLLOW HARVEST FESTIVAL - 31 OCT - 6 PM. Someone scrawled the word AGAIN across it, three times."])
EV.push(["confess","Tilly's Confession","Odette brews the Last Batch every Oct 26 to pay the Hollow, something hungry under Maple Hollow. The pact began in 1926.|If the sweet isn't paid, the Hollow takes someone instead, and the town forgets they ever lived.|'The festival feels like it's happening again and again,' Tilly says. 'And nobody but Odette remembers why.'"])

LINKS = [["voice","receipts","p1"],["recipe","jars","p2"],["calendar","confess","d3"]]

SHOPSPOTS = [["calendar",0.15,0.265,0.1],["voice",0.86,0.30,0.09],["jars",0.5,0.415,0.19],["receipts",0.22,0.535,0.1],["recipe",0.73,0.625,0.1],["door",0.84,0.51,0.1]]
CELLARSPOTS = [["trap",0.5,0.77,0.22],["stairs",0.14,0.5,0.1]]
SHOPCANDY = [[0.07,0.47],[0.93,0.73],[0.42,0.7]]
CELLARCANDY = [[0.1,0.82],[0.9,0.62]]

L = function(d,who,t)
  d.push([who,t])
end

introLines = function()
  local d = []
  L(d,"","Maple Hollow. October 29th, 11:58 PM. Your phone buzzes on the nightstand.")
  L(d,"Tilly","Detective? It's Tilly Penn, the florist on Sugar Lane. Odette from Hollow Sweets hasn't been seen in three days.")
  L(d,"Tilly","The door's open, the lights are on... and the candy jars in the window are humming. Like a lullaby.")
  L(d,"You","Jars don't hum, Miss Penn.")
  L(d,"Tilly","These ones do. Bring your grandmother's Sugar Lens. Please. I'll wait outside. I can't go back in.")
  L(d,"","In your coat pocket, the Sugar Lens begins to glow. It only does that near real magic.")
  return d
end

shopLines = function()
  local d = []
  L(d,"","Hollow Sweets. A bell chimes over the door. Peppermint, smoke, and something older underneath.")
  L(d,"You","Okay, Odette. Show me what the sugar saw.")
  L(d,"","TIP: Your Sugar Lens makes clues twinkle. Tap the sparkles to inspect them.")
  L(d,"","TIP: Tap hidden candies for treats. Trade 3 candies for a hint any time with the bulb.")
  L(d,"","TIP: Two clues that fit together? Pin them on the Case Board.")
  return d
end

tillyLines = function()
  local d = []
  L(d,"You","Cass, then Barnaby, then you, Tilly. You were the last one through that door.")
  L(d,"Tilly","...I didn't lie. I just didn't say. I saw Odette lock the cellar and whisper goodbye to the jars.")
  L(d,"Tilly","Every October 26th she cooks the Last Batch. In 1926, her great-grandmother made a pact with the Hollow: one sweet every Halloween.")
  L(d,"You","And if the sweet isn't paid?")
  L(d,"Tilly","It takes a name instead. A person. And the whole town forgets they ever existed.")
  L(d,"Tilly","The jars guard the cellar. I never learned their order. I never wanted to.")
  L(d,"","New clue: Tilly's Confession.")
  return d
end

p2Lines = function()
  local d = []
  L(d,"","The jars spin: Licorice, Lemon, Cherry. Click. Click. Click.")
  L(d,"","Behind the shelf a latch gives way. The cellar door breathes out cold peppermint.")
  return d
end

d3Lines = function()
  local d = []
  L(d,"You","Every year circled. Every flyer says AGAIN. And nobody remembers who gets taken.")
  L(d,"You","Odette isn't missing. She went down there on purpose, to pay the Hollow before the festival.")
  L(d,"","THEORY LOGGED: Odette entered the cellar willingly.")
  return d
end

cellarLines = function()
  local d = []
  L(d,"","Stone steps. Torchlight. The smell of burnt sugar. In the floor, a trapdoor sealed by a lock of rock-candy teeth.")
  L(d,"You","Someone scratched numbers into the lock plate. That's Odette's handwriting.")
  return d
end

p3Lines = function()
  local d = []
  L(d,"","Click. Click. Click. The teeth drop one by one and the trapdoor swings open.")
  L(d,"","Below: a copper cauldron the size of a bathtub, bubbling with glowing sugar. The Last Batch.")
  L(d,"You","'Never stir clockwise on the 31st.' Is it the 31st somewhere down there?")
  return d
end

endLines = function()
  local d = []
  L(d,"","The sugar swirls into a single wrapped candy and floats into your hand. A tag is tied to it.")
  L(d,"","No Odette. Only a note pinned to the pot.")
  L(d,"Odette's Note","To whoever listened to the sugar:|I paid the Hollow with the Last Batch. It took the sweet, and it let me stay. I'm tucked in its pantry, safe, sleepy and sticky.")
  L(d,"Odette's Note","But the Hollow is never full for long. It has already chosen this year's name: a trick-or-treater on Maple Street. It's on the wrapper.")
  L(d,"You","The same night, over and over. This isn't the end of the case. It's the beginning.")
  return d
end

// ================= state / flow =================
saveGame = function()
  storage.set("ss_candy", G.candy)
  storage.set("ss_star1", G.star1)
end

loadGame = function()
  local c = storage.get("ss_candy")
  local s = storage.get("ss_star1")
  if c == null then c = 0 end
  if s == null then s = 0 end
  G.candy = c
  G.star1 = s
end

newRun = function()
  G.found = []
  G.ded = []
  G.sel = []
  G.cdy = []
  G.earned = 0
  G.hints = 0
  G.room = "shop"
  G.cellarSeen = false
  G.es = 0
  G.slots = []
  G.entry = ""
  G.lastDed = ""
  G.stirAcc = 0
  G.stirOn = false
  G.stirA = 0
  G.stirBad = 0
end

go = function(s)
  G.scene = s
  G.fade = 1
end

hasD = function(id)
  return G.ded.contains(id)
end

addCandy = function(n)
  G.candy += n
  G.earned += n
  G.pop = 24
  saveGame()
  say("+" + n + " candy!")
end

startDialogue = function(lines,bg,cb)
  G.dlg = lines
  G.di = 0
  G.ch = 0
  G.bg = bg
  G.onDone = cb
  go("dialogue")
end

toRoom = function()
  go("room")
end

cbShop = function()
  G.room = "shop"
  go("room")
end

cbIntro = function()
  startDialogue(shopLines(),"shop",cbShop)
end

cbP1 = function()
  if not G.found.contains("confess") then G.found.push("confess") end
  toRoom()
end

cbP2 = function()
  say("The cellar door is unlocked!")
  toRoom()
end

cbBoard = function()
  go("board")
end

cbCellar = function()
  G.room = "cellar"
  go("room")
end

cbP3 = function()
  G.room = "cellar"
  go("room")
end

cbEnd = function()
  G.es = 0
  go("end")
end

startChapter1 = function()
  newRun()
  startDialogue(introLines(),"night",cbIntro)
end

objective = function()
  local n = 0
  local base = ["voice","receipts","recipe","jars","calendar"]
  for bI=0 to 4
    if G.found.contains(base[bI]) then n += 1 end
  end
  if n < 5 then return ["Inspect the twinkling clues (" + n + "/5)","Tap anything that sparkles. The Sugar Lens shows you where."] end
  if not hasD("p1") then return ["Something doesn't add up. Pin two clues.","Case Board: try the Answering Machine + Order Receipts."] end
  if not hasD("p2") then return ["Open the cellar. What guards the door?","Case Board: try the Recipe Book + Candy Jars."] end
  if not hasD("d3") then return ["Why does the town forget? Pin it down.","Case Board: try the Wall Calendar + Tilly's Confession."] end
  if not hasD("p3") then return ["Go down to the cellar. Crack the tooth lock.","Tap the trapdoor in the cellar."] end
  return ["Wake the Last Batch.","Tap the open trapdoor. The recipe said: never stir CLOCKWISE on the 31st. So swipe the other way!"]
end

buyHint = function(txt)
  if G.candy < 3 then
    say("Not enough candies! Collect more (need 3).")
    return
  end
  G.candy -= 3
  G.hints += 1
  saveGame()
  say("Hint (-3 candy): " + txt)
end

getEv = function(id)
  for ev in EV
    if ev[0] == id then return ev end
  end
  return EV[0]
end

openEvidence = function(id)
  if not G.found.contains(id) then
    G.found.push(id)
    addCandy(3)
  end
  G.insp = id
  G.prev = G.scene
  go("inspect")
end

enterCellar = function()
  G.room = "cellar"
  if not G.cellarSeen then
    G.cellarSeen = true
    startDialogue(cellarLines(),"cellar",cbCellar)
  else
    go("room")
  end
end

startPuzzle = function(id)
  G.pz = id
  G.slots = []
  G.entry = ""
  G.stirAcc = 0
  G.stirOn = false
  G.stirBad = 0
  if id == "p1" then
    G.pzTitle = "WHO CAME LAST?"
    G.pzClue = "From the receipts:|- Barnaby came right after Cass.|- Tilly did not arrive first.|Tap the faces in order of arrival, 1st to 3rd."
    G.pzItems = [["Cass","face","#2a8fc4"],["Barnaby","face","#d98a1d"],["Tilly","face","#d6407f"]]
    G.pzAns = ["Cass","Barnaby","Tilly"]
    G.pzHint = "Cass and Barnaby come as a pair, Cass first. Where can Tilly fit?"
  elsif id == "p2" then
    G.pzTitle = "THE JAR LOCK"
    G.pzClue = "From the recipe page:|- Lemon never greets the door (never 1st).|- Licorice stands left of Cherry.|- Cherry never sleeps in the middle.|Tap jars to line them up, left to right."
    G.pzItems = [["Lemon","jar","#e8c020"],["Cherry","jar","#d62850"],["Licorice","jar","#3a3a52"]]
    G.pzAns = ["Licorice","Lemon","Cherry"]
    G.pzHint = "Cherry can't be 2nd, and Licorice is left of Cherry. Try Cherry last."
  elsif id == "p3" then
    G.pzTitle = "THE TOOTH LOCK"
    G.pzClue = "Scratched into the lock plate:|2 - 4 - 8 - 16 - ?|Enter the next tooth number."
    G.pzSol = "32"
    G.pzHint = "Each number doubles the last one."
  else
    G.pzTitle = "THE LAST BATCH"
    G.pzClue = "The pot is awake and hungry.|Swipe in circles around the cauldron to stir it. Think about Odette's rule for the 31st..."
    G.pzHint = "Never stir CLOCKWISE on the 31st. Swipe counter-clockwise!"
  end
  go("puzzle")
end

solved = function(id)
  G.ded.push(id)
  addCandy(5)
  if id == "p1" then
    G.lastDed = "The last visitor was Tilly. Odette recorded her memo after the last visitor left, so Tilly knows more than she said."
    startDialogue(tillyLines(),G.room,cbP1)
  elsif id == "p2" then
    G.lastDed = "The jars are a lock. The recipe gave the order: Licorice, Lemon, Cherry."
    startDialogue(p2Lines(),G.room,cbP2)
  elsif id == "p3" then
    startDialogue(p3Lines(),"cellar",cbP3)
  else
    startDialogue(endLines(),"cellar",cbEnd)
  end
end

checkOrder = function()
  if G.slots.length < 3 then
    say("Fill all three spots first.")
    return
  end
  local ok = true
  for cI=0 to 2
    if G.slots[cI] != G.pzAns[cI] then ok = false end
  end
  if ok then
    solved(G.pz)
  else
    say("That doesn't fit the clues. Try again!")
    G.slots = []
  end
end

pressKey = function(k)
  if k == "C" then
    G.entry = ""
  elsif k == "OK" then
    if G.entry == G.pzSol then
      solved("p3")
    else
      say("The teeth stay shut.")
      G.entry = ""
    end
  elsif G.entry.length < 3 then
    G.entry = G.entry + k
  end
end

tryLink = function()
  local a = G.sel[0]
  local b = G.sel[1]
  G.sel = []
  for lk in LINKS
    if (lk[0] == a and lk[1] == b) or (lk[0] == b and lk[1] == a) then
      if hasD(lk[2]) then
        say("You already solved that link.")
      elsif lk[2] == "d3" then
        G.ded.push("d3")
        G.lastDed = "Odette went down the cellar on purpose, paying the Hollow so it wouldn't take someone. The festival repeats because of it."
        addCandy(5)
        startDialogue(d3Lines(),"night",cbBoard)
      else
        startPuzzle(lk[2])
      end
      return
    end
  end
  say("Those clues don't connect. Yet.")
end

// ================= HUD =================
drawCandyPill = function()
  local W = screen.width
  local H = screen.height
  orr(W*0.6,H*0.03,W*0.34,H*0.05,H*0.025,C_DEEP)
  candy(W*0.66,H*0.055,W*0.022,C_PINK,C_ORANGE)
  txtL("" + G.candy,W*0.72,H*0.055,W*0.055*(1+G.pop*0.02),C_CREAM)
end

drawHUD = function()
  local W = screen.width
  local H = screen.height
  if ibtn("pause",W*0.09,H*0.055,W*0.055) then go("pause") end
  drawCandyPill()
  local ob = objective()
  local fs = W*0.036
  local lines = wrapText(ob[0],W*0.8,fs)
  local ph = lines.length*fs*1.35 + W*0.04
  screen.setAlpha(0.9)
  orr(W*0.04,H*0.1,W*0.92,ph,W*0.03,C_DEEP)
  screen.setAlpha(1)
  star5(W*0.085,H*0.1+ph/2,W*0.025,C_GOLD)
  local k = 0
  for ln in lines
    txtL(ln,W*0.13,H*0.1+W*0.022+fs*0.6+k*fs*1.35,fs,"#fff7e6")
    k += 1
  end
end

drawTray = function()
  local W = screen.width
  local H = screen.height
  orr(W*0.06,H*0.875,W*0.88,H*0.115,W*0.05,C_DEEP)
  if ibtn("folder",W*0.24,H*0.915,W*0.07) then
    G.prev = "room"
    go("evlist")
  end
  if ibtn("board",W*0.5,H*0.915,W*0.07) then go("board") end
  if ibtn("bulb",W*0.76,H*0.915,W*0.07) then buyHint(objective()[1]) end
  txtC("Evidence",W*0.24,H*0.962,W*0.03,C_CREAM)
  txtC("Case Board",W*0.5,H*0.962,W*0.03,C_CREAM)
  txtC("Hint -3",W*0.76,H*0.962,W*0.03,C_CREAM)
end

// ================= scenes =================
drawMenu = function()
  local W = screen.width
  local H = screen.height
  drawNight(true)
  orr(W*0.04,H*0.03,W*0.34,H*0.05,H*0.025,C_DEEP)
  candy(W*0.1,H*0.055,W*0.022,C_PINK,C_ORANGE)
  txtL("" + G.candy,W*0.16,H*0.055,W*0.055,C_CREAM)
  txtO("SUGAR &",W*0.5,H*0.43,W*0.12,"#ffb347",C_INK)
  txtO("SPOOKS",W*0.5,H*0.52,W*0.2,C_ORANGE,"#2a1260")
  orr(W*0.15,H*0.6,W*0.7,H*0.045,H*0.02,C_PINK)
  txtC("CASE 01: THE HOLLOW SWEETS",W*0.5,H*0.6225,W*0.034,"#ffffff")
  if btn("PLAY",W*0.2,H*0.72,W*0.6,H*0.09,C_ORANGE,C_ORANGE2,W*0.09) then go("chapters") end
  if btn("HOW TO PLAY",W*0.3,H*0.84,W*0.4,H*0.06,C_PURPLE2,C_PURPLE,W*0.04) then go("howto") end
  txtC("v2 - a spooky-sweet mystery",W*0.5,H*0.95,W*0.03,"#9a8ac0")
end

drawChapters = function()
  c3Chapters()
end

drawHowTo = function()
  local W = screen.width
  local H = screen.height
  drawNight(false)
  screen.setAlpha(0.6)
  rect(0,0,W,H,"#0d0620")
  screen.setAlpha(1)
  txtO("HOW TO PLAY",W*0.5,H*0.12,W*0.08,"#ffb347",C_INK)
  local rows = ["Tap sparkles to inspect clues.","Tap hidden candies. Trade 3 for a hint.","Pin two clues on the Case Board.","Think outside the box. Magic follows recipes!"]
  for ri=0 to 3
    local y = H*0.2 + ri*H*0.15
    orr(W*0.06,y,W*0.88,H*0.12,W*0.03,C_DEEP)
    oov(W*0.17,y+H*0.06,W*0.12,W*0.12,C_PURPLE2)
    if ri == 0 then twinkle(W*0.17,y+H*0.06,W*0.04) end
    if ri == 1 then candy(W*0.17,y+H*0.06,W*0.02,C_PINK,C_ORANGE) end
    if ri == 2 then glyph("board",W*0.17,y+H*0.06,W*0.05) end
    if ri == 3 then glyph("bulb",W*0.17,y+H*0.06,W*0.05) end
    local lines = wrapText(rows[ri],W*0.6,W*0.04)
    local k = 0
    for ln in lines
      txtL(ln,W*0.28,y+H*0.05+k*W*0.05,W*0.04,C_CREAM)
      k += 1
    end
  end
  if btn("GOT IT!",W*0.25,H*0.84,W*0.5,H*0.08,C_ORANGE,C_ORANGE2,W*0.06) then go("menu") end
end

drawPause = function()
  local W = screen.width
  local H = screen.height
  drawNight(false)
  screen.setAlpha(0.6)
  rect(0,0,W,H,"#0d0620")
  screen.setAlpha(1)
  orr(W*0.12,H*0.28,W*0.76,H*0.4,W*0.05,C_DEEP)
  txtO("PAUSED",W*0.5,H*0.35,W*0.09,"#ffb347",C_INK)
  if btn("RESUME",W*0.2,H*0.45,W*0.6,H*0.08,C_MINT,"#2a9a6a",W*0.06) then go("room") end
  if btn("MAIN MENU",W*0.2,H*0.56,W*0.6,H*0.08,C_PURPLE2,C_PURPLE,W*0.06) then go("menu") end
end

drawDialogue = function()
  local W = screen.width
  local H = screen.height
  if G.bg == "shop" then
    drawShopArt()
  elsif G.bg == "cellar" then
    drawCellarArt()
  else
    drawNight(false)
  end
  if G.bg != "night" then
    screen.setAlpha(0.4)
    rect(0,0,W,H,"#0d0620")
    screen.setAlpha(1)
  end
  local d = G.dlg[G.di]
  local who = d[0]
  local full = d[1]
  local panelY = H*0.62
  local s = W*0.0072
  if who == "You" then
    bust("You",W*0.3,panelY+s*8,s)
  elsif who == "Tilly" then
    bust("Tilly",W*0.7,panelY+s*8,s)
  elsif who == "Odette's Note" then
    screen.setAlpha(0.45)
    bust("Odette",W*0.5,panelY+s*8,s)
    screen.setAlpha(1)
  end
  if G.bg == "night" and who == "Tilly" and G.di < 6 then
    orr(W*0.18,H*0.095,W*0.64,H*0.05,W*0.03,C_DEEP)
    oval(W*0.24,H*0.12,W*0.03,W*0.03,"#5fe36a")
    txtC("Tilly Penn - calling...",W*0.54,H*0.12,W*0.036,C_CREAM)
  end
  orr(W*0.04,panelY,W*0.92,H*0.3,W*0.04,"#24104a")
  if who != "" then
    local tabc = C_ORANGE
    if who == "Tilly" then tabc = "#d6407f" end
    if who == "You" then tabc = "#2a8fc4" end
    if who == "Odette's Note" then tabc = C_PURPLE2 end
    orr(W*0.08,panelY-H*0.03,W*0.38,H*0.055,W*0.025,tabc)
    txtC(who,W*0.27,panelY-H*0.0025,W*0.04,"#ffffff")
  end
  local tc = "#d8c8ff"
  if who != "" then tc = "#fff7e6" end
  local fs = W*0.047
  local lines = wrapText(full,W*0.82,fs)
  local remaining = floor(G.ch)
  local k = 0
  for ln in lines
    if remaining > 0 then
      local n = remaining
      if n > ln.length then n = ln.length end
      txtL(ln.substring(0,n),W*0.09,panelY+H*0.04+k*fs*1.4,fs,tc)
      remaining = remaining - ln.length - 1
    end
    k += 1
  end
  if G.ch >= full.length then
    local bob = sin(G.t*0.15)*W*0.008
    tri(W*0.86,panelY+H*0.255+bob,W*0.92,panelY+H*0.255+bob,W*0.89,panelY+H*0.275+bob,C_ORANGE)
  end
  if G.tap then
    G.tap = false
    if G.ch < full.length then
      G.ch = full.length
    else
      G.di += 1
      G.ch = 0
      if G.di >= G.dlg.length then
        local cb = G.onDone
        G.onDone = null
        if cb != null then
          cb()
        else
          toRoom()
        end
      end
    end
  end
end

drawRoom = function()
  local W = screen.width
  local H = screen.height
  local spots = SHOPSPOTS
  local cands = SHOPCANDY
  local cpre = "s"
  if G.room == "shop" then
    drawShopArt()
  else
    drawCellarArt()
    spots = CELLARSPOTS
    cands = CELLARCANDY
    cpre = "c"
  end
  for sp in spots
    local show = false
    if sp[0] == "door" then
      if hasD("p2") and not G.cellarSeen then show = true end
    elsif sp[0] == "trap" then
      if hasD("d3") and not hasD("p4") then show = true end
    elsif sp[0] == "stairs" then
      show = false
    else
      if not G.found.contains(sp[0]) then show = true end
    end
    if show then
      twinkle(sp[1]*W+W*0.04,sp[2]*H-H*0.03,W*0.035)
    end
  end
  local ci = 0
  for cd in cands
    local id = cpre + ci
    if not G.cdy.contains(id) then
      candy(cd[0]*W,cd[1]*H+sin(G.t*0.08+ci)*W*0.006,W*0.016,CANDY_COLS(ci),C_ORANGE)
      twinkle(cd[0]*W+W*0.025,cd[1]*H-W*0.02,W*0.012)
    end
    ci += 1
  end
  drawHUD()
  drawTray()
  if G.tap then
    local ci2 = 0
    for cd2 in cands
      local id2 = cpre + ci2
      local dx = G.tx - cd2[0]*W
      local dy = G.ty - cd2[1]*H
      if G.tap and not G.cdy.contains(id2) and dx*dx+dy*dy < W*W*0.0035 then
        G.tap = false
        G.cdy.push(id2)
        addCandy(1)
      end
      ci2 += 1
    end
  end
  if G.tap then
    for sp2 in spots
      local ddx = G.tx - sp2[1]*W
      local ddy = G.ty - sp2[2]*H
      local r = sp2[3]*W
      if G.tap and ddx*ddx+ddy*ddy < r*r then
        G.tap = false
        roomTap(sp2[0])
      end
    end
  end
end

CANDY_COLS = function(i)
  local cols = [C_PINK,"#c86bff","#5fe3a8","#ffe45e"]
  return cols[i%4]
end

roomTap = function(id)
  if id == "door" then
    if hasD("p2") then
      enterCellar()
    else
      say("Locked tight. The jars behind it are humming...")
    end
  elsif id == "stairs" then
    G.room = "shop"
    go("room")
  elsif id == "trap" then
    if not hasD("d3") then
      say("The teeth hum. You still don't understand why Odette came down here.")
    elsif not hasD("p3") then
      startPuzzle("p3")
    elsif not hasD("p4") then
      startPuzzle("p4")
    else
      say("The pot is quiet now.")
    end
  else
    openEvidence(id)
  end
end

drawInspect = function()
  local W = screen.width
  local H = screen.height
  drawNight(false)
  screen.setAlpha(0.6)
  rect(0,0,W,H,"#0d0620")
  screen.setAlpha(1)
  local e = getEv(G.insp)
  orr(W*0.06,H*0.14,W*0.88,H*0.7,W*0.04,"#f3e2b8")
  orr(W*0.06,H*0.14,W*0.88,H*0.13,W*0.04,C_ORANGE)
  oov(W*0.17,H*0.205,W*0.14,W*0.14,C_DEEP)
  drawClue(G.insp,W*0.17,H*0.205,W*0.045)
  txtL(e[1],W*0.3,H*0.205,W*0.052,"#ffffff")
  local fs = W*0.04
  local lines = wrapText(e[2],W*0.78,fs)
  local k = 0
  for ln in lines
    txtL(ln,W*0.11,H*0.3+k*fs*1.4,fs,"#3b2a1a")
    k += 1
  end
  if btn("GOT IT",W*0.3,H*0.88,W*0.4,H*0.075,C_ORANGE,C_ORANGE2,W*0.055) then
    go(G.prev)
  end
end

drawEvList = function()
  local W = screen.width
  local H = screen.height
  drawNight(false)
  screen.setAlpha(0.55)
  rect(0,0,W,H,"#0d0620")
  screen.setAlpha(1)
  txtO("EVIDENCE",W*0.5,H*0.08,W*0.08,"#ffb347",C_INK)
  local k = 0
  for ev in EV
    local cx = W*0.27
    if k%2 == 1 then cx = W*0.73 end
    local cy = H*0.2 + floor(k/2)*H*0.22
    local has = G.found.contains(ev[0])
    local col = "#3a2a60"
    if has then col = C_CREAM end
    orr(cx-W*0.19,cy-H*0.09,W*0.38,H*0.19,W*0.03,col)
    if has then
      drawClue(ev[0],cx,cy-H*0.02,W*0.05)
      txtC(ev[1],cx,cy+H*0.07,W*0.034,C_INK)
      if G.tap and G.tx > cx-W*0.19 and G.tx < cx+W*0.19 and G.ty > cy-H*0.09 and G.ty < cy+H*0.1 then
        G.tap = false
        G.insp = ev[0]
        G.prev = "evlist"
        go("inspect")
      end
    else
      txtC("?",cx,cy-H*0.01,W*0.14,"#6a5a90")
    end
    k += 1
  end
  if btn("BACK",W*0.3,H*0.88,W*0.4,H*0.075,C_PURPLE2,C_PURPLE,W*0.055) then go("room") end
end

drawBoard = function()
  local W = screen.width
  local H = screen.height
  rect(0,0,W,H,"#9a6a3a")
  for di=0 to 40
    oval((di*83.7)%W,(di*47.3)%H,W*0.012,W*0.012,"#8a5a2e")
  end
  orr(W*0.02,H*0.02,W*0.96,H*0.96,W*0.03,"#b8864e")
  screen.setAlpha(0.35)
  rect(W*0.03,H*0.03,W*0.94,H*0.94,"#8a5a2e")
  screen.setAlpha(1)
  txtO("CASE BOARD",W*0.5,H*0.07,W*0.08,"#fff1d6","#5a3016")
  txtC("Pick two clues that go together",W*0.5,H*0.115,W*0.038,"#fff1d6")
  local pos = [[0.27,0.25],[0.73,0.25],[0.27,0.45],[0.73,0.45],[0.27,0.65],[0.73,0.65]]
  local ids = ["voice","receipts","recipe","jars","calendar","confess"]
  for lk in LINKS
    if hasD(lk[2]) then
      local ia = ids.indexOf(lk[0])
      local ib = ids.indexOf(lk[1])
      seg(pos[ia][0]*W,pos[ia][1]*H,pos[ib][0]*W,pos[ib][1]*H,4,"#e0182c")
    end
  end
  local k = 0
  for id in ids
    local cx = pos[k][0]*W
    local cy = pos[k][1]*H
    local has = G.found.contains(id)
    if has then
      if G.sel.contains(id) then
        orr(cx-W*0.2,cy-H*0.085,W*0.4,H*0.17,W*0.03,C_GOLD)
      end
      orr(cx-W*0.18,cy-H*0.075,W*0.36,H*0.15,W*0.025,C_CREAM)
      drawClue(id,cx,cy-H*0.012,W*0.045)
      txtC(getEv(id)[1],cx,cy+H*0.055,W*0.03,C_INK)
      oov(cx,cy-H*0.075,W*0.03,W*0.03,"#e0182c")
      if G.tap and G.tx > cx-W*0.18 and G.tx < cx+W*0.18 and G.ty > cy-H*0.075 and G.ty < cy+H*0.075 then
        G.tap = false
        if G.sel.contains(id) then
          G.sel.remove(G.sel.indexOf(id))
        else
          G.sel.push(id)
        end
        if G.sel.length >= 2 then tryLink() end
      end
    else
      orr(cx-W*0.18,cy-H*0.075,W*0.36,H*0.15,W*0.025,"#7a5a3a")
      txtC("?",cx,cy,W*0.1,"#a88a60")
    end
    k += 1
  end
  if G.lastDed != "" then
    orr(W*0.06,H*0.77,W*0.88,H*0.1,W*0.025,"#fff7e6")
    local lines = wrapText("Theory: " + G.lastDed,W*0.82,W*0.032)
    local j = 0
    for ln in lines
      if j < 3 then txtL(ln,W*0.09,H*0.79+j*W*0.04,W*0.032,"#3b2a1a") end
      j += 1
    end
  end
  if btn("BACK",W*0.3,H*0.9,W*0.4,H*0.07,C_ORANGE,C_ORANGE2,W*0.055) then
    G.sel = []
    go("room")
  end
end

drawToken = function(item,cx,cy,w,h)
  local W = screen.width
  if item[1] == "face" then
    orr(cx-w/2,cy-h/2,w,h,W*0.03,C_CREAM)
    bust(item[0],cx,cy+h*0.18,w/110)
    txtC(item[0],cx,cy+h*0.38,W*0.036,C_INK)
  else
    orr(cx-w/2,cy-h/2,w,h,W*0.03,"#3a2070")
    jar(cx,cy+h*0.22,w*0.5,h*0.55,item[2])
    txtC(item[0],cx,cy+h*0.38,W*0.036,C_CREAM)
  end
end

drawOrder = function()
  local W = screen.width
  local H = screen.height
  local cw = W*0.27
  local ch = H*0.17
  local gap = W*0.035
  local x0 = (W-(3*cw+2*gap))/2
  for si=0 to 2
    local sx = x0 + si*(cw+gap)
    local sy = H*0.38
    orr(sx,sy,cw,ch,W*0.03,"#3a1f6e")
    txtC("" + (si+1),sx+cw/2,sy+ch/2,W*0.14,"#5a3a98")
    if si < G.slots.length then
      for it in G.pzItems
        if it[0] == G.slots[si] then drawToken(it,sx+cw/2,sy+ch/2,cw,ch) end
      end
      if G.tap and G.tx > sx and G.tx < sx+cw and G.ty > sy and G.ty < sy+ch then
        G.tap = false
        G.slots.remove(si)
      end
    end
  end
  txtC("Tap a spot to take it back",W*0.5,H*0.58,W*0.033,"#9a8ac0")
  local ti = 0
  for it2 in G.pzItems
    local tx = x0 + ti*(cw+gap)
    local ty = H*0.62
    if G.slots.contains(it2[0]) then
      orr(tx,ty,cw,ch,W*0.03,"#2a1856")
    else
      drawToken(it2,tx+cw/2,ty+ch/2,cw,ch)
      if G.tap and G.tx > tx and G.tx < tx+cw and G.ty > ty and G.ty < ty+ch then
        G.tap = false
        G.slots.push(it2[0])
      end
    end
    ti += 1
  end
  if btn("RESET",W*0.06,H*0.85,W*0.3,H*0.075,C_PURPLE2,C_PURPLE,W*0.045) then G.slots = [] end
  if btn("CHECK",W*0.42,H*0.85,W*0.52,H*0.075,C_MINT,"#2a9a6a",W*0.06) then checkOrder() end
end

drawKeypad = function()
  local W = screen.width
  local H = screen.height
  orr(W*0.3,H*0.37,W*0.4,H*0.07,W*0.03,"#0e0724")
  txtC(G.entry + "_",W*0.5,H*0.405,W*0.07,"#5fe3a8")
  local keys = ["1","2","3","4","5","6","7","8","9","C","0","OK"]
  for ki=0 to 11
    local kx = W*0.14 + (ki%3)*W*0.27
    local ky = H*0.47 + floor(ki/3)*H*0.095
    local col = C_PURPLE2
    local lip = C_PURPLE
    if keys[ki] == "OK" then
      col = C_MINT
      lip = "#2a9a6a"
    end
    if btn(keys[ki],kx,ky,W*0.24,H*0.08,col,lip,W*0.055) then pressKey(keys[ki]) end
  end
end

drawStir = function()
  local W = screen.width
  local H = screen.height
  local goo = C_MINT
  if G.stirBad > 0 then goo = "#ff3b3b" end
  screen.setAlpha(0.25)
  oval(W*0.5,H*0.62,W*0.7,W*0.25,"#ff8a1f")
  screen.setAlpha(1)
  for fi=0 to 2
    local fx = W*0.32 + fi*W*0.18
    oov(fx,H*0.67+sin(G.t*0.3+fi)*H*0.005,W*0.07,H*0.07,"#ff8a1f")
    oval(fx,H*0.675,W*0.035,H*0.04,"#ffe45e")
  end
  oov(W*0.5,H*0.54,W*0.62,H*0.25,"#1b1730")
  oov(W*0.5,H*0.43,W*0.66,H*0.08,"#2d2748")
  oval(W*0.5,H*0.43,W*0.58,H*0.06,goo)
  local k = 0
  for bi=0 to 3
    local a = G.stirAcc*1.5 + bi*PI/2
    oval(W*0.5+cos(a)*W*0.2,H*0.43-sin(a)*H*0.02,W*0.035,W*0.035,"#ffffff")
  end
  local p = G.stirAcc/(4*PI)
  if p < 0 then p = 0 end
  if p > 1 then p = 1 end
  orr(W*0.2,H*0.76,W*0.6,H*0.035,H*0.015,"#2a1856")
  if p > 0.02 then rrect(W*0.2,H*0.76,W*0.6*p,H*0.035,H*0.015,C_PINK) end
  txtC("Stir power",W*0.5,H*0.81,W*0.035,C_CREAM)
  local sx = W*0.62
  local sy = H*0.4
  if G.stirOn then
    sx = touch.x + W/2
    sy = H/2 - touch.y
  end
  seg(sx,sy,sx+W*0.14,sy-H*0.12,W*0.02,"#c98a4a")
  oov(sx,sy,W*0.05,W*0.05,"#e0a860")
end

drawPuzzle = function()
  local W = screen.width
  local H = screen.height
  if G.pz == "p3" then
    drawCellarArt()
  else
    vgrad(0,H,40,20,90,20,10,50,16)
    for si=0 to 9
      twinkle((si*57.1)%W,(si*91.3)%H,W*0.01)
    end
  end
  screen.setAlpha(0.45)
  rect(0,0,W,H,"#0d0620")
  screen.setAlpha(1)
  if ibtn("back",W*0.09,H*0.055,W*0.055) then go("room") end
  if ibtn("bulb",W*0.91,H*0.055,W*0.055) then buyHint(G.pzHint) end
  txtO(G.pzTitle,W*0.5,H*0.055,W*0.055,"#ffb347",C_INK)
  orr(W*0.06,H*0.115,W*0.88,H*0.235,W*0.03,"#f3e2b8")
  oov(W*0.5,H*0.115,W*0.035,W*0.035,"#e0182c")
  local fs = W*0.04
  local lines = wrapText(G.pzClue,W*0.8,fs)
  local k = 0
  for ln in lines
    txtL(ln,W*0.1,H*0.15+k*fs*1.4,fs,"#3b2a1a")
    k += 1
  end
  if G.pz == "p3" then
    drawKeypad()
  elsif G.pz == "p4" then
    drawStir()
  else
    drawOrder()
  end
end

drawEnd = function()
  local W = screen.width
  local H = screen.height
  drawNight(false)
  screen.setAlpha(0.5)
  rect(0,0,W,H,"#0d0620")
  screen.setAlpha(1)
  if G.es == 0 then
    local stars = 1
    if G.hints <= 2 then stars = 2 end
    if G.hints == 0 then stars = 3 end
    txtO("CASE",W*0.5,H*0.14,W*0.12,"#ffb347",C_INK)
    txtO("CLOSED",W*0.5,H*0.24,W*0.16,C_ORANGE,"#2a1260")
    for si=0 to 2
      local sc = "#4a3a6a"
      if si < stars then sc = C_GOLD end
      star5(W*0.25+si*W*0.25,H*0.4,W*0.09,sc)
    end
    orr(W*0.1,H*0.52,W*0.8,H*0.26,W*0.04,C_DEEP)
    txtC("Candies earned: " + G.earned,W*0.5,H*0.58,W*0.05,C_CREAM)
    txtC("Hints used: " + G.hints,W*0.5,H*0.65,W*0.05,C_CREAM)
    txtC("Total candies: " + G.candy,W*0.5,H*0.72,W*0.05,C_GOLD)
    if stars > G.star1 then
      G.star1 = stars
      saveGame()
    end
    if btn("CONTINUE",W*0.2,H*0.86,W*0.6,H*0.08,C_ORANGE,C_ORANGE2,W*0.06) then G.es = 1 end
  elsif G.es == 1 then
    txtO("ONE LAST CLUE",W*0.5,H*0.12,W*0.08,"#ffb347",C_INK)
    candy(W*0.5,H*0.36,W*0.08,C_PINK,C_ORANGE)
    orr(W*0.18,H*0.5,W*0.64,H*0.2,W*0.03,C_CREAM)
    txtC("WREN ALDER",W*0.5,H*0.57,W*0.07,"#8a2a1a")
    txtC("10:47 PM - MAPLE STREET",W*0.5,H*0.64,W*0.036,"#3b2a1a")
    local lines = wrapText("The Hollow has chosen a new name. And the festival flyer still says AGAIN.",W*0.8,W*0.045)
    local k = 0
    for ln in lines
      txtC(ln,W*0.5,H*0.77+k*W*0.06,W*0.045,"#fff7e6")
      k += 1
    end
    if btn("NEXT",W*0.3,H*0.9,W*0.4,H*0.07,C_ORANGE,C_ORANGE2,W*0.055) then G.es = 2 end
  else
    txtO("TO BE CONTINUED...",W*0.5,H*0.12,W*0.07,"#ffb347",C_INK)
    orr(W*0.08,H*0.22,W*0.84,H*0.2,W*0.04,"#2b1a45")
    txtC("CHAPTER 2",W*0.5,H*0.27,W*0.04,"#9a8ac0")
    txtC("The Vanishing Trick-or-Treater",W*0.5,H*0.34,W*0.038,C_CREAM)
    orr(W*0.08,H*0.47,W*0.84,H*0.2,W*0.04,"#2b1a45")
    txtC("CHAPTER 3",W*0.5,H*0.52,W*0.04,"#9a8ac0")
    txtC("The Cursed Halloween Festival",W*0.5,H*0.59,W*0.038,C_CREAM)
    if btn("MAIN MENU",W*0.2,H*0.8,W*0.6,H*0.08,C_ORANGE,C_ORANGE2,W*0.06) then go("menu") end
  end
end

// ================= microStudio entry points =================
init = function()
  G.t = 0
  G.tap = false
  G.tx = 0
  G.ty = 0
  G.fade = 0
  G.pop = 0
  G.toast = ""
  G.toastT = 0
  G.candy = 0
  G.star1 = 0
  loadGame()
  newRun()
  G.scene = "menu"
end

update = function()
  if C4.on then
    c4Update()
    return
  end
  if C2.on then
    c2Update()
    return
  end
  if C3.on then
    c3Update()
    return
  end
  if G.scene == "menu" or G.scene == "chapters" then musicTick("menu") end
  G.t += 1
  G.tap = touch.press
  if G.tap then
    G.tx = touch.x + screen.width/2
    G.ty = screen.height/2 - touch.y
  end
  if G.toastT > 0 then G.toastT -= 1 end
  if G.pop > 0 then G.pop -= 1 end
  if G.stirBad > 0 then G.stirBad -= 1 end
  if G.scene == "dialogue" then G.ch += 1.6 end
  if G.scene == "puzzle" and G.pz == "p4" then
    if touch.touching then
      local dx = touch.x
      local dy = touch.y - screen.height*0.0
      local cy = screen.height/2 - screen.height*0.5
      dy = touch.y - cy
      local d = sqrt(dx*dx+dy*dy)
      if d > screen.width*0.08 and d < screen.width*0.55 then
        local a = atan2(dy,dx)
        if G.stirOn then
          local da = a - G.stirA
          if da > PI then da = da - 2*PI end
          if da < -PI then da = da + 2*PI end
          G.stirAcc += da
          G.stirA = a
        else
          G.stirOn = true
          G.stirA = a
        end
      end
    else
      G.stirOn = false
    end
    if G.stirAcc < -PI*1.2 then
      G.stirAcc = 0
      G.stirBad = 50
      say("Clockwise! The pot hisses and the sugar curdles.")
    end
    if G.stirAcc >= 4*PI then
      G.stirAcc = 0
      solved("p4")
    end
  end
end

draw = function()
  if C4.on then
    c4Draw()
    return
  end
  if C2.on then
    c2Draw()
    return
  end
  if C3.on then
    c3Draw()
    return
  end
  screen.clear("#140a24")
  local sc = G.scene
  if sc == "menu" then
    drawMenu()
  elsif sc == "chapters" then
    drawChapters()
  elsif sc == "howto" then
    drawHowTo()
  elsif sc == "dialogue" then
    drawDialogue()
  elsif sc == "room" then
    drawRoom()
  elsif sc == "inspect" then
    drawInspect()
  elsif sc == "evlist" then
    drawEvList()
  elsif sc == "board" then
    drawBoard()
  elsif sc == "puzzle" then
    drawPuzzle()
  elsif sc == "pause" then
    drawPause()
  elsif sc == "end" then
    drawEnd()
  end
  drawToast()
  if G.fade > 0 then
    screen.setAlpha(G.fade)
    rect(0,0,screen.width,screen.height,"#0d0620")
    screen.setAlpha(1)
    G.fade -= 0.07
  end
end
end()



// file: source.ms
function()
// =====================================================
// SUGAR & SPOOKS - Chapter 2: DEAD AIR   (separate source file: "chapter2")
// Reuses your helpers from main (rect, rrect, oval, ring, seg, tri, orr, oov,
// txtC, txtL, wrapText, twinkle, bust, btn, ibtn, say, drawToast, candy, C_ colors)
// World = 720 x 640. Drag = pan. +/- = zoom. Hold finger in dark rooms = flashlight.
// =====================================================

C2 = object end
C2.on = false
C2.mute = false

c2RK = [["Investigator",0,"Starter kit"],["Detective",100,"HINT bulb unlocked"],["Sergeant",250,"Flashlight drains 33% slower + wider beam"],["Inspector",450,"Clues sparkle in the dark"],["Chief",700,"Gold badge + every perk"]]
c2ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
c2PLAIN = "THE BOX OPENS WITH THE TIME ON THE DEAD WATCH"
c2SHIFT = 7
c2Cands = [["Mara Quill",5,"right"],["Ollie Fenn",7,"left"],["Dex Harlow",7,"right"],["Pip Lorne",9,"top"]]


// ---------- scale layer: everything below is designed on a 360x640 canvas ----------
// C2.k = real screen width / 360, so it fits ANY resolution
vrect = function(x,y,w,h,c)
  local k = C2.k
  rect(x*k,y*k,w*k,h*k,c)
end
vrrect = function(x,y,w,h,r,c)
  local k = C2.k
  rrect(x*k,y*k,w*k,h*k,r*k,c)
end
voval = function(cx,cy,w,h,c)
  local k = C2.k
  oval(cx*k,cy*k,w*k,h*k,c)
end
vring = function(cx,cy,w,h,lw,c)
  local k = C2.k
  ring(cx*k,cy*k,w*k,h*k,lw*k,c)
end
vseg = function(x1,y1,x2,y2,lw,c)
  local k = C2.k
  seg(x1*k,y1*k,x2*k,y2*k,lw*k,c)
end
vtri = function(x1,y1,x2,y2,x3,y3,c)
  local k = C2.k
  tri(x1*k,y1*k,x2*k,y2*k,x3*k,y3*k,c)
end
vorr = function(x,y,w,h,r,c)
  local k = C2.k
  orr(x*k,y*k,w*k,h*k,r*k,c)
end
voov = function(cx,cy,w,h,c)
  local k = C2.k
  oov(cx*k,cy*k,w*k,h*k,c)
end
vtxtC = function(t,cx,y,sz,c)
  local k = C2.k
  txtC(t,cx*k,y*k,sz*k,c)
end
vtxtL = function(t,x,y,sz,c)
  local k = C2.k
  txtL(t,x*k,y*k,sz*k,c)
end
vtwinkle = function(cx,cy,sz)
  local k = C2.k
  twinkle(cx*k,cy*k,sz*k)
end
vcandy = function(cx,cy,sz,c1,c2)
  local k = C2.k
  candy(cx*k,cy*k,sz*k,c1,c2)
end
vbust = function(kind,cx,yy,sz)
  local k = C2.k
  bust(kind,cx*k,yy*k,sz*k)
end
vbtn = function(label,x,y,w,h,col,lip,sz)
  local k = C2.k
  return btn(label,x*k,y*k,w*k,h*k,col,lip,sz*k)
end
vibtn = function(kind,cx,cy,r)
  local k = C2.k
  return ibtn(kind,cx*k,cy*k,r*k)
end
vwrap = function(t,maxw,sz)
  local k = C2.k
  return wrapText(t,maxw*k,sz*k)
end

// ---------- progress / ranks ----------
c2xp = function()
  local v = storage.get("xp")
  if not v then v = 0 end
  return v
end

c2rank = function()
  local r = 0
  for rki=0 to c2RK.length-1
    if c2xp() >= c2RK[rki][1] then r = rki end
  end
  return r
end

c2AddXP = function(n)
  local old = c2rank()
  storage.set("xp", c2xp()+n)
  if c2rank() > old then
    C2.rankUp = 220
    C2.rankName = c2RK[c2rank()][0]
    c2sfx("rank")
  end
end

c2Unlocked = function()
  return storage.get("ch1done") == 1 or G.star1 >= 1
end

c2Exit = function()
  C2.on = false
  go("chapters")
end

// ---------- audio (original 8-bit loops + sfx) ----------
c2Tunes = object end
c2Tunes.menu = ["A4","C5","E5","C5","B4","D5","G#4","B4","A4","E5","C5","A4","F4","A4","C5","E5"]
c2Tunes.case = ["A3","E4","A4","E4","G3","D4","G4","D4","F3","C4","F4","C4","E3","B3","E4","G#4"]
c2Bass = ["A2","F2","G2","E2"]

musicTick = function(kind)
  if C2.mute then return end
  C2.mt = (C2.mt or 0) + 1
  local sp = 13
  if kind == "case" then sp = 22 end
  if C2.mt % sp != 0 then return end
  local mel = c2Tunes[kind]
  local mi = floor(C2.mt/sp) % mel.length
  audio.beep("square volume 14 tempo 700 " + mel[mi])
  if mi % 4 == 0 then
    audio.beep("triangle volume 22 tempo 300 " + c2Bass[floor(mi/4) % c2Bass.length])
  end
end

c2sfx = function(k)
  if C2.mute then return end
  local s = "square volume 30 tempo 900 C5 G5"
  if k == "good" then s = "square volume 30 tempo 700 C5 E5 G5 C6" end
  if k == "bad" then s = "saw volume 30 tempo 600 C3 B2" end
  if k == "pick" then s = "square volume 30 tempo 800 E5 B5" end
  if k == "rank" then s = "square volume 30 tempo 500 C5 E5 G5 C6 E6 G6" end
  audio.beep(s)
end

// ---------- small helpers ----------
wgrad = function(y,h,r1,g1,b1,r2,g2,b2,n)
  local bh = h/n
  for wgi=0 to n-1
    local k = wgi/(n-1)
    vrect(0,y+wgi*bh,720,bh+1,rgb(r1+(r2-r1)*k,g1+(g2-g1)*k,b1+(b2-b1)*k))
  end
end

tapIn = function(x,y,w,h)
  local gx = G.tx/C2.k
  local gy = G.ty/C2.k
  if G.tap and gx >= x and gx <= x+w and gy >= y and gy <= y+h then
    G.tap = false
    return true
  end
  return false
end

caesar = function(t,k)
  local out = ""
  for cii=0 to t.length-1
    local ch = t.substring(cii,cii+1)
    local ix = c2ABC.indexOf(ch)
    if ix >= 0 then
      local n = ((ix+k)%26+26)%26
      out = out + c2ABC.substring(n,n+1)
    else
      out = out + ch
    end
  end
  return out
end

cat2 = function(cx,cy,s,eyes)
  local k = "#15101f"
  vseg(cx+s*0.9,cy+s*0.7,cx+s*1.7,cy+s*0.3,s*0.35,k)
  vseg(cx+s*1.7,cy+s*0.3,cx+s*1.6,cy-s*0.5,s*0.3,k)
  voov(cx,cy+s*0.5,s*1.8,s*1.3,k)
  voov(cx,cy-s*0.45,s*1.4,s*1.1,k)
  vtri(cx-s*0.7,cy-s*0.6,cx-s*0.2,cy-s*0.9,cx-s*0.65,cy-s*1.4,k)
  vtri(cx+s*0.7,cy-s*0.6,cx+s*0.2,cy-s*0.9,cx+s*0.65,cy-s*1.4,k)
  if eyes then
    voval(cx-s*0.3,cy-s*0.5,s*0.36,s*0.3,"#ffd34a")
    voval(cx+s*0.3,cy-s*0.5,s*0.36,s*0.3,"#ffd34a")
    vrect(cx-s*0.33,cy-s*0.6,s*0.06,s*0.22,k)
    vrect(cx+s*0.27,cy-s*0.6,s*0.06,s*0.22,k)
  end
end

emote = function(cx,yy,s,emo)
  local sk = "#e8b48a"
  local bc = "#2a1a3a"
  vrect(cx-6*s,yy-46*s,12*s,7*s,sk)
  if emo == "shock" then
    vseg(cx-13*s,yy-62*s,cx-4*s,yy-64*s,2*s,bc)
    vseg(cx+4*s,yy-64*s,cx+13*s,yy-62*s,2*s,bc)
    voval(cx,yy-42*s,6*s,8*s,"#7a2030")
  elsif emo == "smug" then
    vseg(cx-13*s,yy-63*s,cx-4*s,yy-61*s,2*s,bc)
    vseg(cx+4*s,yy-60*s,cx+13*s,yy-63*s,2*s,bc)
    vseg(cx-4*s,yy-42*s,cx+5*s,yy-44*s,1.5*s,"#8a2a3a")
  elsif emo == "worry" then
    vseg(cx-13*s,yy-60*s,cx-4*s,yy-63*s,2*s,bc)
    vseg(cx+4*s,yy-63*s,cx+13*s,yy-60*s,2*s,bc)
    vseg(cx-4*s,yy-41*s,cx+4*s,yy-41*s,1.5*s,"#8a2a3a")
    voval(cx+24*s,yy-56*s,5*s,7*s,"#7fd8ff")
  elsif emo == "think" then
    vseg(cx-13*s,yy-64*s,cx-4*s,yy-63*s,2*s,bc)
    vseg(cx+4*s,yy-60*s,cx+13*s,yy-60*s,2*s,bc)
    voval(cx+3*s,yy-41*s,4*s,3*s,"#8a2a3a")
    vtxtC("?",cx+32*s,yy-84*s,18*s,C_GOLD)
  else
    vrrect(cx-3*s,yy-42*s,6*s,2*s,s,"#8a2a3a")
  end
end

printArt = function(cx,cy,s,rings,gap)
  vrrect(cx-s*1.1,cy-s*1.3,s*2.2,s*2.6,s*0.2,"#f4ecd8")
  for pri=1 to rings
    vring(cx,cy,s*0.2*pri,s*0.26*pri,1.4,"#2a2a3a")
  end
  if gap == "right" then vrect(cx+s*0.25,cy-s*0.2,s*0.85,s*0.4,"#f4ecd8") end
  if gap == "left" then vrect(cx-s*1.1,cy-s*0.2,s*0.85,s*0.4,"#f4ecd8") end
  if gap == "top" then vrect(cx-s*0.2,cy-s*1.3,s*0.4,s*1.0,"#f4ecd8") end
end

// ---------- camera ----------
camOn = function()
  local k = C2.k
  local RW = screen.width
  local RH = screen.height
  screen.setScale(C2.z,C2.z)
  screen.setTranslation(-C2.z*(C2.cx*k-RW/2), -C2.z*(RH/2-C2.cy*k))
end

camOff = function()
  screen.setScale(1,1)
  screen.setTranslation(0,0)
end

clampCam = function()
  local hw = 360/(2*C2.z)
  local hh = 640/(2*C2.z)
  if 720 > 2*hw then C2.cx = max(hw,min(720-hw,C2.cx)) else C2.cx = 360 end
  if 640 > 2*hh then C2.cy = max(hh,min(640-hh,C2.cy)) else C2.cy = 320 end
end

// ---------- rooms (world 720x640) ----------
drawOffice = function()
  wgrad(0,430,40,34,84,22,18,50,12)
  vorr(40,60,210,240,8,"#16225e")
  voval(190,120,46,46,"#fff0b0")
  vrect(48,220,36,74,"#0b1236")
  vrect(90,190,30,104,"#0b1236")
  vrect(126,230,40,64,"#0b1236")
  vrect(172,200,34,94,"#0b1236")
  vrect(212,235,32,59,"#0b1236")
  vrect(98,205,5,6,"#ffd36b")
  vrect(180,215,5,6,"#ffd36b")
  vrect(143,60,5,240,"#6a5a9a")
  vrect(40,178,210,5,"#6a5a9a")
  vtwinkle(80,100,5)
  vtwinkle(130,140,4)
  vorr(310,60,190,130,6,"#b8864e")
  vrect(318,68,174,114,"#d9a45a")
  vrect(330,80,40,32,C_CREAM)
  vrect(380,76,36,26,"#ffe58a")
  vrect(430,86,44,34,C_CREAM)
  vrect(340,130,36,36,C_CREAM)
  vrect(398,128,44,40,"#cfe8ff")
  vseg(350,96,398,90,1.5,"#d62e2e")
  vseg(398,90,452,103,1.5,"#d62e2e")
  vseg(358,148,420,148,1.5,"#d62e2e")
  voval(350,96,5,5,"#ff3b3b")
  voval(398,90,5,5,"#ff3b3b")
  voval(452,103,5,5,"#ff3b3b")
  vorr(540,70,70,100,3,"#e8c070")
  vtxtC("WANTED",575,86,11,"#8a2a1a")
  voval(575,125,34,34,"#c89a60")
  vring(640,100,22,22,3,"#9aa8c0")
  vring(662,100,22,22,3,"#9aa8c0")
  wgrad(430,210,92,58,40,56,34,26,8)
  vrect(0,425,720,8,"#2a1a30")
  voval(330,560,360,70,"#5a2a4a")
  voval(330,560,290,48,"#7a3a64")
  vorr(600,150,95,280,6,"#6b3b1f")
  vrrect(612,165,70,110,4,"#58300f")
  voval(678,300,10,10,C_GOLD)
  vtxtC("EXIT",647,142,10,C_GOLD)
  vorr(150,325,340,22,5,"#9a6a3a")
  vrect(165,347,20,110,"#6b4524")
  vrect(455,347,20,110,"#6b4524")
  vrrect(300,350,150,60,4,"#7a5230")
  vrect(360,375,30,5,C_GOLD)
  vrrect(325,262,70,48,4,"#2b2b3c")
  vrect(331,268,58,36,"#3a5a8a")
  vrect(337,274,30,4,"#cfe8ff")
  vrect(337,282,40,4,"#cfe8ff")
  vrect(315,312,90,8,"#4a4a5c")
  vseg(210,325,226,285,3,"#3a3a4a")
  vtri(208,285,248,285,228,262,"#e8a030")
  vrrect(430,305,22,20,3,"#f3d9a0")
  // pocket watch (zoom in to read it)
  voov(215,318,26,26,"#cfd8e0")
  voval(215,318,20,20,"#fff8e6")
  vseg(215,318,213,310,1.2,"#222222")
  vseg(215,318,207,311,1,"#222222")
  if C2.z >= 1.8 then
    vtxtC("XII",215,311,5,"#222222")
    vtxtC("stopped: 11:52",215,340,7,C_GOLD)
  end
  if C2.catHere then cat2(485,308,15,true) end
  if C2.mode == "cat" then cat2(C2.catx,C2.caty,15,true) end
end

drawAlley = function()
  wgrad(0,420,12,8,34,24,16,60,10)
  voval(560,90,60,60,"#e8e0c0")
  for abr=0 to 7
    for abc=0 to 12
      local off = (abr%2)*30
      local col = "#2a1a40"
      if (abr+abc)%4 == 0 then col = "#33224f" end
      vrect(abc*60-off,150+abr*34,56,30,col)
    end
  end
  wgrad(420,220,40,34,60,22,18,36,8)
  vrect(0,418,720,6,"#150d28")
  vrect(330,200,10,240,"#3a3a4a")
  voval(335,195,30,18,"#665533")
  local wob = 0
  if C2.mode == "shake" then wob = sin(G.t*1.3)*C2.wig*0.8 end
  vorr(120+wob,360,70,80,6,"#3a5a4a")
  vrect(115+wob,350,80,12,"#2a4a3a")
  vrect(512,360,12,80,"#4a4a5a")
  vorr(480,320,70,48,8,"#3a4a8a")
  vrect(488,338,54,6,"#111122")
  voval(515,332,8,8,"#ff5fa2")
  voval(250,445,60,14,"#30406a")
  vcandy(250,438,6,C_PINK,C_GOLD)
  vorr(10,300,60,130,5,"#6b3b1f")
  vtxtC("OFFICE",40,292,9,C_GOLD)
  if f_(C2,"match") then
    vtri(660,400,700,420,660,440,C_MINT)
    vtxtC("TOWER",670,380,10,C_MINT)
  else
    vseg(640,390,720,350,10,"#ffcc00")
    vseg(640,410,720,370,10,"#ffcc00")
    for tpi=0 to 4
      vseg(650+tpi*16,402-tpi*8,656+tpi*16,396-tpi*8,10,"#111111")
    end
  end
end

drawTower = function()
  wgrad(0,420,8,6,30,30,20,70,10)
  voval(120,80,50,50,"#e8e0c0")
  vseg(540,120,500,430,5,"#5a5a7a")
  vseg(540,120,580,430,5,"#5a5a7a")
  vseg(515,300,565,300,3,"#5a5a7a")
  vseg(522,220,558,220,3,"#5a5a7a")
  vseg(508,370,572,370,3,"#5a5a7a")
  local bc = "#661a1a"
  if floor(G.t/25)%2 == 0 then bc = "#ff3b3b" end
  voval(540,112,14,14,bc)
  wgrad(420,220,36,30,56,20,16,34,8)
  vorr(180,380,130,60,6,"#3a3a52")
  vrect(190,390,50,24,"#0b3a2a")
  voval(215,402,30,30,"#2fe08a")
  vring(215,402,30,30,2,"#0b3a2a")
  voval(270,400,12,12,C_PINK)
  vorr(10,300,60,130,5,"#6b3b1f")
  vtxtC("ALLEY",40,292,9,C_GOLD)
  if not f_(C2,"done") then
    voval(430,360,34,34,"#0d0620")
    vrrect(405,378,50,70,10,"#0d0620")
    vring(430,360,44,26,4,"#444466")
    vring(470,432,16,16,3,"#cfd8e0")
    vring(488,432,16,16,3,"#cfd8e0")
    vseg(478,432,480,432,3,"#cfd8e0")
  end
end

f_ = function(o,k)
  return C2.f[k] == true
end

// ---------- hotspots ----------
c2spots = function()
  local L = []
  if C2.room == "office" then
    if C2.catHere then L.push(["cat",485,308,40]) end
    L.push(["laptop",360,288,45])
    L.push(["board",405,125,70])
    L.push(["watch",215,318,22])
    L.push(["door",647,290,60])
  elsif C2.room == "alley" then
    L.push(["back",40,370,55])
    L.push(["bin",155,400,55])
    L.push(["mailbox",515,350,45])
    L.push(["tower",670,410,55])
  else
    L.push(["back",40,370,55])
    L.push(["console",245,410,55])
    L.push(["cuffs",470,430,50])
  end
  return L
end

c2Tap = function(wx,wy)
  local L = c2spots()
  local best = ""
  local bd = 99999
  for tli=0 to L.length-1
    local dx = wx-L[tli][1]
    local dy = wy-L[tli][2]
    local d = sqrt(dx*dx+dy*dy)
    if d < L[tli][3] and d < bd then
      bd = d
      best = L[tli][0]
    end
  end
  if best != "" then c2Act(best) end
end

dlgStart = function(list,aft)
  C2.dl = list
  C2.di = 0
  C2.aft = aft
  C2.mode = "dlg"
end

c2Act = function(id)
  local f = C2.f
  c2sfx("tap")
  if id == "cat" then
    if not f.sd then
      dlgStart([["Licorice","","*drops the SD card at your feet* Mrrp."],["You","shock","He WANTS me to take it. Okay, okay!"]], function()
        C2.f.sd = true
        c2sfx("pick")
        say("Got: SD card. Open the phone workspace (folder icon).")
      end)
    else
      say("Licorice purrs. He's guarding the pocket watch.")
    end
  elsif id == "laptop" then
    C2.mode = "work"
    C2.tab = 1
  elsif id == "board" then
    say("Board: a missing trick-or-treater and a pirate signal at 11:52, the minute the shop went quiet.")
  elsif id == "watch" then
    if C2.z < 1.8 then
      say("A tiny pocket watch. Zoom in (+) to read it.")
    elsif not f.watch then
      C2.f.watch = true
      c2AddXP(10)
      say("Stopped at 11:52. Time = 1152.")
    else
      say("11:52. Stopped. Always.")
    end
  elsif id == "door" then
    C2.room = "alley"
    C2.cx = 120
    C2.cy = 320
    say("Dark out here. HOLD your finger down for light, drag to look around.")
  elsif id == "back" then
    if C2.room == "tower" then
      C2.room = "alley"
    else
      C2.room = "office"
    end
    C2.cx = 360
    C2.cy = 320
  elsif id == "bin" then
    if not f.bin then
      C2.mode = "shake"
      C2.wig = 0
    else
      say("Empty now.")
    end
  elsif id == "mailbox" then
    if f.box then
      say("Empty. Evidence is in your phone (PRINTS).")
    else
      C2.mode = "key"
      C2.code = ""
    end
  elsif id == "tower" then
    if f.match then
      C2.room = "tower"
      C2.cx = 300
      C2.cy = 320
    else
      say("Police tape. Not yet. Identify the culprit first.")
    end
  elsif id == "console" then
    say("Static loops: 11:52. Someone broadcast from here nightly.")
  elsif id == "cuffs" then
    if not f.done then
      dlgStart([["You","smug","Dex Harlow. Night DJ. Your pirate signal led the trick-or-treater right here."],["Dex","shock","I only played the sugar's whisper! I didn't know the Hollow was riding my signal!"],["You","think","So the Hollow uses the radio. The kid is still out there... and the festival is next."],["Licorice","","Mrrow."]], c2Finish)
    end
  end
end

c2Finish = function()
  C2.f.done = true
  storage.set("ch2done",1)
  c2AddXP(50)
  C2.mode = "end"
  c2sfx("good")
end

// ---------- dark ----------
darkPass = function(lx,ly,R,a)
  local W = 360
  local H = 640
  screen.setAlpha(a)
  local sh = 10
  for dri=0 to ceil(H/sh)-1
    local y0 = dri*sh
    local dy = abs(y0+sh/2-ly)
    if lx < 0 or dy >= R then
      vrect(0,y0,W,sh,"#05030c")
    else
      local hw = sqrt(R*R-dy*dy)
      vrect(0,y0,max(0,lx-hw),sh,"#05030c")
      vrect(lx+hw,y0,max(0,W-lx-hw),sh,"#05030c")
    end
  end
  screen.setAlpha(1)
end

// ---------- update ----------
c2Update = function()
  C2.k = screen.width/360
  local W = 360
  local H = 640
  G.t = (G.t or 0) + 1
  musicTick("case")
  if G.toastT > 0 then G.toastT -= 1 end
  if C2.rankUp > 0 then C2.rankUp -= 1 end
  local tt = touch.touching
  local px = (touch.x + screen.width/2)/C2.k
  local py = (screen.height/2 - touch.y)/C2.k
  G.tap = false
  if tt then
    if not C2.was then
      C2.drag = 0
      C2.lx = px
      C2.ly = py
      C2.sg = 0
    end
    local dx = px - C2.lx
    local dy = py - C2.ly
    C2.drag += abs(dx)+abs(dy)
    if C2.mode == "play" and C2.drag > 14 then
      C2.cx -= dx/C2.z
      C2.cy -= dy/C2.z
    end
    if C2.mode == "shake" and abs(dx) > 7 then
      local sg = 1
      if dx < 0 then sg = -1 end
      if sg != C2.sg then
        C2.wig += 1
        C2.sg = sg
        c2sfx("tap")
      end
    end
    if C2.mode == "play" and C2.room != "office" and C2.batt > 0 then
      C2.batt -= 0.06*C2.drainMul
    end
    C2.lx = px
    C2.ly = py
  elsif C2.was then
    if C2.drag < 14 then
      G.tap = true
      G.tx = C2.lx*C2.k
      G.ty = C2.ly*C2.k
    end
  end
  C2.was = tt
  if C2.mode == "shake" and C2.wig >= 14 then
    C2.f.bin = true
    C2.batt = min(100,C2.batt+60)
    c2AddXP(10)
    c2sfx("good")
    C2.mode = "play"
    say("A spare battery fell out! Flashlight +60%.")
  end
  if C2.mode == "cat" then
    C2.ct += 1
    C2.cx = 300
    C2.cy = 300
    C2.z = 1.25
    if C2.ct < 80 then
      C2.catx = 140
      C2.caty = 165
    elsif C2.ct < 200 then
      local k = (C2.ct-80)/120
      C2.catx = 140 + 345*k
      C2.caty = 165 + 143*k - sin(k*PI)*90
    else
      C2.catHere = true
      dlgStart([["Licorice","","Mrrp."],["You","shock","A cat?! And there's an SD card in his mouth."],["You","smug","Fine. You're hired, partner. I'll call you Licorice."],["You","think","Pet his head (tap him), then use the phone workspace."]], function()
        say("Tap Licorice to take the SD card.")
      end)
    end
  end
  clampCam()
end

// ---------- draw ----------
drawDlg = function()
  local W = 360
  local H = 640
  local d = C2.dl[C2.di]
  local bh = H*0.27
  local yy = H - bh - 8
  vorr(10,yy,W-20,bh,14,C_DEEP)
  local nm = d[0]
  if nm == "You" then
    nm = "DETECTIVE"
    vbust("You",52,yy+24,0.8)
    emote(52,yy+24,0.8,d[1])
  elsif nm == "Licorice" then
    cat2(50,yy+8,17,true)
  end
  vtxtL(nm,100,yy+16,13,C_GOLD)
  local fs = 13
  local lines = vwrap(d[2],W-125,fs)
  for dli=0 to lines.length-1
    vtxtL(lines[dli],100,yy+38+dli*17,fs,"#fff7e6")
  end
  if floor(G.t/20)%2 == 0 then vtxtC("tap",W-30,yy+bh-12,11,C_GOLD) end
  if G.tap then
    G.tap = false
    c2sfx("tap")
    C2.di += 1
    if C2.di >= C2.dl.length then
      C2.mode = "play"
      if C2.aft then
        local fn = C2.aft
        C2.aft = null
        fn()
      end
    end
  end
end

c2Hint = function()
  local f = C2.f
  if c2rank() < 1 then
    say("Reach Detective rank to unlock hints.")
  elsif not f.sd then say("Licorice has something for you. Tap him.")
  elsif not f.dec then say("Open the phone workspace and decode the SD log.")
  elsif not f.watch then say("Zoom in (+) on the pocket watch on your desk.")
  elsif not f.box then say("Alley: shake the bin for a battery, then enter the time on the mailbox.")
  elsif not f.match then say("Phone > PRINTS. Compare ring count AND the gap.")
  elsif not f.done then say("The tape is gone. Head to the tower.")
  else say("Case closed.") end
end

c2HUD = function()
  local W = 360
  local H = 640
  if vibtn("back",24,24,14) then
    c2sfx("tap")
    c2Exit()
  end
  if vibtn("bulb",64,24,14) then
    c2sfx("tap")
    c2Hint()
  end
  if vibtn("folder",104,24,14) then
    c2sfx("tap")
    C2.mode = "work"
    C2.tab = 0
  end
  if vibtn("board",144,24,14) then
    c2sfx("tap")
    C2.mode = "rank"
  end
  if vbtn("+",W-46,H*0.45,36,34,C_ORANGE,C_ORANGE2,22) then
    C2.z = min(2.6,C2.z+0.35)
    c2sfx("tap")
  end
  if vbtn("-",W-46,H*0.45+44,36,34,C_ORANGE,C_ORANGE2,22) then
    C2.z = max(1.0,C2.z-0.35)
    c2sfx("tap")
  end
  if C2.room != "office" then
    vorr(10,H-24,124,14,7,C_DEEP)
    vrect(14,H-21,116*max(0,C2.batt)/100,8,C_GOLD)
    vtxtL("HOLD=LIGHT",140,H-17,10,"#fff7e6")
  end
end

drawWork = function()
  local W = 360
  local H = 640
  vrect(0,0,W,H,C_INK)
  vrect(0,0,W,H*0.09,C_DEEP)
  vtxtL("WORKSPACE",14,26,16,C_GOLD)
  if vibtn("x",W-26,26,13) then
    c2sfx("tap")
    C2.mode = "play"
  end
  local names = ["NOTES","DECODE","PRINTS"]
  for tbi=0 to 2
    local col = C_PURPLE
    if C2.tab == tbi then col = C_ORANGE end
    if vbtn(names[tbi],10+tbi*113,54,106,32,col,C_DEEP,13) then
      C2.tab = tbi
      c2sfx("tap")
    end
  end
  local f = C2.f
  if C2.tab == 0 then
    local n = "Case #2: THE VANISHING TRICK-OR-TREATER.|- A kid vanished on Maple Street.|- A pirate signal broadcasts every night at 11:52.|- A black cat brought an SD card."
    if f.dec then n += "|- Log says: the box opens with the time on the dead watch." end
    if f.watch then n += "|- The watch is stopped at 11:52." end
    if f.box then n += "|- Mailbox evidence: a fingerprint on a sugar skull baggie." end
    if f.match then n += "|- Print matches DEX HARLOW. Tape is down at the tower." end
    local lines = vwrap(n,W-40,14)
    for nli=0 to lines.length-1
      vtxtL(lines[nli],20,120+nli*22,14,"#fff7e6")
    end
  elsif C2.tab == 1 then
    if not f.sd then
      vtxtC("No SD card inserted.",W/2,200,15,C_PINK)
    else
      vtxtL("dead_air.log  [ENCRYPTED]",20,120,14,C_MINT)
      local cl = vwrap(caesar(c2PLAIN,c2SHIFT),W-40,16)
      for cli=0 to cl.length-1
        vtxtL(cl[cli],20,150+cli*22,16,C_MINT)
      end
      vtxtC("SHIFT: "+C2.shift,W/2,300,18,C_GOLD)
      if vbtn("-",40,280,60,40,C_PURPLE2,C_PURPLE,22) then
        C2.shift = (C2.shift+25)%26
        c2sfx("tap")
      end
      if vbtn("+",W-100,280,60,40,C_PURPLE2,C_PURPLE,22) then
        C2.shift = (C2.shift+1)%26
        c2sfx("tap")
      end
      local dl = vwrap(caesar(caesar(c2PLAIN,c2SHIFT),-C2.shift),W-40,16)
      for dci=0 to dl.length-1
        vtxtL(dl[dci],20,360+dci*22,16,C_CREAM)
      end
      if C2.shift == c2SHIFT and not f.dec then
        C2.f.dec = true
        c2AddXP(30)
        c2sfx("good")
        say("Decoded! Find the time on the dead watch.")
      end
    end
  else
    if not f.box then
      vtxtC("No samples collected yet.",W/2,200,15,C_PINK)
    else
      vtxtC("SAMPLE (mailbox)",W/2,120,13,C_GOLD)
      printArt(W/2,190,34,7,"right")
      for pci=0 to 3
        local cx = W*0.27 + (pci%2)*W*0.46
        local cy = 350 + floor(pci/2)*140
        printArt(cx,cy,28,c2Cands[pci][1],c2Cands[pci][2])
        vtxtC(c2Cands[pci][0],cx,cy+48,12,"#fff7e6")
        if tapIn(cx-34,cy-40,68,80) and not f.match then
          if pci == 2 then
            C2.f.match = true
            c2AddXP(30)
            c2sfx("good")
            say("MATCH: Dex Harlow, night DJ. Police tape is down at the tower!")
          else
            c2sfx("bad")
            say("No match. Compare rings AND the gap.")
          end
        end
      end
    end
  end
end

drawKey = function()
  local W = 360
  local H = 640
  vorr(30,120,W-60,400,14,C_DEEP)
  vtxtC("MAILBOX LOCK",W/2,150,16,C_GOLD)
  local shown = C2.code
  while shown.length < 4
    shown = shown + "_"
  end
  vtxtC(shown,W/2,200,32,C_MINT)
  local labels = ["1","2","3","4","5","6","7","8","9","CLR","0","OK"]
  for kpi=0 to 11
    local bx = 50 + (kpi%3)*84
    local yy = 240 + floor(kpi/3)*62
    if vbtn(labels[kpi],bx,yy,76,50,C_PURPLE2,C_PURPLE,18) then
      c2sfx("tap")
      local l = labels[kpi]
      if l == "CLR" then
        C2.code = ""
      elsif l == "OK" then
        if C2.code == "1152" then
          C2.f.box = true
          c2AddXP(20)
          c2sfx("good")
          C2.mode = "play"
          say("Inside: a baggie with a sugar skull and a fingerprint. Check PRINTS on the phone.")
        else
          c2sfx("bad")
          C2.code = ""
        end
      elsif C2.code.length < 4 then
        C2.code = C2.code + l
      end
    end
  end
  if vibtn("x",W-48,138,12) then
    C2.mode = "play"
  end
end

drawRank = function()
  local W = 360
  local H = 640
  vrect(0,0,W,H,C_INK)
  vtxtC("OFFICER STATUS",W/2,40,20,C_GOLD)
  vtxtC("XP: "+c2xp(),W/2,70,14,"#fff7e6")
  local cur = c2rank()
  for rri=0 to 4
    local col = C_DEEP
    if rri == cur then col = C_ORANGE2 end
    vorr(20,100+rri*90,W-40,78,10,col)
    local lock = ""
    if rri > cur then lock = "  (locked)" end
    vtxtL(c2RK[rri][0]+lock,34,124+rri*90,16,C_GOLD)
    vtxtL(c2RK[rri][1]+" XP",34,146+rri*90,12,"#fff7e6")
    local pl = vwrap("Perk: "+c2RK[rri][2],W-70,12)
    vtxtL(pl[0],34,166+rri*90,12,C_MINT)
  end
  if vibtn("x",W-26,24,13) then
    C2.mode = "play"
    c2sfx("tap")
  end
end

c2End = function()
  local W = 360
  local H = 640
  vrect(0,0,W,H,C_INK)
  vtxtC("SIGNAL TRACED",W/2,150,26,C_ORANGE)
  vtxtC("The trick-or-treater is still out there...",W/2,190,12,"#fff7e6")
  vtxtC("Rank: "+c2RK[c2rank()][0],W/2,260,20,C_GOLD)
  vtxtC("XP: "+c2xp(),W/2,290,14,"#fff7e6")
  vtxtC("Perk: "+c2RK[c2rank()][2],W/2,320,12,C_MINT)
  cat2(W/2,420,26,true)
  if vbtn("CONTINUE",W/2-80,520,160,48,C_ORANGE,C_ORANGE2,18) then
    c2sfx("tap")
    c2Exit()
  end
end

c2Draw = function()
  C2.k = screen.width/360
  local W = 360
  local H = 640
  vrect(0,0,W,H,C_INK)
  if C2.mode == "work" then
    drawWork()
    drawToast()
    return
  end
  if C2.mode == "rank" then
    drawRank()
    return
  end
  if C2.mode == "end" then
    c2End()
    return
  end
  camOn()
  if C2.room == "office" then
    drawOffice()
  elsif C2.room == "alley" then
    drawAlley()
  else
    drawTower()
  end
  camOff()
  if C2.room != "office" and C2.mode != "dlg" then
    local R = 70
    if c2rank() >= 2 then R = 100 end
    if C2.batt <= 0 then R = 34 end
    local lx = -1
    local ly = -1
    if C2.was then
      lx = C2.lx
      ly = C2.ly
    end
    darkPass(lx,ly,R*1.35,0.55)
    darkPass(lx,ly,R,0.4)
    if c2rank() >= 3 and lx >= 0 then
      camOn()
      local sp = c2spots()
      for spi=0 to sp.length-1
        vtwinkle(sp[spi][1],sp[spi][2]-20,6)
      end
      camOff()
    end
  end
  if C2.mode == "cat" then
    vrect(0,0,W,H*0.12,"#000000")
    vrect(0,H*0.88,W,H*0.12,"#000000")
  elsif C2.mode == "dlg" then
    drawDlg()
  elsif C2.mode == "play" then
    c2HUD()
    if G.tap then
      local wx = (G.tx/C2.k-W/2)/C2.z + C2.cx
      local wy = (G.ty/C2.k-H/2)/C2.z + C2.cy
      G.tap = false
      c2Tap(wx,wy)
    end
  elsif C2.mode == "shake" then
    vorr(20,90,W-40,70,10,C_DEEP)
    vtxtC("SHAKE IT! Wiggle your finger left-right",W/2,115,12,C_GOLD)
    vrect(40,135,(W-80)*C2.wig/14,10,C_MINT)
  elsif C2.mode == "key" then
    drawKey()
  end
  if C2.rankUp > 0 then
    vorr(30,90,W-60,40,10,C_ORANGE2)
    vtxtC("PROMOTED: "+C2.rankName+"!",W/2,110,16,"#fff7e6")
  end
  drawToast()
end

// ---------- entry points (call from main) ----------
c2Open = function()
  C2.k = screen.width/360
  if not c2Unlocked() then
    say("Finish Chapter 1 first!")
    return false
  end
  C2.on = true
  C2.was = true
  C2.drag = 99
  C2.lx = 0
  C2.ly = 0
  C2.f = object end
  C2.room = "office"
  C2.cx = 300
  C2.cy = 320
  C2.z = 1.25
  C2.batt = 100
  C2.shift = 0
  C2.tab = 0
  C2.wig = 0
  C2.ct = 0
  C2.catHere = false
  C2.rankUp = 0
  C2.drainMul = 1
  if c2rank() >= 2 then C2.drainMul = 0.67 end
  dlgStart([["You","worry","Odette's note said the Hollow already chose this year's name: a trick-or-treater on Maple Street."],["You","think","Now a kid is missing, and a pirate signal has crackled on my radio at 11:52 every night since."],["You","shock","...Did something just move at the window?"]], function()
    C2.mode = "cat"
    C2.ct = 0
  end)
  return true
end
end()



// file: source2.ms
function()
// =====================================================
// SUGAR & SPOOKS - Chapter 3: THE CURSED HALLOWEEN FESTIVAL  (FIXED v2)  (source: "chapter3")
// Needs the "source" (chapter2.ms) file too: it reuses its scale layer (v* helpers),
// dialogue box, camera, darkness, sounds and XP/rank functions.
// =====================================================

C3 = object end
C3.on = false

c3Order = ["glasses","coffee","sword","lamp","usb","printer","poison","pass"]
c3Shop = [["glasses","Reading Glasses",15],["coffee","Takeout Coffee",5],["sword","Wooden Sword",25],["printer","Old Printer",60]]
c3Cards = ["The Moon","The Sun","The Star","The Tower"]
c3Ans = [1,3,0,2]
c3Tune = ["D4","A3","D4","G#3","A3","F4","E4","A3","D4","C#4","A3","G#3","F3","A3","E3","A#3"]
c3Bass = ["D2","D2","A#1","A1"]
c3Web = [["hollow hill festival","","Founded 1962 as a harvest fair. Each year the Bell Tower tolls at 11:52 PM, the festival's 'sweet toll'. Nobody remembers who rings it."],["lantern ritual","photoB","Old custom: three lanterns are lit in the SAME order the bunting flags repeat. A wrong order snuffs them all."],["cursed wrappers","ghoulA","Cursed sweets wear PURPLE stripes and a GOLD star seal. They look delicious. Never eat them."],["binary basics","usb","Read bits in groups of four: 8 4 2 1. Example: 0101 = 4+1 = 5."]]

// ---------- music (own loop, same audio gate as chapter 2) ----------
c3Music = function()
  if touch.touching then
    C3.tch = true
  elsif C3.tch then
    C2.audioReady = true
  end
  if C2.mute or not C2.audioReady then return end
  C3.mt = (C3.mt or 0) + 1
  if C3.mt % 24 != 0 then return end
  local mi = floor(C3.mt/24) % 16
  audio.beep("square volume 12 tempo 600 " + c3Tune[mi])
  if mi % 4 == 0 then
    audio.beep("triangle volume 24 tempo 250 " + c3Bass[mi/4])
  end
end

// ---------- small art kit ----------
vweb = function(x,y,dx,dy,s)
  web(x*C2.k,y*C2.k,dx,dy,s*C2.k)
end

vpumpkin = function(x,y,s)
  pumpkin(x*C2.k,y*C2.k,s*C2.k)
end

glow = function(x,y,r,c)
  screen.setAlpha(0.10)
  voval(x,y,r*2.4,r*2.4,c)
  screen.setAlpha(0.14)
  voval(x,y,r*1.6,r*1.6,c)
  screen.setAlpha(0.2)
  voval(x,y,r*0.9,r*0.9,c)
  screen.setAlpha(1)
end

lantern = function(x,y,c,lit)
  vseg(x,y-20,x,y-9,1.5,"#1a1030")
  vorr(x-8,y-9,16,22,6,"#3a2a40")
  if lit then
    glow(x,y+2,16,c)
    vrrect(x-6,y-7,12,18,5,c)
    voval(x,y+2,6,8,"#fff3b0")
  else
    vrrect(x-6,y-7,12,18,5,"#4a3a50")
  end
end

sweet = function(kind,x,y,s)
  if kind == "gum" then
    voval(x,y+s*0.2,s*1.1,s*1.4,"#e0344a")
    voval(x,y-s*0.7,s*0.8,s*0.8,"#e0344a")
    voval(x-s*0.3,y-s*1.05,s*0.3,s*0.3,"#e0344a")
    voval(x+s*0.3,y-s*1.05,s*0.3,s*0.3,"#e0344a")
    voval(x,y+s*0.2,s*0.5,s*0.7,"#ff7a7a")
  elsif kind == "cane" then
    vseg(x,y+s,x,y-s*0.5,s*0.4,"#fff1d6")
    vseg(x,y-s*0.5,x+s*0.6,y-s*0.9,s*0.4,"#fff1d6")
    vseg(x-s*0.2,y+s*0.4,x+s*0.2,y+s*0.2,s*0.2,"#ff5fa2")
    vseg(x-s*0.2,y,x+s*0.2,y-s*0.2,s*0.2,"#ff5fa2")
  elsif kind == "swirl" then
    // round striped candy, matching the replacement shown in the reference
    local r = s*0.95
    local cols = ["#ff9fc4","#cfe8ff","#ffc94a","#9fe8d0"]
    voval(x,y,r*2,r*2,"#fff1d6")
    for wi=0 to 11
      local a0 = wi*PI/6
      local a1 = (wi+1)*PI/6
      local col = cols[wi%4]
      vtri(x,y,x+cos(a0)*r,y+sin(a0)*r,x+cos(a1)*r,y+sin(a1)*r,col)
    end
    voval(x,y,r*0.34,r*0.34,"#fff1d6")
  elsif kind == "pop" then
    vseg(x,y,x,y+s*1.2,s*0.2,"#c8a050")
    voval(x,y-s*0.2,s*1.1,s*1.1,"#ff8a1f")
    voval(x,y-s*0.2,s*0.6,s*0.6,"#fff1d6")
  elsif kind == "corn" then
    vtri(x-s*0.5,y+s*0.6,x+s*0.5,y+s*0.6,x,y-s*0.7,"#ffc94a")
    vtri(x-s*0.25,y-s*0.1,x+s*0.25,y-s*0.1,x,y-s*0.7,"#fff1d6")
    vrect(x-s*0.4,y+s*0.3,s*0.8,s*0.3,"#ff8a1f")
  elsif kind == "bad" then
    vcandy(x,y,s*0.55,"#7b4bd6","#4a2a8a")
    vseg(x-s*0.3,y-s*0.3,x+s*0.1,y+s*0.3,s*0.15,"#d9c8ff")
    vtri(x-s*0.15,y,x+s*0.15,y,x,y-s*0.35,"#ffc94a")
    vtri(x-s*0.15,y-s*0.2,x+s*0.15,y-s*0.2,x,y+s*0.15,"#ffc94a")
  else
    vcandy(x,y,s*0.55,"#5fe3a8","#7b4bd6")
  end
end

ghoulFig = function(x,y,s,c)
  vseg(x-s*0.5,y-s*0.8,x-s*0.9,y-s*0.2,s*0.2,"#9ad48a")
  vseg(x+s*0.5,y-s*0.8,x+s*0.9,y-s*0.2,s*0.2,"#9ad48a")
  vrrect(x-s*0.5,y-s*1.2,s,s*1.2,s*0.3,c)
  // legs
  vrect(x-s*0.34,y-s*0.05,s*0.22,s*0.65,"#183d8c")
  vrect(x+s*0.12,y-s*0.05,s*0.22,s*0.65,"#183d8c")
  voov(x,y-s*1.55,s*0.9,s*0.9,"#9ad48a")
  voval(x-s*0.2,y-s*1.6,s*0.2,s*0.2,"#fff3b0")
  voval(x+s*0.2,y-s*1.6,s*0.2,s*0.2,"#fff3b0")
  vrect(x-s*0.2,y-s*1.3,s*0.4,s*0.08,"#2a1a3a")
end

ghostFig = function(x,y,s)
  screen.setAlpha(0.85)
  voval(x,y-s,s,s*1.4,"#f0eaff")
  vtri(x-s*0.5,y-s*0.2,x-s*0.15,y-s*0.2,x-s*0.33,y+s*0.15,"#f0eaff")
  vtri(x-s*0.1,y-s*0.2,x+s*0.25,y-s*0.2,x+s*0.07,y+s*0.15,"#f0eaff")
  vtri(x+s*0.2,y-s*0.2,x+s*0.5,y-s*0.2,x+s*0.35,y+s*0.15,"#f0eaff")
  screen.setAlpha(1)
  voval(x-s*0.2,y-s*1.1,s*0.18,s*0.25,"#2a1a3a")
  voval(x+s*0.2,y-s*1.1,s*0.18,s*0.25,"#2a1a3a")
end

witchFig = function(x,y,s,robe,hat,faceMark)
  vtri(x-s*0.6,y,x+s*0.6,y,x,y-s*1.4,robe)
  voval(x,y-s*1.55,s*0.7,s*0.7,"#f2c9a4")
  vrect(x-s*0.55,y-s*1.8,s*1.1,s*0.14,hat)
  vtri(x-s*0.4,y-s*1.8,x+s*0.4,y-s*1.8,x,y-s*2.7,hat)
  if faceMark != false then
    voval(x,y-s*1.5,s*0.1,s*0.1,"#2a1a3a")
  end
end

badge = function(x,y,s)
  vtri(x-s,y-s*0.5,x+s,y-s*0.5,x,y+s*1.2,C_GOLD)
  vrrect(x-s,y-s*1.1,s*2,s*0.9,s*0.3,C_GOLD)
  vtri(x-s*0.6,y-s*0.4,x+s*0.6,y-s*0.4,x,y+s*0.7,"#7a1a2a")
  vtri(x-s*0.3,y-s*0.1,x+s*0.3,y-s*0.1,x,y-s*0.7,C_GOLD)
  vtri(x-s*0.3,y-s*0.5,x+s*0.3,y-s*0.5,x,y+s*0.1,C_GOLD)
end

itemIcon = function(id,x,y,s)
  if id == "glasses" then
    vring(x-s*0.35,y,s*0.6,s*0.6,2,"#cfd8e0")
    vring(x+s*0.35,y,s*0.6,s*0.6,2,"#cfd8e0")
    vseg(x-s*0.05,y,x+s*0.05,y,2,"#cfd8e0")
  elsif id == "coffee" then
    vrrect(x-s*0.35,y-s*0.4,s*0.7,s*0.9,s*0.1,"#c8a050")
    vrect(x-s*0.4,y-s*0.5,s*0.8,s*0.2,"#4a2a1a")
  elsif id == "sword" then
    vseg(x-s*0.4,y+s*0.5,x+s*0.45,y-s*0.5,3,"#d9a05a")
    vseg(x-s*0.3,y+s*0.1,x-s*0.1,y+s*0.3,3,"#6b3b1f")
  elsif id == "lamp" then
    voval(x,y+s*0.1,s*0.9,s*0.5,C_GOLD)
    vtri(x+s*0.3,y,x+s*0.7,y-s*0.3,x+s*0.4,y+s*0.2,C_GOLD)
    vrect(x-s*0.2,y+s*0.3,s*0.4,s*0.15,C_GOLD)
  elsif id == "usb" then
    vrrect(x-s*0.2,y-s*0.2,s*0.7,s*0.4,3,"#222222")
    vrect(x-s*0.55,y-s*0.12,s*0.35,s*0.24,"#cfd8e0")
  elsif id == "printer" then
    vrrect(x-s*0.5,y-s*0.2,s,s*0.6,4,"#8a8a9a")
    vrect(x-s*0.3,y-s*0.5,s*0.6,s*0.3,"#fff1d6")
  elsif id == "poison" then
    voval(x,y+s*0.2,s*0.7,s*0.7,"#7b4bd6")
    vrect(x-s*0.12,y-s*0.5,s*0.24,s*0.4,"#cfe8ff")
    voval(x,y+s*0.2,s*0.2,s*0.2,"#fff1d6")
  else
    vrrect(x-s*0.4,y-s*0.35,s*0.8,s*0.7,3,C_CREAM)
    vtri(x-s*0.15,y,x+s*0.15,y,x,y-s*0.3,C_GOLD)
  end
end

// ---------- rooms ----------
drawBunting = function(y0)
  for bsi=0 to 1
    local yb = y0 + bsi*52
    for bi=0 to 21
      local x = 8 + bi*32
      local y = yb + 22*sin(PI*bi/21)
      local x2 = 8 + (bi+1)*32
      local y2 = yb + 22*sin(PI*(bi+1)/21)
      vseg(x,y,x2,y2,1,"#3a2a40")
      local col = "#ff8a1f"
      if (bi+bsi)%3 == 1 then col = "#7b4bd6" end
      if (bi+bsi)%3 == 2 then col = "#5fe3a8" end
      if bsi == 0 then
        col = "#ff8a1f"
        if bi%3 == 1 then col = "#7b4bd6" end
        if bi%3 == 2 then col = "#5fe3a8" end
      end
      vtri(x-9,y,x+9,y,x,y+20,col)
    end
  end
end

drawFog = function()
  screen.setAlpha(0.07)
  for fgi=0 to 3
    voval((G.t*0.4+fgi*220)%900-100,470+fgi*28,320,60,"#c9b8ff")
  end
  screen.setAlpha(1)
end

drawGate = function()
  wgrad(0,430,12,6,36,60,30,100,12)
  for sti=0 to 12
    vtwinkle((sti*59)%720,(sti*37)%200+10,3)
  end
  voval(150,100,56,56,"#ffe9a8")
  glow(150,100,50,"#ffe9a8")
  wgrad(430,210,38,26,62,20,14,40,8)
  vrect(150,160,40,300,"#2a1850")
  vrect(530,160,40,300,"#2a1850")
  vorr(120,110,480,70,14,"#4a2a8a")
  vtxtC("HOLLOW HILL",360,135,22,C_GOLD)
  vtxtC("HALLOWEEN FESTIVAL",360,162,13,C_ORANGE)
  lantern(190,200,"#ff8a1f",true)
  lantern(530,200,"#ff8a1f",true)
  vpumpkin(100,470,34)
  vpumpkin(620,480,34)
  vweb(0,0,1,1,160)
  ghoulFig(560,430,34,"#4a2a8a")
  // ID card is now positioned directly in the guard's left hand
  vrrect(517,401,25,18,3,C_CREAM)
  vtxtC("ID",529.5,411,7,"#2a1a3a")
  if not C3.got.cd0 then sweet("swirl",100,540,14) end
  drawFog()
end

drawSquare = function()
  wgrad(0,430,16,8,44,70,34,110,14)
  for sti=0 to 15
    vtwinkle((sti*47)%720,(sti*29)%170+10,3)
  end
  glow(620,95,50,"#ffe9a8")
  voval(620,95,56,56,"#ffe9a8")
  vrect(0,330,720,100,"#150a2e")
  vrect(330,110,60,230,"#1d1040")
  vtri(322,112,398,112,360,60,"#2a1456")
  voval(360,160,40,40,"#fff3b0")
  vring(360,160,40,40,2,"#8a6a2a")
  vseg(360,160,358,142,2,"#222222")
  vseg(360,160,349,168,1.5,"#222222")
  vrect(348,200,24,40,"#0a0518")
  voval(360,216,16,18,C_GOLD)
  wgrad(430,210,40,28,70,22,14,44,8)
  for gri=0 to 5
    vrect(0,440+gri*34,720,2,"#2a1a50")
  end
  drawBunting(150)
  // candy stall
  vtri(50,300,210,300,130,262,C_PINK)
  for asi=0 to 7
    local ac = C_CREAM
    if asi%2 == 0 then ac = C_PINK end
    vrect(60+asi*18,300,18,22,ac)
  end
  // candy-stall support legs 鈥� thin sides, matching the original stand reference
  vrect(56,300,5,86,C_CREAM)
  vrect(199,300,5,86,C_CREAM)
  vorr(60,360,140,46,6,"#8a4a2a")
  local kinds = ["gum","swirl","pop","corn","wrap","bad"]
  for jsi=0 to 5
    vrrect(76+jsi*22-9,336,18,22,4,"#cfe8ff")
    sweet(kinds[jsi],76+jsi*22,348,8)
  end
  vtxtC("SWEETS",130,383,10,C_GOLD)
  // lantern pole
  vrect(238,270,5,150,"#3a2a40")
  lantern(240,285,"#5fe3a8",C3.f.lan1)
  lantern(240,320,"#ff8a1f",C3.f.lan2)
  lantern(240,355,"#b07bff",C3.f.lan3)
  // fortune tent
  vtri(300,372,470,372,385,296,"#7b4bd6")
  vrect(315,372,140,48,"#4a2a8a")
  vtri(360,420,410,420,385,380,"#150a2e")
  vtwinkle(385,325,6)
  vtxtC("FORTUNE",385,364,9,C_GOLD)
  // HQ trailer
  vrrect(480,378,78,42,8,"#c0c8d8")
  vrect(490,386,22,16,"#3a5a8a")
  vrect(520,386,28,32,"#6b3b1f")
  voval(496,424,12,12,"#222222")
  voval(540,424,12,12,"#222222")
  vtxtC("HQ",500,372,9,C_GOLD)
  // curio shop
  vorr(580,330,130,90,6,"#3a2a5a")
  vrect(620,352,40,68,"#6b3b1f")
  vrect(590,350,24,24,"#ffd36b")
  vtxtC("ODDS & ENDS",645,322,8,C_GOLD)
  // chest
  vorr(120,478,60,34,6,"#8a5a2a")
  if C3.f.chest then
    vtri(120,478,180,478,150,446,"#6b3b1f")
    glow(150,480,24,C_GOLD)
  else
    vrrect(120,462,60,22,8,"#6b3b1f")
    voval(150,484,8,8,C_GOLD)
  end
  vtri(8,430,38,408,38,452,C_MINT)
  vtxtC("LOT",24,462,8,C_MINT)
  // crowd
  if not C3.got.cd1 then sweet("gum",100,545,13) end
  if not C3.got.cd2 then sweet("pop",470,548,13) end
  if not C3.got.cd3 then sweet("corn",670,515,13) end
  drawFog()
end

drawShop = function()
  wgrad(0,640,40,26,60,74,44,40,12)
  vrect(0,420,720,220,"#4a2e22")
  for pli=0 to 8
    vrect(0,430+pli*24,720,2,"#2a1810")
  end
  vrect(60,200,600,10,"#8a5a2a")
  vrect(60,300,600,10,"#8a5a2a")
  // shelf items
  voval(130,188,50,26,C_GOLD)
  vrrect(200,168,34,34,4,"#e87aa0")
  vtxtC("Spells",217,185,7,"#fff1d6")
  voval(300,184,34,34,"#cfe8ff")
  vrect(288,198,24,6,"#4a2a8a")
  vrect(400,166,12,34,"#cfe8ff")
  voval(406,196,34,34,"#2f9ae0")
  vseg(500,170,560,200,4,"#8a5a2a")
  voval(150,286,40,40,"#ff8a1f")
  voval(360,290,30,30,"#9ad48a")
  vrrect(450,262,50,34,4,"#2a6a4a")
  vseg(560,260,620,300,5,"#6b3b1f")
  vseg(572,290,592,270,4,"#2a1a10")
  vrrect(60,360,180,60,6,"#6b3b1f")
  vorr(250,372,220,48,8,"#8a5a2a")
  vorr(100,100,130,60,6,"#2a1a10")
  vtxtC("PRICES",165,118,11,C_GOLD)
  vtxtC("Take a look,",165,140,9,"#fff1d6")
  // wizard
  vtri(320,420,400,420,360,310,"#3a2f8a")
  voval(360,296,40,40,"#f2c9a4")
  vrect(334,282,52,8,"#3a2f8a")
  vtri(338,284,382,284,360,230,"#3a2f8a")
  vtwinkle(360,260,5)
  vorr(30,330,56,100,5,"#6b3b1f")
  vtxtC("EXIT",58,322,8,C_GOLD)
  // crystal ball 鈥� no extra triangle beside/below it
  vrrect(520,388,70,40,6,"#7b4bd6")
  voval(555,376,44,44,"#cfe8ff")
  glow(555,376,22,"#cfe8ff")
  if not C3.got.cd4 then sweet("wrap",620,520,13) end
end

drawTent = function()
  wgrad(0,640,40,16,76,16,8,36,12)
  vtri(0,0,360,0,0,300,"#4a1a8a")
  vtri(360,0,720,0,720,300,"#4a1a8a")
  for sti=0 to 10
    vtwinkle((sti*67)%720,(sti*41)%260+20,3)
  end
  vorr(30,330,56,100,5,"#6b3b1f")
  vtxtC("EXIT",58,322,8,C_GOLD)
  vrect(0,430,720,210,"#2a1048")
  voval(360,500,380,110,"#5a2a8a")
  vring(360,500,340,90,2,C_GOLD)
  witchFig(360,380,40,"#7a1a8a","#ff5fa2",false)
  voval(260,470,60,60,"#150a2e")
  glow(360,470,30,"#9fe8ff")
  voval(360,470,40,40,"#cfe8ff")
  local fog = (not C3.worn) or C3.blurT > 0
  for tci=0 to 3
    local cx = 250 + tci*80
    vrrect(cx-24,456,48,68,6,"#fff1d6")
    vrrect(cx-20,460,40,60,4,"#4a2a8a")
    if fog then
      vtxtC("????",cx,492,9,"#9a8ac0")
    else
      vtxtC(c3Cards[tci],cx,492,8,C_GOLD)
      if tci == 2 then vtwinkle(cx,468,5) end
    end
  end
  if not C3.got.cd6 then sweet("swirl",650,520,13) end
end

drawLot = function()
  wgrad(0,420,6,4,24,24,16,56,10)
  voval(120,90,50,50,"#e8e0c0")
  vrect(0,300,720,120,"#150a2e")
  for fei=0 to 20
    vrect(fei*36,330,6,80,"#3a2a40")
  end
  vrect(0,350,720,6,"#3a2a40")
  wgrad(420,220,32,24,48,16,12,30,8)
  vrect(0,424,720,6,"#150d28")
  vorr(420,300,220,130,6,"#3a3a52")
  vrect(560,340,60,90,"#0a0518")
  if C3.f.web then
    vrrect(575,390,36,28,4,"#8a8a9a")
    voval(585,380,6,6,"#ffd36b")
    voval(600,380,6,6,"#5fe3a8")
    vrect(580,396,26,10,"#fff1d6")
    vseg(560,360,500,440,2,"#222222")
  else
    vweb(560,340,-1,1,90)
    vweb(560,430,-1,-1,70)
  end
  vorr(160,430,70,50,6,"#6b3b1f")
  vorr(260,440,60,40,6,"#7a4a2a")
  vorr(340,436,70,44,6,"#6b3b1f")
  vpumpkin(70,520,26)
  if not C3.f.gus then
    ghoulFig(195,435,24,"#4a2a8a")
    vtxtC("zzz",215,380+sin(G.t*0.08)*4,10,"#d9c8ff")
  else
    ghoulFig(110,470,24,"#4a2a8a")
  end
  vtri(8,430,38,408,38,452,C_MINT)
  vtxtC("BACK",24,462,8,C_MINT)
  if not C3.got.cd5 then sweet("gum",90,552,13) end
end

drawHQ = function()
  wgrad(0,640,52,46,86,28,22,52,12)
  vorr(40,70,200,200,8,"#16225e")
  voval(180,130,40,40,"#fff0b0")
  // window wires 鈥� aligned directly through the lanterns
  vseg(40,176,240,296,2,"#1a1030")
  vseg(40,186,240,306,2,"#1a1030")
  lantern(80,200,"#ff8a1f",true)
  lantern(130,240,"#b07bff",true)
  vrect(138,70,5,200,"#6a5a9a")
  vorr(300,60,200,140,6,"#b8864e")
  vrect(308,68,184,124,"#d9a45a")
  vrect(320,80,40,34,C_CREAM)
  vrect(375,76,36,28,"#ffe58a")
  vrect(430,86,50,36,C_CREAM)
  vseg(340,96,392,90,1.5,"#d62e2e")
  vseg(392,90,455,104,1.5,"#d62e2e")
  vrect(330,134,36,40,"#cfe8ff")
  vtxtC("EVIDENCE",400,150,8,"#8a2a1a")
  badge(570,130,22)
  wgrad(430,210,92,58,40,56,34,26,8)
  vrect(0,425,720,8,"#2a1a30")
  vorr(40,330,56,100,5,"#6b3b1f")
  vtxtC("EXIT",68,322,8,C_GOLD)
  vorr(200,330,420,24,5,"#9a6a3a")
  vrect(220,354,22,100,"#6b4524")
  vrect(580,354,22,100,"#6b4524")
  vrrect(320,262,80,56,4,"#2b2b3c")
  vrect(326,268,68,44,"#3a5a8a")
  if C3.f.wifi then vtxtC("WIFI OK",360,290,8,C_MINT) else vtxtC("NO WIFI",360,290,8,C_PINK) end
  vrect(310,320,100,8,"#4a4a5c")
  if C3.f.usbPlug then vrrect(414,318,16,8,2,"#222222") end
  if C3.f.printerPlaced then
    vrrect(520,300,70,46,6,"#8a8a9a")
    vrect(530,284,50,22,"#fff1d6")
    if C3.f.printed then vrect(536,290,38,10,C_GOLD) end
  else
    vring(555,326,70,30,2,C_GOLD)
    vtxtC("PRINTER",555,326,7,C_GOLD)
  end
  vrrect(450,305,22,20,3,"#f3d9a0")
  if not C3.got.cd7 then sweet("corn",110,540,13) end
end

// ---------- hotspots ----------
c3Spots = function()
  local L = []
  local r = C3.room
  if r == "gate" then
    L.push(["guard",560,420,50])
    L.push(["cd0",100,540,16])
  elsif r == "square" then
    L.push(["stall",130,385,50])
    for ssi=0 to 5
      L.push(["j"+ssi,76+ssi*22,348,10])
    end
    L.push(["lan1",240,285,14])
    L.push(["lan2",240,320,14])
    L.push(["lan3",240,355,14])
    L.push(["chest",150,485,34])
    L.push(["tent",385,395,50])
    L.push(["hq",515,398,40])
    L.push(["shop",645,385,45])
    L.push(["lot",24,430,34])
    L.push(["bell",360,285,36])
    L.push(["ghoulA",430,490,30])
    L.push(["ghostB",560,505,32])
    L.push(["cd1",100,545,16])
    L.push(["cd2",470,548,16])
    L.push(["cd3",670,515,16])
  elsif r == "shop" then
    L.push(["wizard",360,340,55])
    L.push(["exit",58,380,45])
    L.push(["crystal",555,385,34])
    L.push(["book",217,185,24])
    L.push(["cd4",620,520,16])
  elsif r == "tent" then
    L.push(["psy",360,340,60])
    L.push(["exit",58,380,45])
    for tki=0 to 3
      L.push(["card"+tki,250+tki*80,490,34])
    end
    L.push(["cd6",650,520,16])
  elsif r == "lot" then
    L.push(["back",24,430,34])
    L.push(["gus",195,420,40])
    L.push(["web",545,390,50])
    L.push(["router",590,395,30])
    if not C3.f.usb then L.push(["usbspot",330,415,26]) end
    L.push(["cd5",90,552,16])
  else
    L.push(["exit",68,380,45])
    L.push(["laptop",360,290,45])
    L.push(["printer",555,320,45])
    L.push(["board",400,130,70])
    L.push(["cd7",110,540,16])
  end
  return L
end

c3Targets = function()
  local T = []
  if C3.room == "square" then T.push(["bunting",200,185]) end
  if C3.room == "lot" and C3.f.web then T.push(["label",590,395]) end
  return T
end

// ---------- dialogue / notes / helpers ----------
c3Say = function(list,fn)
  dlgStart(list,fn)
  C3.mode = "dlg"
end

c3Note = function(t)
  if C3.notes.indexOf(t) < 0 then
    C3.notes.push(t)
    say("New note saved on your phone.")
  end
end

c3Give = function(id)
  C3.inv[id] = true
  c2sfx("pick")
end

c3Go = function(room,cx)
  C3.room = room
  C2.cx = cx
  C2.cy = 320
  C2.z = 1.1
  C3.sel = ""
end

c3Time = function()
  local m = floor(C3.hint/3600)
  local s = floor((C3.hint%3600)/60)
  local ss = "" + s
  if s < 10 then ss = "0" + s end
  return m + ":" + ss
end

c3HintText = function()
  local f = C3.f
  if not f.gate then return "The gate guard wants your badge number. Your ID is in the phone." end
  if not f.photoB then return "Your phone has a camera. Those flags keep repeating..." end
  if not f.lit then return "Search the web for the old lantern custom, then light the three lanterns." end
  if not f.chest then return "The chest near the front has a secret." end
  if not C3.inv.glasses then return "Fortune-teller cards are tiny. Where can a detective buy glasses?" end
  if not f.tarot then return "Wear the glasses in Madame Velour's tent and order her riddle." end
  if not f.gus then return "Gus sleeps in the back lot. He needs something hot and strong." end
  if not f.web then return "Those webs need something sharp." end
  if not f.usb then return "In the dark lot, the phone scanner bar peaks near hidden things." end
  if not f.wifi then return "Router label photo plus the chest note give you the Wi-Fi." end
  if not f.dec then return "Binary: each group of four bits is one digit (8 4 2 1)." end
  if not f.printed then return "Place the printer in HQ, then print from the laptop." end
  return "Show the pass at the Bell Tower, then accuse who ran the festival's sugar."
end

c3Exit = function()
  storage.set("c3hint", C3.hint+1)
  C3.on = false
  go("chapters")
end

// ---------- item use ----------
c3Use = function(item,id)
  local f = C3.f
  local ok = false
  if item == "coffee" and id == "gus" then
    ok = true
    C3.inv.coffee = false
    f.gus = true
    c3Say([["You","smug","Fresh takeout coffee. Black, hot, strong."],["Gus","","Mmmgh... FINALLY. Go on, the shed is back there. Mind the webs."]],null)
  elsif item == "sword" and id == "web" then
    if not f.gus then
      say("Gus is blocking the path to the shed.")
      ok = true
    else
      ok = true
      f.web = true
      c2sfx("good")
      say("Swish! The cursed webs fall. A router blinks inside the shed.")
    end
  elsif item == "printer" and id == "printer" then
    ok = true
    C3.inv.printer = false
    f.printerPlaced = true
    c2sfx("good")
    say("Printer set up. It needs Wi-Fi before it works.")
  elsif item == "usb" and id == "laptop" then
    ok = true
    C3.inv.usb = false
    f.usbPlug = true
    c2sfx("good")
    say("USB plugged in. Open the terminal.")
  elsif item == "pass" and id == "bell" then
    c3Act("bell")
    ok = true
  end
  if ok then
    C3.sel = ""
  else
    say("That doesn't work here.")
    c2sfx("bad")
  end
end

// ---------- hotspot actions ----------
c3Act = function(id)
  local f = C3.f
  c2sfx("tap")
  local c = id.substring(0,2)
  if c == "cd" then
    if not C3.got[id] then
      C3.got[id] = true
      addCandy(3)
      saveGame()
      c2sfx("pick")
      say("+3 candies!")
    end
    return
  end
  if id == "guard" then
    if f.gate then
      say("The guard nods. 'Enjoy the festival.'")
    else
      c3Say([["Guard","","Badge. Number only, no dashes. I'm not letting just anyone in tonight."],["You","think","My ID is on my phone. Tap the folder icon, then ID."]], function()
        c3KeyOpen("BADGE NUMBER","478821",function()
          C3.f.gate = true
          c2AddXP(10)
          c2sfx("good")
          c3Go("square",360)
          c3Say([["You","shock","Whoa. The whole festival is... wrong. Nobody here is breathing."],["You","think","Lanterns, flags, a bell tower stuck at 11:52. I need to look at everything."]],null)
        end,"play")
      end)
    end
  elsif id == "stall" then
    say("Mr. Gumdrop's sweets. Tap a jar to inspect it.")
  elsif id.substring(0,1) == "j" and id.length == 2 then
    local ji = id.substring(1,2)
    if f.poison then
      say("Mr. Gumdrop watches you. 'Anything else, dear?'")
    elsif ji == "5" then
      f.poison = true
      c3Give("poison")
      c2AddXP(20)
      c3Note("POISON: purple stripes + gold star seal. Sold only from Mr. Gumdrop's jars.")
      c3Say([["You","shock","Purple stripes. Gold star seal. This is the cursed candy."],["You","worry","I can smell something bitter under the sugar. Evidence."]],null)
    elsif ji == "4" then
      say("Mint-and-purple wrapper. Sweet, but not cursed. Plain.")
    else
      if f.web3 then
        say("Looks normal. Not the one with purple stripes and a gold star.")
      else
        C3.blurT = 1500
        c3Say([["You","worry","I nibbled it... my eyes swim. Everything is blurry!"],["You","think","Maybe the shop sells glasses. Next time, search before tasting."]],null)
      end
    end
  elsif id == "lan1" or id == "lan2" or id == "lan3" then
    if f.lit then
      say("The lanterns glow steadily.")
    else
      C3.lanSeq.push(id)
      f[id] = true
      c2sfx("pick")
      local want = ["lan2","lan3","lan1"]
      local li = C3.lanSeq.length-1
      if C3.lanSeq[li] != want[li] then
        C3.lanSeq = []
        f.lan1 = false
        f.lan2 = false
        f.lan3 = false
        c2sfx("bad")
        say("Wrong order. A cold wind snuffs every lantern.")
      elsif C3.lanSeq.length == 3 then
        f.lit = true
        c2AddXP(20)
        c2sfx("good")
        say("The ritual lights! Something clicks near the front.")
      end
    end
  elsif id == "chest" then
    if f.chest then
      say("Empty now.")
    elsif not f.lit then
      say("Locked tight. Even the keyhole is cursed. Maybe the lanterns?")
    else
      f.chest = true
      addCandy(20)
      saveGame()
      c3Note("CHEST NOTE: Wi-Fi password is the festival date: month then day, 1031.")
      c2AddXP(20)
      c2sfx("good")
      say("The chest creaks open: +20 candies and a note!")
    end
  elsif id == "tent" then
    c3Go("tent",360)
    if not C3.worn and not f.tentSaid then
      f.tentSaid = true
      c3Say([["You","worry","Ugh... everything in here is smeared. I can't read a thing."],["You","think","Maybe I need glasses. Is there a shop out there?"]],null)
    end
  elsif id == "shop" then
    c3Go("shop",360)
  elsif id == "hq" then
    c3Go("hq",360)
  elsif id == "lot" then
    c3Go("lot",300)
    if not f.lotSaid then
      f.lotSaid = true
      c3Say([["You","think","Pitch dark back here. Hold your finger down to use the flashlight."],["You","think","My phone has a scanner. Use it where signals hide."]],null)
    end
  elsif id == "bell" then
    if f.printed then
      c3Say([["You","smug","Pass in hand. Time to find out who's been ringing this bell."]], function()
        C3.mode = "accuse"
      end)
    else
      say("Locked bell tower. A printed pass is needed.")
    end
  elsif id == "ghoulA" then
    if not f.ghoulA then
      f.ghoulA = true
      c3Say([["Ghoul","","Flags tell lanterns their order, little detective."],["Ghoul","","And never trust sweets in purple stripes."]], function()
        say("Your phone has new things to search.")
      end)
    else
      say("The ghoul hums a tune that makes your teeth hurt.")
    end
  elsif id == "ghostB" then
    c3Say([["Ghost","","Madame Velour only reads for those who see clearly..."],["Ghost","","Fix your eyes first, living one."]],null)
  elsif id == "exit" or id == "back" then
    if C3.room == "lot" then
      c3Go("square",120)
    else
      c3Go("square",360)
    end
  elsif id == "wizard" then
    C3.mode = "shop"
  elsif id == "crystal" then
    say("A crystal ball. It shows your own worried face.")
  elsif id == "book" then
    say("SPELLS: 'Never rub a lamp you can't afford to lose.'")
  elsif c == "ca" then
    c3Card(["0","1","2","3"].indexOf(id.substring(4,5)))
  elsif id == "psy" then
    if not f.psy then
      f.psy = true
      c3Note("TAROT RIDDLE: The Tower fell before the Moon rose. The Sun came first of all. The Star keeps the last watch.")
      c3Say([["Madame Velour","","I knew you'd come. The cards are scattered, and the order matters."],["Madame Velour","","The Tower fell before the Moon rose. The Sun came first of all. The Star keeps the last watch."],["You","think","I should write that down. It's saved in my phone notes."]],null)
    elsif f.tarot then
      say("Madame Velour smiles. 'The lamp serves you well.'")
    else
      say("Madame Velour: 'Order the four cards, detective.'")
    end
  elsif id == "gus" then
    if f.gus then
      say("Gus yawns. 'Go on, I'm awake.'")
    else
      c3Say([["You","think","Gus is sound asleep on the only path. He needs something hot and strong."]],null)
    end
  elsif id == "web" then
    if f.web then say("The webs lie in ribbons.") else say("Thick cursed webs. Something sharp would cut them.") end
  elsif id == "router" then
    say("Router label: HOLLOW-FEST. Password line is scratched out.")
  elsif id == "usbspot" then
    f.usb = true
    c3Give("usb")
    c2AddXP(20)
    c3Note("USB found under the crate. File: BELL_PASS.dat")
    c3Say([["You","shock","A USB stick tucked under the crate. The scanner was right."]],null)
  elsif id == "laptop" then
    if C3.sel == "" then C3.mode = "hack" end
  elsif id == "printer" then
    if f.printerPlaced then say("Printer ready.") else say("An empty spot. Select the printer from your items, then tap here.") end
  elsif id == "board" then
    say("Case board: the bell, the candy, the gold star seal.")
  end
end

c3Card = function(idx)
  local f = C3.f
  if f.tarot then return end
  if (not C3.worn) or C3.blurT > 0 then
    c3Say([["You","worry","I can't read the card. Everything is smeared. I need glasses."]],null)
    return
  end
  C3.seq.push(idx)
  c2sfx("pick")
  local si = C3.seq.length-1
  if C3.seq[si] != c3Ans[si] then
    C3.seq = []
    c2sfx("bad")
    say("The cards go dark. Start again.")
  elsif C3.seq.length == 4 then
    f.tarot = true
    c3Give("lamp")
    c2AddXP(30)
    c2sfx("good")
    c3Say([["Madame Velour","","Correct. Take this lamp. Rub it only when you must."],["You","think","One rub, one answer. I should save it."]],null)
  end
end

// ---------- keypad ----------
c3KeyOpen = function(title,ans,fn,back)
  C3.keyTitle = title
  C3.keyAns = ans
  C3.keyFn = fn
  C3.keyBack = back
  C3.code = ""
  C3.mode = "key"
end

c3Key = function()
  vrect(0,0,360,640,C_INK)
  vorr(30,100,300,440,14,C_DEEP)
  vtxtC(C3.keyTitle,180,130,11,C_GOLD)
  local shown = C3.code
  while shown.length < C3.keyAns.length
    shown = shown + "_"
  end
  vtxtC(shown,180,185,28,C_MINT)
  local labels = ["1","2","3","4","5","6","7","8","9","CLR","0","OK"]
  for kpi=0 to 11
    local bx = 48 + (kpi%3)*88
    local yy = 225 + floor(kpi/3)*62
    if vbtn(labels[kpi],bx,yy,80,50,C_PURPLE2,C_PURPLE,18) then
      c2sfx("tap")
      local l = labels[kpi]
      if l == "CLR" then
        C3.code = ""
      elsif l == "OK" then
        if C3.code == C3.keyAns then
          C3.mode = C3.keyBack
          local fn = C3.keyFn
          fn()
        else
          c2sfx("bad")
          C3.code = ""
        end
      elsif C3.code.length < C3.keyAns.length then
        C3.code = C3.code + l
      end
    end
  end
  if vibtn("x",312,116,12) then
    C3.mode = C3.keyBack
  end
end

// ---------- shop ----------
c3ShopUI = function()
  vrect(0,0,360,640,C_INK)
  vtxtC("ODDS & ENDS",180,40,20,C_GOLD)
  vtxtC("Candies: "+G.candy,180,72,14,"#fff7e6")
  for shi=0 to 3
    local it = c3Shop[shi]
    local yy = 110+shi*96
    vorr(16,yy,328,84,10,C_DEEP)
    itemIcon(it[0],52,yy+42,30)
    vtxtL(it[1],90,yy+26,13,C_CREAM)
    vtxtL(it[2]+" candies",90,yy+52,11,C_GOLD)
    if C3.inv[it[0]] or (it[0] == "printer" and C3.f.printerPlaced) then
      vtxtC("OWNED",290,yy+42,11,C_MINT)
    elsif vbtn("BUY",246,yy+26,84,34,C_MINT,"#2a9a6a",14) then
      c3Buy(shi)
    end
  end
  if vbtn("LEAVE",110,520,140,44,C_ORANGE,C_ORANGE2,16) then
    C3.mode = "play"
  end
end

c3Buy = function(i)
  local it = c3Shop[i]
  if G.candy < it[2] then
    say("Not enough candies.")
    c2sfx("bad")
    return
  end
  G.candy -= it[2]
  saveGame()
  c3Give(it[0])
  if it[0] == "glasses" then
    C3.worn = true
    say("Bought glasses and put them on. Everything is crisp now.")
  else
    say("Bought: "+it[1])
  end
end

// ---------- phone ----------
c3Phone = function()
  vrect(0,0,360,640,C_INK)
  vrect(0,0,360,56,C_DEEP)
  vtxtL("PHONE",14,28,16,C_GOLD)
  if vibtn("x",326,28,13) then
    C3.mode = "play"
    c2sfx("tap")
  end
  local names = ["CAM","WEB","NOTES","ID","SCAN"]
  for pti=0 to 4
    local col = C_PURPLE
    if C3.app == pti then col = C_ORANGE end
    if vbtn(names[pti],6+pti*70,66,66,32,col,C_DEEP,11) then
      C3.app = pti
      c2sfx("tap")
    end
  end
  local f = C3.f
  if C3.app == 0 then
    vtxtC("CAMERA",180,130,15,C_GOLD)
    local t = vwrap("Close the phone and press the shutter with something in the center frame. Photos: "+C3.photos,300,13)
    for ci=0 to t.length-1
      vtxtL(t[ci],30,170+ci*22,13,"#fff7e6")
    end
    if vbtn("OPEN CAMERA",90,300,180,48,C_MINT,"#2a9a6a",15) then
      C3.mode = "cam"
    end
  elsif C3.app == 1 then
    vtxtC("HOLLOW SEARCH",180,126,15,C_GOLD)
    local yy = 150
    for wci=0 to c3Web.length-1
      local w = c3Web[wci]
      local open = true
      if w[1] != "" then
        open = C3.f[w[1]] == true
      end
      if open then
        if vbtn(w[0],20,yy,320,30,C_PURPLE2,C_PURPLE,11) then
          C3.web = wci
          c2sfx("tap")
          if wci == 2 then C3.f.web3 = true end
        end
        yy += 38
      end
    end
    if C3.web >= 0 then
      local t = vwrap(c3Web[C3.web][2],300,12)
      for ri=0 to t.length-1
        vtxtL(t[ri],30,yy+14+ri*20,12,C_CREAM)
      end
    end
  elsif C3.app == 2 then
    vtxtC("NOTES",180,126,15,C_GOLD)
    local ny = 150
    if C3.notes.length == 0 then vtxtC("(empty)",180,200,13,"#9a8ac0") end
    for nli=0 to C3.notes.length-1
      local t = vwrap("- "+C3.notes[nli],310,11)
      for ni=0 to t.length-1
        vtxtL(t[ni],24,ny,11,"#fff7e6")
        ny += 17
      end
      ny += 6
    end
  elsif C3.app == 3 then
    vorr(30,140,300,200,12,"#b8d0e8")
    vrect(30,140,300,36,"#1e4a78")
    vtxtL("DETECTIVE ID",44,158,13,"#ffffff")
    vrect(46,190,70,86,"#8aa8c8")
    vbust("You",81,262,0.55)
    vtxtL(c2RK[c2rank()][0],130,198,13,"#16304a")
    vtxtL("BADGE 47-88-21",130,224,13,"#16304a")
    vtxtL("XP "+c2xp(),130,250,12,"#16304a")
    badge(300,300,18)
    for bci=0 to 22
      vrect(46+bci*10,310,5+(bci%3),20,"#16304a")
    end
  else
    vtxtC("SIGNAL SCANNER",180,126,15,C_GOLD)
    vorr(70,160,220,220,110,"#0a2a3a")
    vring(180,270,200,200,2,C_MINT)
    vring(180,270,130,130,2,C_MINT)
    vring(180,270,60,60,2,C_MINT)
    vseg(180,270,180+cos(G.t*0.05)*100,270+sin(G.t*0.05)*100,3,C_MINT)
    local t = vwrap("In dark areas the SIGNAL bar at the bottom shows how close you are to something hidden. Slide the flashlight around.",300,12)
    for si=0 to t.length-1
      vtxtL(t[si],30,410+si*18,12,"#fff7e6")
    end
  end
end

// ---------- camera ----------
c3Cam = function()
  vseg(110,230,110,260,3,"#ffffff")
  vseg(110,230,140,230,3,"#ffffff")
  vseg(250,230,220,230,3,"#ffffff")
  vseg(250,230,250,260,3,"#ffffff")
  vseg(110,410,110,380,3,"#ffffff")
  vseg(110,410,140,410,3,"#ffffff")
  vseg(250,410,220,410,3,"#ffffff")
  vseg(250,410,250,380,3,"#ffffff")
  vtxtC("Aim the frame, then SNAP",180,200,12,"#ffffff")
  if vbtn("SNAP",130,540,100,44,C_PINK,"#a02a6a",18) then
    c3Snap()
  end
  if vbtn("CLOSE",20,540,80,44,C_PURPLE,C_DEEP,13) then
    C3.mode = "play"
  end
end

c3Snap = function()
  local T = c3Targets()
  local hit = ""
  for tgi=0 to T.length-1
    local sx = (T[tgi][1]-C2.cx)*C2.z + 180
    local sy = (T[tgi][2]-C2.cy)*C2.z + 320
    if abs(sx-180) < 70 and abs(sy-320) < 90 then hit = T[tgi][0] end
  end
  C3.flash = 8
  c2sfx("pick")
  if hit == "bunting" then
    C3.photos += 1
    C3.f.photoB = true
    c2AddXP(10)
    c3Note("PHOTO: bunting flags repeat ORANGE, PURPLE, GREEN.")
  elsif hit == "label" then
    C3.photos += 1
    c3Note("PHOTO: router label. Network HOLLOW-FEST, password line scratched out.")
  else
    say("Nothing worth a photo here.")
  end
end

// ---------- hack terminal ----------
c3Hack = function()
  local f = C3.f
  vrect(0,0,360,640,"#04140c")
  vtxtC("TERMINAL",180,40,18,"#5fe38a")
  for hsi=0 to 3
    local v = "no"
    if hsi == 0 and f.wifi then v = "connected" end
    if hsi == 1 and f.mount then v = "mounted" end
    if hsi == 2 and f.dec then v = "decrypted" end
    if hsi == 3 and f.printed then v = "done" end
    local lab = ["WIFI","USB","FILE","PRINT"]
    vtxtL(lab[hsi]+": "+v,30,86+hsi*26,13,"#5fe38a")
  end
  if vbtn("CONNECT WIFI",40,200,280,44,"#1a6a3a","#0a3a1a",14) then
    if f.wifi then
      say("Already connected to HOLLOW-FEST.")
    else
      c3KeyOpen("WIFI PASSWORD","1031",function()
        C3.f.wifi = true
        c2sfx("good")
        say("Connected to HOLLOW-FEST.")
      end,"hack")
    end
  end
  if vbtn("MOUNT USB",40,256,280,44,"#1a6a3a","#0a3a1a",14) then
    if not f.usbPlug then
      say("No USB plugged in. Select the USB stick, then tap the laptop.")
    elsif f.mount then
      say("BELL_PASS.dat is already mounted.")
    else
      f.mount = true
      c2sfx("good")
      c3Note("File BELL_PASS.dat: encrypted bits 0110 0100 0010 0111")
      say("Found BELL_PASS.dat. It's encrypted.")
    end
  end
  if vbtn("DECRYPT FILE",40,312,280,44,"#1a6a3a","#0a3a1a",14) then
    if not f.mount then
      say("Nothing to decrypt yet.")
    elsif f.dec then
      say("Already decrypted.")
    else
      c3KeyOpen("0110 0100 0010 0111  ->  4 digits","6427",function()
        C3.f.dec = true
        c2AddXP(30)
        c2sfx("good")
        say("Decrypted: a Bell Tower pass, ready to print.")
      end,"hack")
    end
  end
  if vbtn("PRINT PASS",40,368,280,44,"#1a6a3a","#0a3a1a",14) then
    if not f.dec then
      say("Nothing to print.")
    elsif not f.printerPlaced then
      say("No printer set up in HQ.")
    elsif not f.wifi then
      say("Printer offline: it needs Wi-Fi.")
    elsif f.printed then
      say("Already printed.")
    else
      f.printed = true
      c3Give("pass")
      c2AddXP(30)
      c3Note("PASS printed. Signed: M. Gumdrop, Bell Keeper.")
      say("Printed! A Bell Tower pass signed by M. Gumdrop.")
    end
  end
  if vbtn("CLOSE",110,560,140,44,C_PURPLE,C_DEEP,14) then
    C3.mode = "play"
  end
end

// ---------- accusation / end ----------
c3Accuse = function()
  vrect(0,0,360,640,C_INK)
  vtxtC("WHO RAN THE SWEET TOLL?",180,44,17,C_GOLD)
  local n = ""
  local frm = max(0,C3.notes.length-5)
  for ani=frm to C3.notes.length-1
    n = n + C3.notes[ani] + "|"
  end
  local t = vwrap(n,310,10)
  for ti=0 to min(t.length-1,17)
    vtxtL(t[ti],24,80+ti*15,10,"#d9c8ff")
  end
  local names = ["Old Pip, the shopkeeper","Madame Velour, the psychic","Mr. Gumdrop, the candy stall","Gus, the night watchman"]
  for ci=0 to 3
    if vbtn(names[ci],24,380+ci*54,312,44,C_PURPLE2,C_PURPLE,12) then
      if ci == 2 then
        c3Finish()
      else
        c2sfx("bad")
        say("That doesn't fit the evidence. Look at the wrapper and the pass again.")
      end
    end
  end
end

c3Finish = function()
  C3.f.done = true
  storage.set("ch3done",1)
  c2AddXP(60)
  c2sfx("good")
  C3.mode = "end"
end

c3End = function()
  vrect(0,0,360,640,C_INK)
  badge(180,120,40)
  vtxtC("THE SWEET TOLL STOPS",180,220,18,C_ORANGE)
  vtxtC("Mr. Gumdrop sweetened the festival",180,252,11,"#fff7e6")
  vtxtC("with cursed sugar. But he whispered:",180,270,11,"#fff7e6")
  vtxtC("'The sugar knows your name...'",180,296,13,C_PINK)
  vtxtC("Rank: "+c2RK[c2rank()][0],180,350,18,C_GOLD)
  vtxtC("XP: "+c2xp(),180,376,13,"#fff7e6")
  vtxtC("Perk: "+c2RK[c2rank()][2],180,400,11,C_MINT)
  cat2(180,480,24,true)
  if vbtn("CONTINUE",100,540,160,48,C_ORANGE,C_ORANGE2,18) then
    c3Exit()
  end
end

// ---------- HUD ----------
c3HUD = function()
  if vibtn("back",24,24,14) then c3Exit() end
  if vibtn("bulb",60,24,14) then
    if C3.hint > 0 then
      say("Hints are locked for "+c3Time()+". Think like a detective.")
    else
      say(c3HintText())
    end
  end
  if vibtn("folder",96,24,14) then
    C3.mode = "phone"
  end
  if vibtn("board",132,24,14) then
    C2.mode = "rank"
    C3.mode = "rank"
  end
  badge(336,26,10)
  if C3.hint > 0 then
    vorr(80,46,200,18,9,C_DEEP)
    vtxtC("HINTS LOCKED  "+c3Time(),180,55,10,C_GOLD)
  end
  if vbtn("+",318,230,34,34,C_ORANGE,C_ORANGE2,20) then C2.z = min(2.6,C2.z+0.35) end
  if vbtn("-",318,274,34,34,C_ORANGE,C_ORANGE2,20) then C2.z = max(1.0,C2.z-0.35) end
  local sx = 8
  for ii=0 to c3Order.length-1
    local id = c3Order[ii]
    if C3.inv[id] then
      local col = C_DEEP
      if C3.sel == id then col = C_ORANGE2 end
      if id == "glasses" and C3.worn then col = C_PURPLE2 end
      vorr(sx,594,38,38,8,col)
      itemIcon(id,sx+19,613,24)
      if tapIn(sx,594,38,38) then
        c2sfx("tap")
        if id == "glasses" then
          C3.worn = not C3.worn
          if C3.worn then say("Glasses on.") else say("Glasses off.") end
        elsif id == "lamp" then
          C3.mode = "rub"
          C3.rub = 0
        elsif C3.sel == id then
          C3.sel = ""
        else
          C3.sel = id
          say("Selected. Tap where to use it.")
        end
      end
      sx += 42
    end
  end
end

c3Rub = function()
  vrect(0,0,360,640,"#0d0620")
  vtxtC("RUB THE LAMP",180,120,18,C_GOLD)
  vtxtC("Drag your finger around the lamp",180,150,11,"#fff7e6")
  glow(180,320,60+C3.rub/40,C_GOLD)
  itemIcon("lamp",180,320,120)
  vorr(60,460,240,16,8,C_DEEP)
  vrect(64,464,min(232,232*C3.rub/1100),8,C_GOLD)
  if vibtn("x",326,28,13) then C3.mode = "play" end
  if C3.rub > 1100 then
    C3.inv.lamp = false
    C3.mode = "play"
    c3Say([["Genie","","One wish, one answer. The timer cannot stop me."],["Genie","",c3HintText()],["You","shock","He's gone. That was my one wish."]],null)
  end
end

// ---------- chapter list (replaces drawChapters in main) ----------
c3ChapTitles = [["The Haunted|Candy Shop"],["The Vanishing|Trick-or-Treater"],["The Cursed|Halloween Festival"],["The Sugar Knows|Your Name"],["Room 13|"],["Last Bus Home|"],["Dead Air|"],["The Birthday Party|"],["Don't Open|The Door"],["The Sweetest|Surprise"]]

c3Chapters = function()
  local W = screen.width
  local H = screen.height
  local k = W/360
  C2.k = k
  drawNight(false)
  screen.setAlpha(0.55)
  rect(0,0,W,H,"#0d0620")
  screen.setAlpha(1)
  local tt = touch.touching
  local py = H/2 - touch.y
  G.chS = G.chS or 0
  G.chTap = false
  if tt then
    if not G.chW then
      G.chD = 0
      G.chL = py
    end
    local dy = py - G.chL
    G.chD += abs(dy)
    if G.chD > 10*k then G.chS -= dy/k end
    G.chL = py
    G.chX = touch.x + W/2
    G.chY = py
  elsif G.chW and G.chD < 10*k then
    G.chTap = true
  end
  G.chW = tt
  G.chS = max(0,min(370,G.chS))
  G.tap = G.chTap
  G.tx = G.chX
  G.ty = G.chY
  local open = [true, c2Unlocked(), storage.get("ch2done") == 1, (storage.get("ch3done") == 1 or C4_FORCE_UNLOCK == 1), false, false, false, false, false, false]
  for ci=0 to 9
    local y = 112 + ci*88 - G.chS
    if y > -90 and y < 650 then
      local col = C_DEEP
      if not open[ci] then col = "#1e1040" end
      vorr(16,y,328,80,12,col)
      vorr(26,y+8,64,64,10,"#2a1a50")
      if open[ci] then
        if ci == 0 then vcandy(58,y+40,12,C_PINK,C_ORANGE) end
        if ci == 1 then cat2(58,y+44,13,true) end
        if ci == 2 then lantern(58,y+42,"#ff8a1f",true) end
        if ci == 3 then c4Sprite("c4_zanji",38,y+20,44,44) end
      else
        vrrect(46,y+36,24,20,4,C_GOLD)
        vring(58,y+34,16,16,3,C_GOLD)
      end
      local tc = C_CREAM
      if not open[ci] then tc = "#7a6aa0" end
      vtxtL("CHAPTER "+(ci+1),104,y+16,10,C_GOLD)
      local ln = c3ChapTitles[ci][0].split("|")
      vtxtL(ln[0],104,y+38,15,tc)
      if ln.length > 1 and ln[1] != "" then vtxtL(ln[1],104,y+58,15,tc) end
      if open[ci] then
        if y > 100 and y < 560 then
          if vbtn("START",252,y+44,80,28,C_MINT,"#2a9a6a",12) then
            if ci == 0 then startChapter1() end
            if ci == 1 then c2Open() end
            if ci == 2 then c3Open() end
            if ci == 3 then c4Open() end
          end
        end
      else
        vtxtL("LOCKED",252,y+62,10,"#7a6aa0")
      end
    end
  end
  vrect(0,0,360,100,"#0d0620")
  if ibtn("back",W*0.09,H*0.055,W*0.055) then go("menu") end
  drawCandyPill()
  txtO("CHOOSE A CASE",W*0.5,H*0.14,W*0.075,"#ffb347",C_INK)
end

// ---------- entry / update / draw ----------
c3Open = function()
  C2.k = screen.width/360
  if storage.get("ch2done") != 1 then
    say("Finish Chapter 2 first!")
    return false
  end
  C3.on = true
  C3.mode = "play"
  C3.room = "gate"
  C3.f = object end
  C3.inv = object end
  C3.got = object end
  C3.notes = []
  C3.seq = []
  C3.lanSeq = []
  C3.sel = ""
  C3.worn = false
  C3.blurT = 0
  C3.app = 0
  C3.web = -1
  C3.photos = 0
  C3.flash = 0
  C3.rub = 0
  C3.t = 0
  C3.was = true
  C3.drag = 99
  C3.lx = 0
  C3.ly = 0
  local h = storage.get("c3hint")
  C3.hint = 108000
  if h and h > 0 then C3.hint = h-1 end
  C2.on = false
  C2.mode = "play"
  C2.cx = 360
  C2.cy = 320
  C2.z = 1.1
  c3Say([["You","worry","Odette's shop is quiet. The trick-or-treater is still missing."],["You","think","A note says the Hollow's next stage is the Halloween Festival. Tonight."],["You","think","Hints are locked for the first 30 minutes of this case. I'll have to solve this the hard way."]],null)
  return true
end

c3Update = function()
  C2.k = screen.width/360
  G.t = (G.t or 0) + 1
  if G.toastT > 0 then G.toastT -= 1 end
  C3.t += 1
  if C3.hint > 0 and C3.mode != "dlg" and C3.mode != "end" then C3.hint -= 1 end
  if C3.t % 180 == 0 then storage.set("c3hint", C3.hint+1) end
  if C3.blurT > 0 then C3.blurT -= 1 end
  if C3.flash > 0 then C3.flash -= 1 end
  c3Music()
  local tt = touch.touching
  local px = (touch.x + screen.width/2)/C2.k
  local py = (screen.height/2 - touch.y)/C2.k
  G.tap = false
  if tt then
    if not C3.was then
      C3.drag = 0
      C3.lx = px
      C3.ly = py
    end
    local dx = px - C3.lx
    local dy = py - C3.ly
    C3.drag += abs(dx)+abs(dy)
    if (C3.mode == "play" or C3.mode == "cam") and C3.drag > 14 then
      C2.cx -= dx/C2.z
      C2.cy -= dy/C2.z
    end
    if C3.mode == "rub" then C3.rub += abs(dx)+abs(dy) end
    C3.lx = px
    C3.ly = py
  elsif C3.was then
    if C3.drag < 14 then
      G.tap = true
      G.tx = C3.lx*C2.k
      G.ty = C3.ly*C2.k
    end
  end
  C3.was = tt
  clampCam()
end

c3Draw = function()
  C2.k = screen.width/360
  local m = C3.mode
  vrect(0,0,360,640,C_INK)
  if m == "phone" then
    c3Phone()
  elsif m == "shop" then
    c3ShopUI()
  elsif m == "key" then
    c3Key()
  elsif m == "hack" then
    c3Hack()
  elsif m == "accuse" then
    c3Accuse()
  elsif m == "end" then
    c3End()
  elsif m == "rank" then
    drawRank()
    if C2.mode == "play" then C3.mode = "play" end
  elsif m == "rub" then
    c3Rub()
  else
    camOn()
    if C3.room == "gate" then
      drawGate()
    elsif C3.room == "square" then
      drawSquare()
    elsif C3.room == "shop" then
      drawShop()
    elsif C3.room == "tent" then
      drawTent()
    elsif C3.room == "lot" then
      drawLot()
    else
      drawHQ()
    end
    camOff()
    if C3.room == "lot" and m != "dlg" then
      local R = 70
      if c2rank() >= 2 then R = 100 end
      local lx = -1
      local ly = -1
      if C3.was then
        lx = C3.lx
        ly = C3.ly
      end
      darkPass(lx,ly,R*1.35,0.55)
      darkPass(lx,ly,R,0.4)
      if lx >= 0 and not C3.f.usb then
        local wx = (lx-180)/C2.z + C2.cx
        local wy = (ly-320)/C2.z + C2.cy
        local dxx = wx-330
        local dyy = wy-415
        C3.radar = max(0,100 - sqrt(dxx*dxx+dyy*dyy)/3)
      else
        C3.radar = 0
      end
    end
    if ((not C3.worn) and C3.room == "tent") or C3.blurT > 0 then
      screen.setAlpha(0.28)
      for bli=0 to 7
        voval(40+bli*45+sin(G.t*0.03+bli)*10,120+bli*55,170,120,"#ffffff")
      end
      screen.setAlpha(1)
    end
    if m == "dlg" then
      drawDlg()
      if C3.mode == "dlg" and C2.mode == "play" then C3.mode = "play" end
    elsif m == "cam" then
      c3Cam()
    elsif m == "play" then
      c3HUD()
      if C3.room == "lot" then
        vorr(10,570,110,16,8,C_DEEP)
        vrect(13,573,104*(C3.radar or 0)/100,10,C_MINT)
        vtxtL("SIGNAL",128,578,9,C_MINT)
      end
      if G.tap then
        local W = 360
        local H = 640
        local wx = (G.tx/C2.k-W/2)/C2.z + C2.cx
        local wy = (G.ty/C2.k-H/2)/C2.z + C2.cy
        G.tap = false
        c3Tap(wx,wy)
      end
    end
    if C3.flash > 0 then
      screen.setAlpha(C3.flash/8)
      vrect(0,0,360,640,"#ffffff")
      screen.setAlpha(1)
    end
  end
  drawToast()
end

c3Tap = function(wx,wy)
  local L = c3Spots()
  local best = ""
  local bd = 99999
  for tli=0 to L.length-1
    local dx = wx-L[tli][1]
    local dy = wy-L[tli][2]
    local d = sqrt(dx*dx+dy*dy)
    if d < L[tli][3] and d < bd then
      bd = d
      best = L[tli][0]
    end
  end
  if best == "" then
    C3.sel = ""
    return
  end
  if C3.sel != "" then
    c3Use(C3.sel,best)
  else
    c3Act(best)
  end
end
end()



// file: source3.ms
function()
// =====================================================
// SUGAR & SPOOKS - Chapter 4: THE SUGAR KNOWS YOUR NAME
// Phone-first neighborhood chapter
// Requires: main_patched-3.txt + chapter2 source + chapter3_fixed_v2.ms
// Add the c4_* sprites from the Chapter 4 asset pack.
// If Zanji multiplayer is enabled, also add zanji_server.ms as Server.
// =====================================================

// >>> SET TO 0 WHEN YOU ARE DONE TESTING (1 = chapter 4 always unlocked) <<<
C4_FORCE_UNLOCK = 1

C4 = object end
C4.on = false
C4.networkRequired = true
// Leave "" to use microStudio's built-in relay. For an always-on server, export the server
// as a NodeJS app, host it, and put its address here, e.g. "wss://your-app.onrender.com"
C4.serverURL = ""
C4.phoneVisible = true

// ------------------ phone data ------------------

C4.apps = [
  ["threads","c4_threads","THREADS"],
  ["email","c4_email_alert","MAIL"],
  ["linkedin","c4_linkedin","LINKEDIN"],
  ["browser","c4_browser","BROWSER"],
  ["notes","c4_notes","NOTES"],
  ["bluetooth","c4_bluetooth","BLUETOOTH"],
  ["clock","c4_clock","CLOCK"],
  ["store","c4_plus","STORE"],
  ["upload","c4_upload","UPLOAD"],
  ["trash","c4_trash","DELETE"],
  ["pause","c4_pause","LOCK"],
  ["scanner","c4_scanner","SCAN"],
  ["apk","c4_apk","APK"],
  ["zanji","c4_zanji","ZANJI"],
  ["power","c4_power","POWER"]
]

C4.coreApps = ["scanner","threads","email","linkedin","browser","notes","bluetooth","clock","store","upload","trash","pause","power"]
C4.page0 = ["threads","email","linkedin","browser","notes","bluetooth","clock","store","upload","trash","scanner","power"]
// Page 2 is the hidden/secondary page. Zanji only becomes visible after installation.
C4.page1 = ["zanji","apk","pause"]

C4.jobs = [
  ["Maple Hollow Halloween Committee","pending"],
  ["Night Courier","rejected"],
  ["Hollow Sweets Assistant","pending"]
]

C4.webResults = [
  ["maple hollow","MAPLE HOLLOW COMMUNITY","Halloween street closures begin at 11:30 PM. Residents are asked to keep porch lights on until the final bell."],
  ["11:52","THE SWEET TOLL","Local records mention a bell at 11:52 PM. Nobody agrees who rings it."],
  ["halloween","TRICK-OR-TREAT SAFETY","Keep to lit houses. If a porch light turns purple, do not knock."],
  ["zanji","ZANJI","A private number-to-number messenger. Search a number to start a conversation. No acceptance is required."],
  ["sugar","HOLLOW SUGAR","Old folklore: the Hollow remembers names written in sugar, wrappers, and digital messages."]
]

C4.houseNames = ["14","18","21","27","31","36","42","13"]
C4.houseOutcomes = [
  "candy",
  "none",
  "clue",
  "candy",
  "strange",
  "candy",
  "clue",
  "final"
]

// ------------------ music: deliberately different from C3 ------------------

c4Tune = ["F3","Ab3","C4","Eb4","C4","Ab3","G3","F3","Db4","F3","Ab3","C4","Bb3","Ab3","F3","E3"]
c4Bass = ["F2","Db2","Eb2","C2"]

c4Music = function()
  if not C2.audioReady then
    if touch.touching then C2.audioReady = true end
  end
  if C2.mute or not C2.audioReady then return end
  C4.mt = (C4.mt or 0) + 1
  if C4.mt % 30 != 0 then return end
  local mi = floor(C4.mt/30) % c4Tune.length
  audio.beep("sine volume 10 tempo 520 " + c4Tune[mi])
  if mi % 4 == 0 then
    audio.beep("triangle volume 16 tempo 220 " + c4Bass[mi/4])
  end
end

// ------------------ sprite helper ------------------

c4Sprite = function(name,x,y,w,h)
  local k = C2.k
  screen.drawSprite(name,(x+w/2-180)*k,(320-y-h/2)*k,w*k,h*k)
end

c4PhoneFrame = function()
  c4Sprite("c4_phone_frame",19,28,322,583)
end

c4Image = function(img,x,y,w,h)
  screen.drawImage(img,(x+w/2-180)*C2.k,(320-y-h/2)*C2.k,w*C2.k,h*C2.k)
end

c4Screen = function(c)
  vrect(34,79,292,475,c)
end

c4ScreenR = function(x,y,w,h,r,c)
  vorr(x,y,w,h,r,c)
end

c4Top = function(title)
  vrect(34,79,292,36,C_DEEP)
  vtxtL(title,45,92,12,C_GOLD)
  if vbtn("HOME",250,84,66,24,C_PURPLE2,C_PURPLE,9) then
    C4.app = "home"
    C4.sub = ""
    C4.keyboardOn = false
  end
end

c4Hit = function(x,y,w,h)
  return G.tap and G.tx/C2.k >= x and G.tx/C2.k <= x+w and G.ty/C2.k >= y and G.ty/C2.k <= y+h
end

c4Tap = function(x,y,w,h)
  if c4Hit(x,y,w,h) then
    G.tap = false
    return true
  end
  return false
end

c4PhoneButton = function(x,y,w,h,label,col)
  return vbtn(label,x,y,w,h,col,C_DEEP,9)
end

// ------------------ storage ------------------

c4Save = function()
  storage.set("c4_wallpaper",C4.wallpaper)
  storage.set("c4_notes",C4.notes)
  storage.set("c4_posts",C4.posts)
  storage.set("c4_inbox",C4.inbox)
  storage.set("c4_sent",C4.sent)
  storage.set("c4_email",C4.email)
  storage.set("c4_jobs",C4.jobs)
  storage.set("c4_houses",C4.houses)
  storage.set("c4_scans",C4.scans)
  storage.set("c4_bluetooth",C4.bt)
  storage.set("c4_installed",C4.installed)
end

c4Load = function()
  local w = storage.get("c4_wallpaper")
  if w == 0 then w = 0 end
  C4.wallpaper = w

  local n = storage.get("c4_notes")
  if n == 0 then n = [] end
  C4.notes = n

  local p = storage.get("c4_posts")
  if p == 0 then p = [] end
  C4.posts = p

  local ib = storage.get("c4_inbox")
  if ib == 0 then ib = [] end
  C4.inbox = ib

  local se = storage.get("c4_sent")
  if se == 0 then se = [] end
  C4.sent = se

  local em = storage.get("c4_email")
  if em == 0 then em = "" end
  C4.email = em

  local jb = storage.get("c4_jobs")
  if jb == 0 then
    C4.jobs = [
      ["Maple Hollow Halloween Committee","pending"],
      ["Night Courier","rejected"],
      ["Hollow Sweets Assistant","pending"]
    ]
  else
    C4.jobs = jb
  end

  local hs = storage.get("c4_houses")
  if hs == 0 then hs = [false,false,false,false,false,false,false,false] end
  C4.houses = hs

  local sc = storage.get("c4_scans")
  if sc == 0 then sc = [] end
  C4.scans = sc

  local bt = storage.get("c4_bluetooth")
  if bt == 0 then bt = [] end
  C4.bt = bt

  local ins = storage.get("c4_installed")
  if ins == 0 then
    C4.installed = ["threads","email","linkedin","browser","notes","bluetooth","clock","store","upload","trash","pause","apk","power"]
  else
    C4.installed = ins
  end
  if not C4.installed.contains("scanner") then C4.installed.push("scanner") end
end

c4Candy = function(n)
  G.candy += n
  saveGame()
  G.pop = 20
  say("+"+n+" candy!")
end

c4InitState = function()
  C4.wallpaper = 0
  C4.notes = []
  C4.posts = [
    ["Maple Hollow Watch","Porch lights stay on until 11:52. Please keep the street calm."],
    ["@mara_m","Anyone else hear a bell? It isn't coming from the church."],
    ["@hollowkids","TRICK OR TREAT!!! CANDY!"]
  ]
  C4.inbox = [
    ["Maple Hollow Watch","Porch Lights","If a light turns purple, do not knock."],
    ["LinkedIn","Welcome to your job search","Applications can be pending or rejected. Never assume an acceptance."],
    ["Unknown","13","I know the number your phone gave you."]
  ]
  C4.sent = []
  C4.email = ""
  C4.houses = [false,false,false,false,false,false,false,false]
  C4.scans = []
  C4.bt = []
  C4.installed = ["threads","email","linkedin","browser","notes","bluetooth","clock","store","upload","trash","pause","apk","power"]
end

// ------------------ keyboard ------------------

C4.keys1 = ["Q","W","E","R","T","Y","U","I","O","P"]
C4.keys2 = ["A","S","D","F","G","H","J","K","L"]
C4.keys3 = ["Z","X","C","V","B","N","M"]

c4Type = function(k)
  if C4.input.length >= 160 then return end
  C4.input = C4.input + k
end

c4Key = function(k)
  if k == "<" then
    if C4.input.length > 0 then C4.input = C4.input.substring(0,C4.input.length-1) end
  elsif k == "SPACE" then
    c4Type(" ")
  elsif k == "ENTER" then
    C4.inputDone = true
  else
    c4Type(k)
  end
end

C4.keys0 = ["1","2","3","4","5","6","7","8","9","0"]

c4DrawKeys = function(y0)
  local rows = [C4.keys0,C4.keys1,C4.keys2,C4.keys3]
  for ri=0 to 3
    local row = rows[ri]
    local kw = 25
    local gap = 2
    local total = row.length*(kw+gap)-gap
    local x0 = 180-total/2
    for ki=0 to row.length-1
      local x = x0+ki*(kw+gap)
      vorr(x,y0+ri*32,kw,28,5,"#f3efff")
      vtxtC(row[ki],x+kw/2,y0+ri*32+9,9,C_INK)
      if c4Tap(x,y0+ri*32,kw,28) then c4Key(row[ki]) end
    end
  end
  local yb = y0+128
  vorr(42,yb,60,28,5,"#d9d0ee")
  vorr(108,yb,34,28,5,"#f3efff")
  vorr(148,yb,100,28,5,"#f3efff")
  vorr(254,yb,63,28,5,"#a9f0cf")
  vtxtC("DEL",72,yb+9,8,C_INK)
  vtxtC(".",125,yb+9,10,C_INK)
  vtxtC("SPACE",198,yb+9,8,C_INK)
  vtxtC("DONE",285,yb+9,8,C_INK)
  if c4Tap(42,yb,60,28) then c4Key("<") end
  if c4Tap(108,yb,34,28) then c4Key(".") end
  if c4Tap(148,yb,100,28) then c4Key("SPACE") end
  if c4Tap(254,yb,63,28) then c4Key("ENTER") end
end

c4KeyboardInput = function(title,doneText)
  c4Screen("#dfeaf0")
  c4Top(title)
  vorr(43,124,274,66,9,"#ffffff")
  local show = C4.input
  if show == "" then show = "Type here..." end
  local ls = vwrap(show,250,11)
  for i=0 to min(ls.length-1,2)
    vtxtL(ls[i],54,143+i*15,11,"#211534")
  end
  if doneText != "" then
    vtxtC("tap DONE to "+doneText.toLowerCase(),180,204,8,C_PURPLE)
  end
  c4DrawKeys(222)
end

// ------------------ wallpaper / phone shell ------------------

c4Wallpaper = function()
  if C4.wallpaper == 0 then
    c4Screen("#b7ccd7")
    voval(265,410,56,56,"#ffd77a")
    voval(255,400,14,14,"#fff3b0")
    for wi=0 to 5
      voval(60+wi*45,380+sin(G.t*0.02+wi)*4+(wi%2)*30,4,4,"#ffffff")
    end
  elsif C4.wallpaper == 1 then
    c4Screen("#24104a")
    for wi2=0 to 8
      voval(50+(wi2*37)%250,365+(wi2*29)%80,5,5,"#ffc94a")
    end
    vrect(34,500,292,54,"#140923")
    for hi=0 to 4
      local hx = 46+hi*58
      vrect(hx,470,40,40,"#31155a")
      vtri(hx-4,470,hx+44,470,hx+20,448,"#4c287a")
      vrect(hx+15,486,10,24,"#170b2d")
    end
  else
    c4Screen("#102a35")
    voval(180,440,150,150,"#164454")
    voval(180,440,110,110,"#0c2029")
    for si=0 to 11
      vseg(180,440,180+cos(si*PI/6)*72,440+sin(si*PI/6)*72,1,"#2c6d7e")
    end
    vtxtC("MAPLE HOLLOW",180,370,10,"#a5e5e5")
  end
end

c4Status = function()
  vrect(34,79,292,22,"#120a24")
  vtxtL("10:47 PM",44,84,8,C_CREAM)
  vtxtL("o",275,84,8,C_MINT)
  vtxtL("4G",291,84,7,C_CREAM)
end

c4AppSprite = function(id)
  for ai=0 to C4.apps.length-1
    if C4.apps[ai][0]==id then return C4.apps[ai][1] end
  end
  return "c4_question"
end

c4AppLabel = function(id)
  for ai=0 to C4.apps.length-1
    if C4.apps[ai][0]==id then return C4.apps[ai][2] end
  end
  return id.toUpperCase()
end

c4DrawHome = function()
  c4Wallpaper()
  c4Status()
  vtxtL("HOME",45,111,11,C_GOLD)
  if vbtn("WALL",250,101,66,22,C_PURPLE2,C_PURPLE,8) then C4.app="wallpaper" end
  // Scanner is opened by tapping the real camera lens at the top of the supplied phone frame.

  local ink = C_INK
  if C4.wallpaper != 0 then ink = C_CREAM end
  local arr = C4.page
  local apps = C4.page0
  if arr == 1 then apps = C4.page1 end
  local i = 0
  for id in apps
    local installed = C4.installed.contains(id)
    if id == "apk" and C4.apkPending == "" then installed = false end
    local row = floor(i/4)
    local col = i%4
    local x = 70.5+col*73
    local y = 132+row*78
    if installed then
      c4Sprite(c4AppSprite(id),x-20,y,40,40)
      vtxtC(c4AppLabel(id),x,y+46,7,ink)
      if c4Tap(x-25,y-4,50,58) then
        C4.app = id
        if id == "threads" then C4.sub="feed" end
        if id == "email" then C4.sub="inbox" end
        if id == "notes" then C4.sub="list" end
        if id == "linkedin" then C4.sub="jobs" end
        if id == "browser" then C4.sub="search" end
        if id == "clock" then C4.sub="clock" end
        if id == "bluetooth" then C4.sub="bt" end
        if id == "store" then C4.sub="store" end
        if id == "trash" then C4.sub="delete" end
        if id == "pause" then C4.app="lock" end
        if id == "power" then
          C4.powerOff=true
          C4.app="home"
        end
        if id == "apk" then C4.sub="install" end
        if id == "zanji" then C4.sub="contacts" end
      end
    end
    i += 1
  end

  vtxtC("o",170,532,8,C_GOLD)
  vtxtC("o",190,532,8,"#777777")
  vtxtC("page "+(C4.page+1)+"/2",180,546,7,ink)
  if c4Tap(34,520,42,42) then C4.page=0 end
  if c4Tap(282,520,42,42) then C4.page=1 end
  vtxtC("<",55,534,18,ink)
  vtxtC(">",303,534,18,ink)
end

c4DrawPhone = function()
  c4PhoneFrame()
  if C4.powerOff then
    c4Screen("#050509")
    vtxtC("POWER OFF",180,275,15,C_CREAM)
    vtxtC("Tap the power icon area",180,305,9,"#8b8b9a")
    vtxtC("to wake the phone.",180,322,9,"#8b8b9a")
    return
  end
  if C4.app == "home" then
    c4DrawHome()
  elsif C4.app == "threads" then
    c4Threads()
  elsif C4.app == "email" then
    c4Email()
  elsif C4.app == "linkedin" then
    c4LinkedIn()
  elsif C4.app == "browser" then
    c4Browser()
  elsif C4.app == "notes" then
    c4Notes()
  elsif C4.app == "clock" then
    c4Clock()
  elsif C4.app == "bluetooth" then
    c4Bluetooth()
  elsif C4.app == "store" then
    c4Store()
  elsif C4.app == "trash" then
    c4Trash()
  elsif C4.app == "apk" then
    c4Installer()
  elsif C4.app == "zanji" then
    c4Zanji()
  elsif C4.app == "scanner" then
    c4Scanner()
  elsif C4.app == "upload" then
    c4Upload()
  elsif C4.app == "wallpaper" then
    c4WallpaperMenu()
  elsif C4.app == "lock" then
    c4Lock()
  end
end

// ------------------ Threads ------------------

c4Threads = function()
  if C4.sub == "compose" then
    c4KeyboardInput("NEW POST","POST")
    if C4.inputDone then
      if C4.input != "" then
        local ph=""
        if C4.photo!=null then ph=C4.photo end
        C4.posts.push(["@you",C4.input,ph])
        C4.photo=null
        C4.photoIdx=-1
        c4Save()
        C4.input = ""
        C4.inputDone = false
        C4.sub = "feed"
        C4.keyboardOn = false
        say("Posted to Threads.")
      end
    end
    if vbtn("PHOTO",45,392,72,26,C_PURPLE2,C_PURPLE,8) then
      c4LoadPhoto()
    end
    if C4.photo!=null then
      c4Sprite(C4.photo,125,382,34,34)
      vtxtL("PHOTO ATTACHED",205,399,8,C_PURPLE)
    end
    return
  end
  c4Screen("#f7f2f8")
  c4Top("THREADS")
  vtxtL("@maplehollow",45,120,11,C_INK)
  vtxtL("Tonight in Maple Hollow",45,136,8,"#675b70")
  local y = 160
  for pi=0 to min(C4.posts.length-1,5)
    local p = C4.posts[C4.posts.length-1-pi]
    vorr(43,y,274,58,8,"#ffffff")
    vtxtL(p[0],53,y+12,9,C_PURPLE)
    local ls = vwrap(p[1],248,8)
    for li=0 to min(ls.length-1,2)
      vtxtL(ls[li],53,y+28+li*11,8,C_INK)
    end
    if p.length>2 and p[2] != "" and p[2] != false and p[2] != true then
      c4Sprite(p[2],283,y+8,26,26)
    end
    y += 64
  end
  if vbtn("NEW POST",100,514,160,28,C_MINT,"#2a9a6a",10) then
    C4.sub="compose"
    C4.input=""
    C4.inputDone=false
    C4.keyboardOn=true
  end
end

C4.gallery = ["c4_alert","c4_question","c4_email_alert","c4_clock","c4_notes","c4_browser","c4_bluetooth"]

c4LoadPhoto = function()
  // microStudio cannot open the real photo picker, so photos come from the phone gallery.
  C4.photoIdx = ((C4.photoIdx or -1)+1) % (C4.gallery.length+1)
  if C4.photoIdx == C4.gallery.length then
    C4.photo = null
    say("Photo removed.")
  else
    C4.photo = C4.gallery[C4.photoIdx]
    say("Photo "+(C4.photoIdx+1)+" attached.")
  end
end

// ------------------ Mail ------------------

c4Email = function()
  if C4.sub == "read" then
    c4Screen("#eef3f6")
    c4Top("MAIL")
    local m = C4.inbox[C4.mailIndex]
    vtxtL(m[0],48,128,10,C_PURPLE)
    vtxtL(m[1],48,150,12,C_INK)
    local ls = vwrap(m[2],260,10)
    for li=0 to ls.length-1
      vtxtL(ls[li],48,180+li*15,10,C_INK)
    end
    if vbtn("BACK",100,510,70,28,C_PURPLE2,C_PURPLE,9) then C4.sub="inbox" end
    return
  end
  if C4.sub == "compose_to" then
    c4KeyboardInput("NEW EMAIL","NEXT")
    if C4.inputDone then
      C4.mailTo = C4.input
      C4.input = ""
      C4.inputDone = false
      C4.sub = "compose_body"
    end
    return
  end
  if C4.sub == "compose_body" then
    c4KeyboardInput("EMAIL BODY","SEND")
    if C4.inputDone then
      if C4.input != "" then
        C4.sent.push([C4.mailTo,"Halloween message",C4.input])
        c4Save()
        C4.inbox.push(["Sent",C4.mailTo,C4.input])
        C4.input=""
        C4.inputDone=false
        C4.sub="inbox"
        say("Email sent.")
      end
    end
    return
  end
  c4Screen("#eef3f6")
  c4Top("MAIL")
  c4Sprite("c4_email",48,116,18,18)
  vtxtL("INBOX",63,121,9,C_PURPLE)
  local y = 140
  for mi=0 to C4.inbox.length-1
    local m = C4.inbox[mi]
    vorr(43,y,274,52,8,"#ffffff")
    vtxtL(m[0],53,y+12,8,C_PURPLE)
    vtxtL(m[1],53,y+28,9,C_INK)
    if c4Tap(43,y,274,52) then
      C4.mailIndex=mi
      C4.sub="read"
    end
    y += 58
    if y > 470 then break end
  end
  if vbtn("COMPOSE",100,514,160,28,C_MINT,"#2a9a6a",10) then
    C4.sub="compose_to"
    C4.input=""
    C4.inputDone=false
  end
end

// ------------------ LinkedIn ------------------

c4LinkedIn = function()
  if C4.sub == "profile" then
    c4Screen("#eef4f8")
    c4Top("LINKEDIN")
    vtxtC("YOUR PROFILE",180,125,12,C_PURPLE)
    vtxtL("Name: You",50,155,10,C_INK)
    local em = C4.email
    if em == "" then em = "not created yet" end
    vtxtL("Email: "+em,50,176,9,C_INK)
    if C4.email == "" then
      if vbtn("CREATE EMAIL",80,210,200,30,C_MINT,"#2a9a6a",10) then
        C4.sub="make_email"
        C4.input=""
        C4.inputDone=false
      end
    end
    if vbtn("JOBS",110,514,140,28,C_PURPLE2,C_PURPLE,10) then C4.sub="jobs" end
    return
  end
  if C4.sub == "make_email" then
    c4KeyboardInput("EMAIL NAME","CREATE")
    if C4.inputDone then
      if C4.input != "" then
        C4.email=C4.input.toLowerCase()+"@hollowmail.net"
        c4Save()
        C4.input=""
        C4.inputDone=false
        C4.sub="profile"
        C4.inbox.push(["LinkedIn","Your new HollowMail address","Your account email is now "+C4.email+"."])
        c4Save()
      end
    end
    return
  end
  c4Screen("#eef4f8")
  c4Top("LINKEDIN")
  vtxtL("LINKEDIN",48,119,11,"#0b66c3")
  if vbtn("PROFILE",250,106,66,22,C_PURPLE2,C_PURPLE,8) then C4.sub="profile" end
  local y = 140
  for ji=0 to C4.jobs.length-1
    local job=C4.jobs[ji]
    vorr(43,y,274,82,8,"#ffffff")
    vtxtL(job[0],53,y+14,10,C_INK)
    vtxtL("Maple Hollow",53,y+30,8,"#687681")
    local st=job[1]
    local col=C_GOLD
    if st=="rejected" then col="#d6405a" end
    vtxtL("STATUS: "+st.toUpperCase(),53,y+49,8,col)
    if vbtn("APPLY",230,y+42,72,26,C_MINT,"#2a9a6a",8) then
      if C4.email == "" then
        C4.sub="profile"
        say("Create your HollowMail email first.")
      else
        if ji == 1 then C4.jobs[ji][1]="rejected" else C4.jobs[ji][1]="pending" end
        C4.inbox.push(["LinkedIn","Application update: "+job[0],"Status: "+C4.jobs[ji][1]+". No acceptance has been issued."])
        c4Save()
        say("Application submitted.")
      end
    end
    y += 90
  end
end

// ------------------ Browser ------------------

c4Browser = function()
  if C4.sub == "search" then
    c4Screen("#ffffff")
    c4Top("BROWSER")
    vorr(43,121,274,38,8,"#eef1f4")
    local q=C4.query
    if q=="" then q="Search Maple Hollow..." end
    vtxtL(q,53,135,9,C_INK)
    if vbtn("SEARCH",238,127,70,24,C_MINT,"#2a9a6a",8) then
      C4.sub="results"
    end
    if vbtn("TYPE",100,178,160,28,C_PURPLE2,C_PURPLE,10) then
      C4.input=C4.query
      C4.inputDone=false
      C4.sub="type_search"
    end
    return
  end
  if C4.sub == "type_search" then
    c4KeyboardInput("SEARCH","SEARCH")
    if C4.inputDone then
      C4.query=C4.input
      C4.input=""
      C4.inputDone=false
      C4.sub="results"
    end
    return
  end
  c4Screen("#ffffff")
  c4Top("BROWSER")
  vtxtL("SEARCH RESULTS",45,119,10,C_PURPLE)
  local q=C4.query.toLowerCase()
  local found=0
  local y=140
  for wi=0 to C4.webResults.length-1
    local r=C4.webResults[wi]
    if q=="" or r[0].indexOf(q)>=0 or r[1].toLowerCase().indexOf(q)>=0 or r[2].toLowerCase().indexOf(q)>=0 then
      vorr(43,y,274,68,8,"#f7f7fa")
      vtxtL(r[1],53,y+13,9,C_PURPLE)
      local ls=vwrap(r[2],250,8)
      for li=0 to min(ls.length-1,2)
        vtxtL(ls[li],53,y+29+li*11,8,C_INK)
      end
      y += 76
      found += 1
      if found >= 4 then break end
    end
  end
  if found==0 then vtxtC("No result.",180,190,11,C_INK) end
  if vbtn("NEW SEARCH",90,514,180,28,C_MINT,"#2a9a6a",10) then
    C4.sub="search"
  end
end

// ------------------ Notes ------------------

c4Notes = function()
  if C4.sub=="new" then
    c4KeyboardInput("NEW NOTE","SAVE")
    if C4.inputDone then
      if C4.input != "" then
        C4.notes.push(["Note "+(C4.notes.length+1),C4.input])
        c4Save()
        C4.input=""
        C4.inputDone=false
        C4.sub="list"
        say("Note saved.")
      end
    end
    return
  end
  if C4.sub=="read" then
    c4Screen("#fffdf7")
    c4Top("NOTES")
    local n=C4.notes[C4.noteIndex]
    vtxtL(n[0],48,126,11,C_PURPLE)
    local ls=vwrap(n[1],260,10)
    for li=0 to ls.length-1
      vtxtL(ls[li],48,155+li*15,10,C_INK)
    end
    if vbtn("BACK",100,514,70,28,C_PURPLE2,C_PURPLE,9) then C4.sub="list" end
    return
  end
  c4Screen("#fffdf7")
  c4Top("NOTES")
  vtxtL("SAVED NOTES",45,119,10,C_PURPLE)
  local y=138
  for ni=0 to C4.notes.length-1
    local n=C4.notes[ni]
    vorr(43,y,274,42,8,"#ffffff")
    vtxtL(n[0],53,y+13,9,C_INK)
    local preview=n[1]
    if preview.length>34 then preview=preview.substring(0,34)+"..." end
    vtxtL(preview,53,y+29,7,"#766d75")
    if c4Tap(43,y,274,42) then
      C4.noteIndex=ni
      C4.sub="read"
    end
    y+=48
    if y>470 then break end
  end
  if vbtn("NEW NOTE",100,514,160,28,C_MINT,"#2a9a6a",10) then
    C4.sub="new"
    C4.input=""
    C4.inputDone=false
  end
end

// ------------------ Clock ------------------

c4Clock = function()
  c4Screen("#11111b")
  c4Top("CLOCK")
  vtxtC("10:47",180,145,30,C_CREAM)
  vtxtC("OCT 31 鈥� MAPLE HOLLOW",180,177,8,"#9aa1b0")
  vtxtC("TIMER",180,225,11,C_GOLD)
  local t=C4.timer
  if t<0 then t=0 end
  local mm=floor(t/60)
  local ss=floor(t%60)
  local s=""+ss
  if ss<10 then s="0"+ss end
  vtxtC(mm+":"+s,180,265,25,C_MINT)
  if vbtn("1 MIN",48,310,78,28,C_PURPLE2,C_PURPLE,9) then C4.timer+=60 end
  if vbtn("5 MIN",141,310,78,28,C_PURPLE2,C_PURPLE,9) then C4.timer+=300 end
  if vbtn("CLEAR",234,310,78,28,"#d6405a","#8f263a",9) then C4.timer=0 end
  if vbtn("START / PAUSE",80,365,200,32,C_MINT,"#2a9a6a",10) then C4.timerRun=not C4.timerRun end
  if C4.timer==0 and C4.timerRun then C4.timerRun=false end
end

// ------------------ Bluetooth ------------------

c4Bluetooth = function()
  c4Screen("#eef4f8")
  c4Top("BLUETOOTH")
  vtxtL("BLUETOOTH",48,120,12,C_PURPLE)
  vtxtL("Status:",48,146,9,C_INK)
  local st="OFF"
  if C4.btOn then st="ON" end
  vtxtL(st,110,146,9,C_MINT)
  if vbtn("TOGGLE",220,128,88,28,C_PURPLE2,C_PURPLE,9) then
    C4.btOn=not C4.btOn
    c4Save()
  end
  vtxtL("NEARBY DEVICES",48,190,10,C_PURPLE)
  local devices=["MAPLE-13","ODTTE-LENS","HOLLOW-KEY","UNKNOWN-BT"]
  for di=0 to 3
    local paired=C4.bt.contains(devices[di])
    local y=210+di*48
    vorr(43,y,274,38,8,"#ffffff")
    vtxtL(devices[di],53,y+13,9,C_INK)
    if C4.btOn then
      if paired then
        vtxtC("PAIRED",270,y+13,8,C_MINT)
      else
        if vbtn("PAIR",226,y+6,72,24,C_PURPLE2,C_PURPLE,8) then
          C4.bt.push(devices[di])
          c4Save()
          say("Paired with "+devices[di]+".")
        end
      end
    end
  end
end

// ------------------ Store / APK ------------------

c4Store = function()
  c4Screen("#f4f0f8")
  c4Top("APP STORE")
  vtxtL("AVAILABLE APPS",45,119,10,C_PURPLE)
  local items=[["ZANJI","zanji"]]
  for si=0 to 0
    local y=145+si*82
    vorr(43,y,274,68,8,"#ffffff")
    vtxtL(items[si][0],53,y+16,10,C_INK)
    vtxtL("Download .APK",53,y+34,8,"#77707b")
    if C4.installed.contains(items[si][1]) then
      vtxtC("INSTALLED",266,y+27,8,C_MINT)
    elsif C4.apkPending==items[si][1] then
      vtxtC("DOWNLOADING",264,y+27,8,C_GOLD)
    else
      if vbtn("GET",230,y+18,72,24,C_MINT,"#2a9a6a",8) then
        C4.apkPending=items[si][1]
        say(items[si][0]+" .APK downloaded. Open the APK icon to confirm.")
      end
    end
  end
end

c4Installer = function()
  c4Screen("#f0f0f4")
  c4Top("APK INSTALLER")
  if C4.apkPending=="" then
    vtxtC("NO APK DOWNLOADED",180,190,12,C_INK)
    vtxtC("Use + APP STORE first.",180,216,9,"#6b6570")
    return
  end
  vtxtC("INSTALL APPLICATION?",180,145,13,C_PURPLE)
  vtxtC(C4.apkPending.toUpperCase()+".APK",180,177,12,C_INK)
  vtxtC("This app is not installed yet.",180,202,9,"#6b6570")
  if vbtn("CANCEL",50,250,110,34,"#77727e","#4b4750",10) then C4.apkPending="" end
  if vbtn("INSTALL",200,250,110,34,C_MINT,"#2a9a6a",10) then
    if not C4.installed.contains(C4.apkPending) then C4.installed.push(C4.apkPending) end
    local installed=C4.apkPending
    C4.apkPending=""
    c4Save()
    say(installed.toUpperCase()+" installed.")
    C4.app="home"
  end
end

// ------------------ Delete ------------------

c4Trash = function()
  c4Screen("#f8f1f2")
  c4Top("DELETE")
  vtxtL("DELETE THINGS",45,119,10,"#a52b40")
  vtxtL("This will not delete core apps.",45,138,8,"#6e6570")
  if vbtn("DELETE LAST NOTE",45,165,263,28,"#d6405a","#8f263a",9) then
    if C4.notes.length>0 then
      C4.notes.pop()
      c4Save()
      say("Last note deleted.")
    else say("No notes to delete.") end
  end
  if vbtn("DELETE LAST POST",45,205,263,28,"#d6405a","#8f263a",9) then
    if C4.posts.length>3 then
      C4.posts.pop()
      c4Save()
      say("Last post deleted.")
    else say("Original neighborhood posts are protected.") end
  end
  vtxtL("OPTIONAL APPS",45,265,10,C_PURPLE)
  local y=286
  for ai=0 to C4.installed.length-1
    local id=C4.installed[ai]
    if not C4.coreApps.contains(id) and id!="apk" then
      vorr(43,y,274,34,7,"#ffffff")
      vtxtL(id.toUpperCase(),53,y+12,8,C_INK)
      if vbtn("DELETE",230,y+5,72,24,"#d6405a","#8f263a",8) then
        C4.installed.remove(ai)
        c4Save()
        say(id.toUpperCase()+" removed.")
      end
      y+=40
    end
  end
end

// ------------------ Scanner ------------------

c4Scanner = function()
  c4Screen("#071015")
  c4Top("SCANNER")
  vtxtC("PHONE SCANNER",180,123,12,C_MINT)
  vtxtC("Point the scan at a marked object.",180,148,8,"#a8c7cf")
  vorr(70,190,220,180,10,"#0d222a")
  vrect(82,202,196,2,C_MINT)
  vrect(82,356,196,2,C_MINT)
  vrect(82,202,2,156,C_MINT)
  vrect(276,202,2,156,C_MINT)
  local p=82+((G.t*2)%194)
  vrect(p,204,2,152,"#8fffe8")
  if vbtn("SCAN NOW",90,405,180,34,C_MINT,"#2a9a6a",11) then
    if C4.scans.length<3 then
      C4.scans.push("mark"+(C4.scans.length+1))
      c4Save()
      c4AddClue("The scanner found a tiny Z etched under the sugar glaze. Someone is using the same symbol on the street.")
      say("Scan complete. New clue saved.")
    else
      say("The scanner sees nothing new.")
    end
  end
  vtxtC("Scans: "+C4.scans.length+"/3",180,470,9,C_GOLD)
end

c4AddClue = function(t)
  C4.inbox.push(["Scanner","New scan result",t])
end

// ------------------ Upload ------------------

c4Upload = function()
  c4Screen("#edf4f8")
  c4Top("UPLOAD")
  vtxtC("CLOUD UPLOAD",180,125,12,C_PURPLE)
  vtxtC("Send a saved clue to your private cloud.",180,150,8,C_INK)
  if vbtn("UPLOAD NOTES",80,195,200,32,C_MINT,"#2a9a6a",10) then
    C4.cloudUploaded=true
    c4Save()
    say("Notes uploaded to MapleCloud.")
  end
  if vbtn("UPLOAD PROFILE",80,240,200,32,C_PURPLE2,C_PURPLE,10) then
    C4.cloudUploaded=true
    say("Profile uploaded.")
  end
  if C4.cloudUploaded then
    vtxtC("鉁� SYNCED",180,305,12,C_MINT)
  end
end

// ------------------ Wallpaper menu ------------------

c4WallpaperMenu = function()
  c4Screen("#eef0f4")
  c4Top("WALLPAPER")
  vtxtC("CHOOSE A WALLPAPER",180,119,11,C_PURPLE)
  for wi=0 to 2
    local x=48+wi*92
    local col="#b7ccd7"
    if wi==1 then col="#24104a" end
    if wi==2 then col="#102a35" end
    vorr(x,145,78,112,8,col)
    vtxtC(""+(wi+1),x+39,200,12,C_CREAM)
    if vbtn("USE",x+7,218,64,24,C_MINT,"#2a9a6a",8) then
      C4.wallpaper=wi
      c4Save()
      C4.app="home"
    end
  end
end

// ------------------ Lock / pause ------------------

c4Lock = function()
  c4Screen("#10091d")
  vtxtC("SLEEP MODE",180,220,18,C_GOLD)
  vtxtC("Tap to wake.",180,250,9,"#b0a6bd")
  c4Sprite("c4_pause",180-24,285,48,48)
  if c4Tap(70,150,220,220) then C4.app="home" end
end

// ------------------ Zanji ------------------

c4ZanjiLoad = function()
  local m = storage.get("c4_zanji_msgs")
  if m == 0 then m = [] end
  C4.zanjiMessages = m
end

c4ZanjiSave = function()
  while C4.zanjiMessages.length > 300
    C4.zanjiMessages.remove(0)
  end
  storage.set("c4_zanji_msgs",C4.zanjiMessages)
end

c4ZanjiOnline = function()
  return C4.conn != null and C4.conn.status == "connected"
end

c4ZanjiConnect = function()
  if not C4.installed.contains("zanji") then return end
  if C4.zanjiNumber == "" then
    local saved = storage.get("c4_zanji_number")
    if saved == 0 or saved == null then saved = storage.get("zanji_number_backup") end
    if saved != 0 and saved != null and (""+saved).length == 8 then
      C4.zanjiNumber = ""+saved
    else
      local r = floor(random.next()*900000)+100000
      C4.zanjiNumber = "73"+r
    end
    storage.set("c4_zanji_number",C4.zanjiNumber)
    storage.set("zanji_number_backup",C4.zanjiNumber)
    local tk = storage.get("c4_zanji_token")
    if tk == 0 or tk == null then
      tk = "t"+floor(random.next()*1000000000)+"x"+floor(random.next()*1000000000)
      storage.set("c4_zanji_token",tk)
    end
    C4.zanjiToken = ""+tk
    local cs = storage.get("c4_zanji_contacts")
    if cs == 0 or cs == null then cs = [] end
    C4.zanjiContacts = cs
    local ob = storage.get("c4_zanji_outbox")
    if ob != 0 and ob != null then C4.zanjiOutbox = ob end
  end
  if C4.zanjiMessages.length == 0 then
    C4.zanjiMessages.push(["0000",C4.zanjiNumber,"Welcome to Zanji. Your number is "+C4.zanjiNumber+". Share it with friends, or press SEARCH NUMBER to message theirs."])
    c4ZanjiSave()
  end
  if C4.conn == null then
    C4.conn = c4NewConn()
  elsif (C4.conn.status == "error" or C4.conn.status == "disconnected") and C4.t % 180 == 0 then
    C4.conn = c4NewConn()
  end
  if C4.conn.status != "connected" then
    C4.registered = false
  elsif not C4.registered then
    C4.conn.send(object
      type = "register"
      number = C4.zanjiNumber
      token = C4.zanjiToken
    end)
    C4.registered = true
    for o in C4.zanjiOutbox
      C4.conn.send(object
        type = "send"
        dest = o[0]
        body = o[1]
      end)
    end
    C4.zanjiOutbox = []
    storage.set("c4_zanji_outbox",C4.zanjiOutbox)
  end
end

c4NewConn = function()
  if C4.serverURL != "" then return new ServerConnection(C4.serverURL) end
  return new ServerConnection()
end

c4ZanjiAddContact = function(n)
  if C4.zanjiContacts == null then C4.zanjiContacts = [] end
  if n == "0000" or n == C4.zanjiNumber or n == "" then return end
  if C4.zanjiContacts.indexOf(n) < 0 then
    C4.zanjiContacts.push(n)
    storage.set("c4_zanji_contacts",C4.zanjiContacts)
  end
end

c4ZanjiPoll = function()
  if C4.conn == null then return end
  for m in C4.conn.messages
    local d = m
    if m.data != null then d = m.data end
    if d.type == "assigned" then
      C4.zanjiNumber = ""+d.number
      storage.set("c4_zanji_number",C4.zanjiNumber)
    elsif d.type == "msg" then
      c4ZanjiAddContact(""+d.from)
      C4.zanjiMessages.push([""+d.from,C4.zanjiNumber,""+d.body])
      c4ZanjiSave()
      if not (C4.app == "zanji" and C4.zanjiTarget == ""+d.from) then
        say("New Zanji message from "+d.from)
      end
    elsif d.type == "status" then
      C4.zanjiStatus = d.text
    end
  end
end

c4ZanjiSend = function(dest,body)
  if dest == "0000" then
    C4.zanjiMessages.push([C4.zanjiNumber,dest,body])
    C4.zanjiMessages.push(["0000",C4.zanjiNumber,"Zanji Help: messages go straight to the number you search. No request needed."])
    c4ZanjiSave()
    return
  end
  c4ZanjiAddContact(dest)
  C4.zanjiMessages.push([C4.zanjiNumber,dest,body])
  c4ZanjiSave()
  if c4ZanjiOnline() then
    C4.conn.send(object
      type = "send"
      dest = dest
      body = body
    end)
  else
    C4.zanjiOutbox.push([dest,body])
    storage.set("c4_zanji_outbox",C4.zanjiOutbox)
    say("Offline. It will send when Zanji reconnects.")
  end
end

c4ZanjiPeers = function()
  local peers = []
  for mi=C4.zanjiMessages.length-1 to 0 by -1
    local m = C4.zanjiMessages[mi]
    local p = m[0]
    if p == C4.zanjiNumber then p = m[1] end
    if not peers.contains(p) then peers.push(p) end
  end
  if C4.zanjiContacts != null then
    for ci=C4.zanjiContacts.length-1 to 0 by -1
      if not peers.contains(C4.zanjiContacts[ci]) then peers.push(C4.zanjiContacts[ci]) end
    end
  end
  return peers
end

c4ZanjiBack = function()
  C4.sub = "contacts"
  C4.input = ""
  C4.inputDone = false
end

c4Zanji = function()
  if C4.sub == "compose" then
    c4KeyboardInput("MESSAGE "+C4.zanjiTarget,"send")
    if C4.inputDone then
      if C4.input != "" then c4ZanjiSend(C4.zanjiTarget,C4.input) end
      C4.input = ""
      C4.inputDone = false
      C4.sub = "chat"
    end
    return
  end
  if C4.sub == "search" then
    c4KeyboardInput("SEARCH NUMBER","open chat")
    if C4.inputDone then
      if C4.input.length >= 3 then
        C4.zanjiTarget = C4.input
        c4ZanjiAddContact(C4.input)
        C4.sub = "chat"
      else
        say("Type the full number first.")
      end
      C4.input = ""
      C4.inputDone = false
    end
    return
  end
  c4Screen("#f3edf7")
  c4Top("ZANJI")
  local num = C4.zanjiNumber
  if num == "" then num = "connecting..." end
  if c4ZanjiOnline() then
    vtxtL("ONLINE",45,122,8,"#2a9a6a")
  else
    if C4.conn != null and C4.conn.status == "connecting" then
      vtxtL("CONNECTING to Zanji server...",45,122,8,"#a57b20")
    else
      vtxtL("OFFLINE - messages are saved and will send",45,122,8,"#a52b40")
      vtxtL("automatically when the server is back",45,132,7,"#a52b40")
    end
  end
  if C4.sub == "chat" then
    vtxtL("CHAT WITH "+C4.zanjiTarget,45,140,10,C_PURPLE)
    local mine = []
    for mi=0 to C4.zanjiMessages.length-1
      local m = C4.zanjiMessages[mi]
      if m[0] == C4.zanjiTarget or m[1] == C4.zanjiTarget then mine.push(m) end
    end
    local first = max(0,mine.length-5)
    local y = 158
    for mi=first to mine.length-1
      local m = mine[mi]
      local isMe = (m[0] == C4.zanjiNumber)
      local ls = vwrap(m[2],200,8)
      local h = 14+min(ls.length,3)*11
      local x = 45
      local col = "#ffffff"
      if isMe then
        x = 317-215
        col = "#cfe9ff"
      end
      vorr(x,y,215,h,8,col)
      for li=0 to min(ls.length-1,2)
        vtxtL(ls[li],x+8,y+11+li*11,8,C_INK)
      end
      y += h+6
    end
    if C4.zanjiStatus != "" then vtxtC(C4.zanjiStatus,180,440,7,"#6c6370") end
    if vbtn("BACK",45,470,80,28,"#77727e","#4b4750",9) then c4ZanjiBack() end
    if vbtn("TYPE MESSAGE",135,470,172,28,C_MINT,"#2a9a6a",9) then
      C4.sub = "compose"
      C4.input = ""
      C4.inputDone = false
    end
    return
  end
  vtxtL("YOUR NUMBER: "+num,45,140,10,C_INK)
  vtxtL("CHATS",45,164,9,C_PURPLE)
  local peers = c4ZanjiPeers()
  local y = 180
  for pi=0 to min(peers.length-1,5)
    vorr(43,y,274,38,8,"#ffffff")
    vtxtL(peers[pi],53,y+14,10,C_INK)
    vtxtL("tap to open",53,y+28,7,"#8b8392")
    if c4Tap(43,y,274,38) then
      C4.zanjiTarget = peers[pi]
      C4.sub = "chat"
    end
    y += 44
  end
  if peers.length == 0 then
    vtxtC("No chats yet. Search a number to start.",180,230,8,"#6c6370")
  end
  if vbtn("SEARCH NUMBER / NEW CHAT",55,490,250,28,C_PURPLE2,C_PURPLE,9) then
    C4.sub = "search"
    C4.input = ""
    C4.inputDone = false
  end
  vtxtC("No request needed. Just message them.",180,530,7,"#6c6370")
end

// ------------------ Neighborhood ------------------

c4House = function(x,y,s,style,num,lit)
  local wall=["#6e4a82","#735b42","#4f687a","#805052"][style%4]
  local roof=["#2d173c","#32261c","#1b3340","#3b1e26"][style%4]
  vrect(x-38*s,y-70*s,76*s,70*s,wall)
  vtri(x-48*s,y-70*s,x+48*s,y-70*s,x,y-112*s,roof)
  vrect(x-8*s,y-35*s,16*s,35*s,"#291733")
  vrect(x-28*s,y-50*s,18*s,16*s,"#ffd36b")
  vrect(x+10*s,y-50*s,18*s,16*s,"#ffd36b")
  vrect(x-25*s,y-47*s,12*s,10*s,"#fff0a2")
  vrect(x+13*s,y-47*s,12*s,10*s,"#fff0a2")
  if lit then
    screen.setAlpha(0.12)
    voval(x,y-47*s,62*s,48*s,"#ffd36b")
    screen.setAlpha(1)
  end
  vpumpkin(x-28*s,y+4*s,8*s)
  vpumpkin(x+28*s,y+6*s,7*s)
  vtxtC(num,x,y-82*s,9,C_CREAM)
end

c4DrawWorld = function()
  vgrad(0,640,20,10,45,77,33,105,18)
  voval(285,92,100,100,"#ffe0a1")
  for wi=0 to 13
    voval(15+(wi*137)%330,25+(wi*83)%250,3,3,"#fff2b0")
  end
  vrect(0,460,360,180,"#1d1430")
  vrect(0,480,360,12,"#342446")
  vrect(0,545,360,95,"#11101b")
  vrect(0,570,360,4,"#3b3545")
  for hi=0 to 7
    local x=35+hi*40
    local h=C4.houseNames[hi]
    local lit=true
    if C4.houses[hi] then lit=false end
    c4House(x,455,0.62,hi,h,lit)
  end
  vtxtC("MAPLE STREET",180,510,10,C_GOLD)
  vtxtC("TRICK OR TREAT",180,535,8,C_CREAM)
  vorr(10,585,110,32,8,C_DEEP)
  vtxtL("CANDY: "+G.candy,20,596,9,C_GOLD)
  vorr(220,585,130,32,8,C_DEEP)
  vtxtL("SCANS "+C4.scans.length+"/3",230,596,9,C_MINT)
end

c4WorldTap = function()
  if not G.tap then return end
  local px=G.tx/C2.k
  local py=G.ty/C2.k
  if py>300 and py<475 then
    local best=-1
    for hi2=0 to 7
      local hx=35+hi2*40
      if abs(px-hx)<24 then best=hi2 end
    end
    if best>=0 then
      G.tap=false
      c4VisitHouse(best)
    end
  end
end

c4VisitHouse = function(i)
  if C4.houses[i] then
    say("No one answers at house "+C4.houseNames[i]+".")
    return
  end
  local out=C4.houseOutcomes[i]
  // House 13 stays available until its requirements are actually met.
  if out=="final" then
    if G.candy<13 then
      say("House 13 is silent. The lock seems to want exactly 13 candies.")
      return
    end
    if C4.scans.length<3 then
      say("The lock flashes: SCAN THREE MARKS.")
      return
    end
  end
  C4.houses[i]=true
  c4Save()
  if out=="candy" then
    c4Candy(2+(i%3))
    if i==3 then
      C4.inbox.push(["Unknown","A wrapper","The candy wrapper says: ZANJI // "+C4.houseNames[i]])
      c4Save()
    end
  elsif out=="none" then
    c4StartDlg([["You","","Trick or treat!"],["Neighbor","","Sorry, no candy tonight."],["You","think","The porch light is on. But the house feels empty."]],null)
  elsif out=="clue" then
    c4Candy(1)
    c4AddClue("House "+C4.houseNames[i]+" had a sugar mark shaped like a Z. The same symbol appeared in the scanner.")
    c4Save()
    c4StartDlg([["You","","Trick or treat!"],["Neighbor","","Candy is easy. Knowing who is watching is harder."],["You","worry","There is a Z scratched into the doorbell."]],null)
  elsif out=="strange" then
    c4Candy(3)
    c4AddClue("A house gave you candy wrapped in a black strip. The wrapper has your Zanji number printed on it.")
    c4Save()
    c4StartDlg([["You","","Trick or treat!"],["Neighbor","","Take three. You'll need them."],["You","shock","They said that before I gave them my name."]],null)
  elsif out=="final" then
    c4StartDlg([["You","","House 13. There was no house 13 yesterday."],["Unknown","","You kept knocking. So I opened the door."],["You","shock","The phone buzzes. The message is from my own Zanji number."],["Unknown","","Look behind you."]],c4Finish)
  end
end

// ------------------ Chapter dialogue ------------------

c4StartDlg = function(lines,cb)
  C4.dlg=lines
  C4.di=0
  C4.dlgTimer=0
  C4.dlgCb=cb
  C4.mode="dlg"
end

c4DrawDlg = function()
  c4DrawWorld()
  screen.setAlpha(0.48)
  vrect(0,0,360,640,"#0a0615")
  screen.setAlpha(1)
  local d=C4.dlg[C4.di]
  local who=d[0]
  local text=d[2]
  vorr(18,410,324,190,12,"#24104a")
  if who!="" then
    if who=="You" or who=="Player" then
      vbust("You",82,412,0.72)
    elsif who=="Odette" then
      vbust("Odette",278,412,0.72)
    else
      vbust("Tilly",278,412,0.72)
    end
  end
  if who!="" then
    vtxtL(who,34,431,10,C_GOLD)
  end
  local ls=vwrap(text,292,11)
  for li=0 to min(ls.length-1,7)
    vtxtL(ls[li],34,462+li*16,10,C_CREAM)
  end
  if vbtn("NEXT",118,570,124,30,C_ORANGE,C_ORANGE2,10) then
    C4.di+=1
    if C4.di>=C4.dlg.length then
      C4.mode="world"
      if C4.dlgCb!=null then
        local cb=C4.dlgCb
        C4.dlgCb=null
        cb()
      end
    end
  end
end

// ------------------ HUD / pause / hints ------------------

c4HintText = function()
  if C4.scans.length < 3 then
    return "Tap the camera lens at the top-left of your phone to scan. You need 3 scans."
  end
  if G.candy < 13 then
    return "Trick-or-treat the lit houses. Some give candy, some give clues. You need 13 candy."
  end
  return "House 13 is ready. Knock on the last house on the right."
end

c4HUD = function()
  if vibtn("pause",24,24,14) then C4.mode = "pause" end
  if vibtn("bulb",60,24,14) then say(c4HintText()) end
  if vibtn("folder",96,24,14) then
    C4.phoneVisible = true
    C4.app = "home"
    C4.sub = ""
  end
end

c4DrawPause = function()
  c4DrawWorld()
  screen.setAlpha(0.6)
  vrect(0,0,360,640,"#0a0615")
  screen.setAlpha(1)
  vorr(50,150,260,330,14,"#24104a")
  vtxtC("PAUSED",180,185,16,C_GOLD)
  if vbtn("RESUME",80,215,200,40,C_MINT,"#2a9a6a",13) then C4.mode = "world" end
  if vbtn("HINT",80,265,200,40,C_PURPLE2,C_PURPLE,13) then say(c4HintText()) end
  if vbtn("CHAPTERS",80,315,200,40,C_ORANGE,C_ORANGE2,13) then c4Exit() end
  if vbtn("MAIN MENU",80,365,200,40,C_PINK,"#a83c6c",13) then
    c4Save()
    C4.on = false
    go("menu")
  end
end

// ------------------ Chapter end ------------------

c4Finish = function()
  storage.set("ch4done",1)
  c4Save()
  C4.mode="end"
end

c4End = function()
  vrect(0,0,360,640,C_INK)
  vtxtC("CHAPTER 4",180,105,11,C_GOLD)
  vtxtC("THE SUGAR KNOWS",180,145,20,C_ORANGE)
  vtxtC("YOUR NAME",180,174,20,C_PINK)
  vtxtC("13 candies. 3 scans. One door.",180,230,10,C_CREAM)
  vtxtC("And the phone sent a message",180,258,9,"#c6b8d7")
  vtxtC("from a number that belongs to you.",180,277,9,"#c6b8d7")
  vorr(45,320,270,110,12,C_DEEP)
  vtxtC("ZANJI",180,345,12,C_GOLD)
  vtxtC("UNKNOWN: Look behind you.",180,375,10,C_CREAM)
  vtxtC("The next chapter is still locked.",180,405,9,"#8d7da4")
  if vbtn("BACK TO CASES",90,500,180,34,C_MINT,"#2a9a6a",11) then c4Exit() end
end

// ------------------ phone update helpers ------------------

// The phone is a real handheld object in Chapter 4.  It can be put away so
// the player can walk the neighborhood, then reopened from the world HUD.
c4TogglePhone = function()
  C4.phoneVisible = not C4.phoneVisible
  if C4.phoneVisible then
    C4.app="home"
    C4.sub=""
    C4.keyboardOn=false
  end
end

c4HandleSystem = function()
  if C4.timerRun and C4.timer>0 then
    C4.timer-=1/60
    if C4.timer<=0 then
      C4.timer=0
      C4.timerRun=false
      say("Timer finished.")
    end
  end

  // Physical keyboard works too when an on-screen keyboard is active.
  if C4.keyboardOn then
    for key in keyboard.press
      if keyboard.press[key] then
        if key.length==1 then c4Key(key.toUpperCase()) end
      end
    end
    if keyboard.press.SPACE then c4Key("SPACE") end
    if keyboard.press.BACKSPACE then c4Key("<") end
    if keyboard.press.ENTER then c4Key("ENTER") end
  end
end

c4HandleHomeHardware = function()
  local x=G.tx/C2.k
  local y=G.ty/C2.k

  // When the phone is put away, the world HUD can bring it back.
  if not C4.phoneVisible then
    if G.tap and x>128 and x<212 and y>584 and y<622 then
      G.tap=false
      C4.phoneVisible=true
      C4.app="home"
      C4.sub=""
      return
    end
    return
  end

  // Power button / yellow hardware area on the supplied frame.
  if C4.powerOff and x>265 and x<325 and y>20 and y<78 then
    C4.powerOff=false
    G.tap=false
    return
  end

  // Bottom-center home key: always returns to the phone home screen.
  if G.tap and x>145 and x<215 and y>560 and y<630 then
    G.tap=false
    C4.app="home"
    C4.sub=""
    C4.keyboardOn=false
    return
  end

  // Bottom-right hardware back key: inside an app, go home; on home, put the
  // phone away so the player can explore the street.
  if G.tap and x>258 and x<335 and y>560 and y<630 then
    G.tap=false
    if C4.app!="home" then
      C4.app="home"
      C4.sub=""
      C4.keyboardOn=false
    else
      C4.phoneVisible=false
      C4.keyboardOn=false
    end
    return
  end

  // The supplied phone's top-left camera lens opens the scanner.
  if G.tap and x>45 and x<95 and y>25 and y<75 then
    G.tap=false
    C4.app="scanner"
    C4.sub=""
    return
  end
end

// ------------------ open / update / draw ------------------

c4Open = function()
  if storage.get("ch3done") != 1 and C4_FORCE_UNLOCK != 1 then
    say("Finish Chapter 3 first!")
    return false
  end
  C2.k=screen.width/360
  C4.on=true
  C3.on=false
  C2.on=false
  C4.mode="world"
  C4.app="home"
  C4.sub=""
  C4.page=0
  C4.powerOff=false
  C4.phoneVisible=true
  C4.timer=0
  C4.timerRun=false
  C4.keyboardOn=false
  C4.input=""
  C4.inputDone=false
  C4.apkPending=""
  C4.photo=null
  C4.photoName=""
  C4.query=""
  C4.mailIndex=0
  C4.noteIndex=0
  C4.zanjiTarget=""
  C4.zanjiMessages=[]
  C4.zanjiOutbox=[]
  C4.zanjiContacts=[]
  C4.zanjiToken=""
  C4.photoIdx=-1
  C4.zanjiStatus=""
  C4.zanjiNumber=""
  C4.registered=false
  C4.conn=null
  c4Load()
  c4ZanjiLoad()
  local c4Fresh=storage.get("c4_initialized")
  if c4Fresh != 1 then
    c4InitState()
    storage.set("c4_initialized",1)
    c4Save()
  end
  if C4.email=="" then
    C4.email="player@hollowmail.net"
    c4Save()
  end
  C4.mt=0
  C4.t=0
  C4.was=false
  c4StartDlg([
    ["You","think","The festival ended, but the Hollow did not."],
    ["You","worry","The message from Chapter 3 is still open: 'The sugar knows your name.'"],
    ["You","think","Tonight I have one job. Find the missing name before 11:52 PM."],
    ["","","The whole phone is in your hands. Tap the bottom-right back key to put it away; tap PHONE on the street to bring it back."]
  ],null)
  return true
end

c4Exit = function()
  c4Save()
  C4.on=false
  C2.on=false
  C3.on=false
  go("chapters")
end

c4Update = function()
  C2.k=screen.width/360
  G.t=(G.t or 0)+1
  C4.t+=1
  if C4.conn!=null then c4ZanjiPoll() end
  c4ZanjiConnect()
  c4Music()
  c4HandleSystem()

  local tt=touch.touching
  local px=(touch.x+screen.width/2)/C2.k
  local py=(screen.height/2-touch.y)/C2.k
  G.tap=false
  if tt then
    if not C4.was then
      C4.drag=0
      C4.lx=px
      C4.ly=py
    end
    C4.drag+=abs(px-C4.lx)+abs(py-C4.ly)
    C4.lx=px
    C4.ly=py
  elsif C4.was then
    if C4.drag<12 then
      G.tap=true
      G.tx=C4.lx*C2.k
      G.ty=C4.ly*C2.k
    end
  end
  C4.was=tt

  // Phone gets tap priority.  The street is interactive only while the phone
  // is put away, preventing taps on phone icons from also clicking houses.
  if G.tap then c4HandleHomeHardware() end

  if C4.phoneVisible and C4.powerOff then
    if G.tap and G.tx/C2.k>110 and G.tx/C2.k<250 and G.ty/C2.k>170 and G.ty/C2.k<390 then
      C4.powerOff=false
      G.tap=false
    end
  end

  // World interaction only happens with the phone put away.
  if C4.mode=="world" and not C4.phoneVisible and G.tap then c4WorldTap() end
end

c4Draw = function()
  C2.k=screen.width/360
  if C4.mode=="dlg" then
    c4DrawDlg()
  elsif C4.mode=="world" then
    c4DrawWorld()
    if C4.phoneVisible then
      c4DrawPhone()
    else
      // Small, clear world HUD control for reopening the full phone.
      vorr(128,584,84,38,10,C_DEEP)
      vtxtC("PHONE",170,600,10,C_GOLD)
      vtxtC("tap to open",170,614,6,C_CREAM)
      c4HUD()
    end
  elsif C4.mode=="pause" then
    c4DrawPause()
  elsif C4.mode=="end" then
    c4End()
  end
  drawToast()
end

// =====================================================
// END CHAPTER 4
// =====================================================
end()



// file: source4.ms
function()
// =====================================================
// SUGAR & SPOOKS - Zanji server v5  (paste into the SERVER source)
// Project Options -> Networking ON.
// - Every player keeps ONE permanent number (saved on their device, proven with a private token).
// - A returning player always gets their same number back. Reconnecting replaces any stale connection.
// - Messages to an offline number are held and delivered when that number connects.
// =====================================================

ZANJI = object end
ZANJI.users = []
ZANJI.owners = object end
ZANJI.pending = []
ZANJI.counter = 0

zanjiFindByConnection = function(c)
  for ui=0 to ZANJI.users.length-1
    if ZANJI.users[ui].connection == c then return ZANJI.users[ui] end
  end
  return null
end

zanjiFindByNumber = function(n)
  for ui=0 to ZANJI.users.length-1
    if ZANJI.users[ui].number == n then return ZANJI.users[ui] end
  end
  return null
end

zanjiTaken = function(n)
  local o = ZANJI.owners[n]
  if o == null or o == 0 or o == "" then return false end
  return true
end

zanjiNewNumber = function()
  local n = ""
  for tri=0 to 50
    ZANJI.counter += 1
    local r = floor(random.next()*900000)+100000
    n = "73"+r
    if not zanjiTaken(n) then return n end
  end
  return "73"+(100000+ZANJI.counter)
end

zanjiTell = function(connection,text)
  connection.send(object
    type = "status"
    text = text
  end)
end

zanjiDeliverPending = function(user)
  local keep = []
  for p in ZANJI.pending
    if p.dest == user.number then
      user.connection.send(object
        type = "msg"
        from = p.from
        body = p.body
      end)
    else
      keep.push(p)
    end
  end
  ZANJI.pending = keep
end

zanjiRegister = function(connection,data)
  local want = ""+data.number
  local tok = ""+data.token
  local n = want
  if want.length != 8 or want.substring(0,2) != "73" then n = zanjiNewNumber() end
  if zanjiTaken(n) and ZANJI.owners[n] != tok then n = zanjiNewNumber() end
  local old = zanjiFindByNumber(n)
  if old != null then
    ZANJI.users.remove(ZANJI.users.indexOf(old))
    old.connection.disconnect()
  end
  ZANJI.owners[n] = tok
  local user = object
    connection = connection
    number = n
  end
  ZANJI.users.push(user)
  connection.send(object
    type = "assigned"
    number = n
  end)
  zanjiTell(connection,"Connected.")
  zanjiDeliverPending(user)
  print("Zanji online: "+n)
end

serverInit = function()
  server = new Server()
  print("Zanji server online.")
end

serverUpdate = function()
  for connection in server.new_connections
    print("Zanji connection: "+connection.id)
  end

  for message in server.messages
    local data = message.data
    local sender = zanjiFindByConnection(message.connection)

    if data.type == "register" then
      if sender == null then zanjiRegister(message.connection,data) end

    elsif data.type == "send" then
      if sender != null then
        local dest = ""+data.dest
        local target = zanjiFindByNumber(dest)
        if target != null then
          print("Delivered "+sender.number+" -> "+dest)
          target.connection.send(object
            type = "msg"
            from = sender.number
            body = data.body
          end)
          zanjiTell(message.connection,"Delivered to "+dest)
        elsif dest.length == 8 and dest.substring(0,2) == "73" then
          if ZANJI.pending.length > 300 then ZANJI.pending.remove(0) end
          print("Held message for "+dest+" from "+sender.number)
          ZANJI.pending.push(object
            dest = dest
            from = sender.number
            body = data.body
          end)
          zanjiTell(message.connection,"Sent. They will see it when they open Zanji.")
        else
          zanjiTell(message.connection,"That is not a Zanji number.")
        end
      end
    end
  end

  for connection in server.closed_connections
    local gone = zanjiFindByConnection(connection)
    if gone != null then
      ZANJI.users.remove(ZANJI.users.indexOf(gone))
      print("Zanji offline: "+gone.number)
    end
  end
end
end()



`
      

var Compiler, LocalLayer;

Compiler = (function() {
  class Compiler {
    constructor(program) {
      var i, j, len, ref, s;
      this.program = program;
      this.code_saves = [];
      this.code = "";
      this.code = [this.code];
      this.routine = new Routine();
      this.locals = new Locals(this);
      this.count = 0;
      ref = this.program.statements;
      for (i = j = 0, len = ref.length; j < len; i = ++j) {
        s = ref[i];
        this.compile(s);
        if (i < this.program.statements.length - 1) {
          this.routine.POP(s);
        }
      }
      this.routine.optimize();
      this.routine.resolveLabels();
      this.count += this.routine.opcodes.length;
      this.routine.locals_size = this.locals.max_index;
    }

    
    // console.info(JSON.stringify @routine.export())
    // @routine = new Routine(0).import( @routine.export() )
    compile(statement) {
      if (statement instanceof Program.Value) {
        return this.compileValue(statement);
      } else if (statement instanceof Program.Operation) {
        return this.compileOperation(statement);
      } else if (statement instanceof Program.Assignment) {
        return this.compileAssignment(statement);
      } else if (statement instanceof Program.Variable) {
        return this.compileVariable(statement);
      } else if (statement instanceof Program.Function) {
        return this.compileFunction(statement);
      } else if (statement instanceof Program.FunctionCall) {
        return this.compileFunctionCall(statement);
      } else if (statement instanceof Program.While) {
        return this.compileWhile(statement);
      }
      if (statement instanceof Program.SelfAssignment) {
        return this.compileSelfAssignment(statement);
      } else if (statement instanceof Program.Braced) {
        return this.compileBraced(statement);
      } else if (statement instanceof Program.CreateObject) {
        return this.compileCreateObject(statement);
      } else if (statement instanceof Program.Field) {
        return this.compileField(statement);
      } else if (statement instanceof Program.Negate) {
        return this.compileNegate(statement);
      } else if (statement instanceof Program.For) {
        return this.compileFor(statement);
      } else if (statement instanceof Program.ForIn) {
        return this.compileForIn(statement);
      } else if (statement instanceof Program.Not) {
        return this.compileNot(statement);
      } else if (statement instanceof Program.Return) {
        return this.compileReturn(statement);
      } else if (statement instanceof Program.Condition) {
        return this.compileCondition(statement);
      } else if (statement instanceof Program.Break) {
        return this.compileBreak(statement);
      } else if (statement instanceof Program.Continue) {
        return this.compileContinue(statement);
      } else if (statement instanceof Program.CreateClass) {
        return this.compileCreateClass(statement);
      } else if (statement instanceof Program.NewCall) {
        return this.compileNewCall(statement);
      } else if (statement instanceof Program.After) {
        return this.compileAfter(statement);
      } else if (statement instanceof Program.Every) {
        return this.compileEvery(statement);
      } else if (statement instanceof Program.Do) {
        return this.compileDo(statement);
      } else if (statement instanceof Program.Sleep) {
        return this.compileSleep(statement);
      } else if (statement instanceof Program.Delete) {
        return this.compileDelete(statement);
      } else if (true) {
        console.info(statement);
        throw "Not implemented";
      }
    }

    compileAssignment(statement) {
      var arg_index, f, i, index, j, ref;
      if (statement.local) {
        if (statement.field instanceof Program.Variable) {
          if (statement.expression instanceof Program.Function) {
            index = this.locals.register(statement.field.identifier); //# register function locally first
            this.compile(statement.expression); //# then compile function which may refer to itself
            this.routine.arg1[this.routine.arg1.length - 1].import_self = index;
            return this.routine.STORE_LOCAL(index, statement);
          } else if (statement.expression instanceof Program.After || statement.expression instanceof Program.Do || statement.expression instanceof Program.Every) {
            index = this.locals.register(statement.field.identifier); //# register thread locally first
            arg_index = this.routine.arg1.length; //# thread main routine will land here
            this.compile(statement.expression); //# then compile function which may refer to itself
            this.routine.arg1[arg_index].import_self = index;
            return this.routine.STORE_LOCAL(index, statement);
          } else {
            this.compile(statement.expression); //# first compile expression which may refer to another local with same name
            index = this.locals.register(statement.field.identifier); //# then register a local for that name
            return this.routine.STORE_LOCAL(index, statement);
          }
        } else {
          throw "illegal";
        }
      } else {
        if (statement.field instanceof Program.Variable) {
          if (this.locals.get(statement.field.identifier) != null) {
            this.compile(statement.expression);
            index = this.locals.get(statement.field.identifier);
            this.routine.STORE_LOCAL(index, statement);
          } else if (statement.expression instanceof Program.CreateClass) {
            return this.compileUpdateClass(statement.expression, statement.field.identifier);
          } else {
            this.compile(statement.expression);
            this.routine.STORE_VARIABLE(statement.field.identifier, statement);
          }
        } else {
          f = statement.field;
          if (f.expression instanceof Program.Variable) {
            if (f.expression.identifier === "this") {
              this.routine.LOAD_THIS(f);
            } else if (this.locals.get(f.expression.identifier) != null) {
              index = this.locals.get(f.expression.identifier);
              this.routine.LOAD_LOCAL_OBJECT(index, f.expression);
            } else if (f.expression.identifier === "global") {
              this.routine.LOAD_GLOBAL(f);
            } else {
              this.routine.LOAD_VARIABLE_OBJECT(f.expression.identifier, statement);
            }
          } else {
            this.compile(f.expression);
            this.routine.MAKE_OBJECT(statement);
          }
          for (i = j = 0, ref = f.chain.length - 2; j <= ref; i = j += 1) {
            this.compile(f.chain[i]);
            this.routine.LOAD_PROPERTY_OBJECT(f.chain[i]);
          }
          this.compile(f.chain[f.chain.length - 1]);
          this.compile(statement.expression);
          return this.routine.STORE_PROPERTY(statement);
        }
      }
    }

    compileSelfAssignment(statement) {
      var c, f, i, index, j, op, ref;
      switch (statement.operation) {
        case Token.TYPE_PLUS_EQUALS:
          op = "ADD";
          break;
        case Token.TYPE_MINUS_EQUALS:
          op = "SUB";
          break;
        case Token.TYPE_MULTIPLY_EQUALS:
          op = "MUL";
          break;
        case Token.TYPE_DIVIDE_EQUALS:
          op = "DIV";
          break;
        case Token.TYPE_MODULO_EQUALS:
          op = "MODULO";
          break;
        case Token.TYPE_AND_EQUALS:
          op = "BINARY_AND";
          break;
        case Token.TYPE_OR_EQUALS:
          op = "BINARY_OR";
      }
      if (statement.field instanceof Program.Variable) {
        if (this.locals.get(statement.field.identifier) != null) {
          index = this.locals.get(statement.field.identifier);
          this.routine.LOAD_LOCAL(index, statement);
          this.compile(statement.expression);
          this.routine[op](statement, 1);
          this.routine.STORE_LOCAL(index, statement);
        } else {
          this.routine.LOAD_VARIABLE(statement.field.identifier, statement);
          this.compile(statement.expression);
          this.routine[op](statement, 1);
          this.routine.STORE_VARIABLE(statement.field.identifier, statement);
        }
      } else {
        f = statement.field;
        if (f.expression instanceof Program.Variable) {
          if (f.expression.identifier === "this") {
            this.routine.LOAD_THIS(f);
          } else if (this.locals.get(f.expression.identifier) != null) {
            index = this.locals.get(f.expression.identifier);
            this.routine.LOAD_LOCAL_OBJECT(index, statement);
          } else if (f.expression.identifier === "global") {
            this.routine.LOAD_GLOBAL(f);
          } else {
            this.routine.LOAD_VARIABLE_OBJECT(f.expression.identifier, statement);
          }
        } else {
          this.compile(f.expression);
          this.routine.MAKE_OBJECT(statement);
        }
        for (i = j = 0, ref = f.chain.length - 2; j <= ref; i = j += 1) {
          this.compile(f.chain[i]);
          this.routine.LOAD_PROPERTY_OBJECT(f.chain[i]);
        }
        c = f.chain[f.chain.length - 1];
        this.compile(f.chain[f.chain.length - 1]);
        this.routine.LOAD_PROPERTY_ATOP(statement);
        this.compile(statement.expression);
        this.routine[op](statement, 1);
        return this.routine.STORE_PROPERTY(statement);
      }
    }

    compileOperation(op) {
      var jump, ref, ref1;
      if ((ref = op.operation) === "+" || ref === "-" || ref === "*" || ref === "/" || ref === "%" || ref === "&" || ref === "|" || ref === "<<" || ref === ">>") {
        this.compile(op.term1);
        this.compile(op.term2);
        switch (op.operation) {
          case "+":
            this.routine.ADD(op);
            break;
          case "-":
            this.routine.SUB(op);
            break;
          case "*":
            this.routine.MUL(op);
            break;
          case "/":
            this.routine.DIV(op);
            break;
          case "%":
            this.routine.MODULO(op);
            break;
          case "&":
            this.routine.BINARY_AND(op);
            break;
          case "|":
            this.routine.BINARY_OR(op);
            break;
          case "<<":
            this.routine.SHIFT_LEFT(op);
            break;
          case ">>":
            this.routine.SHIFT_RIGHT(op);
        }
      } else if ((ref1 = op.operation) === "==" || ref1 === "!=" || ref1 === "<" || ref1 === ">" || ref1 === "<=" || ref1 === ">=") {
        this.compile(op.term1);
        this.compile(op.term2);
        switch (op.operation) {
          case "==":
            this.routine.EQ(op);
            break;
          case "!=":
            this.routine.NEQ(op);
            break;
          case "<":
            this.routine.LT(op);
            break;
          case ">":
            this.routine.GT(op);
            break;
          case "<=":
            this.routine.LTE(op);
            break;
          case ">=":
            this.routine.GTE(op);
        }
      } else if (op.operation === "and") {
        jump = this.routine.createLabel("and");
        op.term1.nowarning = true;
        op.term2.nowarning = true;
        this.compile(op.term1);
        this.routine.JUMPN_NOPOP(jump, op);
        this.routine.POP(op);
        this.compile(op.term2);
        return this.routine.setLabel(jump);
      } else if (op.operation === "or") {
        jump = this.routine.createLabel("or");
        op.term1.nowarning = true;
        op.term2.nowarning = true;
        this.compile(op.term1);
        this.routine.JUMPY_NOPOP(jump, op);
        this.routine.POP(op);
        this.compile(op.term2);
        return this.routine.setLabel(jump);
      } else if (op.operation === "^") {
        this.compile(op.term1);
        this.compile(op.term2);
        return this.routine.BINARY_OP(Compiler.predefined_binary_functions.pow, op);
      } else {
        return "";
      }
    }

    compileBraced(expression) {
      this.compile(expression.expression);
    }

    compileNegate(expression) {
      if (expression.expression instanceof Program.Value && expression.expression.type === Program.Value.TYPE_NUMBER) {
        return this.routine.LOAD_VALUE(-expression.expression.value, expression);
      } else {
        this.compile(expression.expression);
        return this.routine.NEGATE(expression);
      }
    }

    compileNot(expression) {
      expression.expression.nowarning = true;
      this.compile(expression.expression);
      return this.routine.NOT(expression);
    }

    compileValue(value) {
      var i, j, ref;
      switch (value.type) {
        case Program.Value.TYPE_NUMBER:
          this.routine.LOAD_VALUE(value.value, value);
          break;
        case Program.Value.TYPE_STRING:
          this.routine.LOAD_VALUE(value.value, value);
          break;
        case Program.Value.TYPE_ARRAY:
          this.routine.CREATE_ARRAY(value);
          for (i = j = 0, ref = value.value.length - 1; j <= ref; i = j += 1) {
            this.routine.LOAD_VALUE(i, value);
            this.compile(value.value[i]);
            this.routine.CREATE_PROPERTY(value);
          }
      }
    }

    compileVariable(variable) {
      var index, v;
      v = variable.identifier;
      if (v === "this") {
        return this.routine.LOAD_THIS(variable);
      } else if (v === "global") {
        return this.routine.LOAD_GLOBAL(variable);
      } else if (Compiler.predefined_values[v] != null) {
        return this.routine.LOAD_VALUE(Compiler.predefined_values[v], variable);
      } else if (this.locals.get(v) != null) {
        index = this.locals.get(v);
        return this.routine.LOAD_LOCAL(index, variable);
      } else {
        return this.routine.LOAD_VARIABLE(v, variable);
      }
    }

    compileField(field) {
      var c, i, id, index, j, k, len, ref, ref1;
      if (field.expression.identifier === "keyboard" || field.expression.identifier === "gamepad") {
        field.nowarning = true;
      }
      c = field.chain[field.chain.length - 1];
      if (c instanceof Program.Value && c.value === "type") {
        if (field.chain.length === 1) {
          if (field.expression instanceof Program.Variable) { // variable.type
            id = field.expression.identifier;
            if (this.locals.get(id) != null) {
              index = this.locals.get(id);
              this.routine.LOAD_LOCAL(index, field);
              this.routine.TYPE(field);
            } else if (Compiler.predefined_values[id] != null) {
              this.routine.LOAD_VALUE("number", field);
            } else if ((Compiler.predefined_unary_functions[id] != null) || Compiler.predefined_binary_functions[id]) {
              this.routine.LOAD_VALUE("function", field);
            } else {
              this.routine.VARIABLE_TYPE(id, field.expression);
            }
          } else {
            this.compile(field.expression);
            this.routine.TYPE(field);
          }
        } else {
          this.compile(field.expression);
          for (i = j = 0, ref = field.chain.length - 3; j <= ref; i = j += 1) {
            this.compile(field.chain[i]);
            this.routine.LOAD_PROPERTY(field);
          }
          this.compile(field.chain[field.chain.length - 2]);
          this.routine.PROPERTY_TYPE(field.expression);
        }
      } else {
        this.compile(field.expression);
        ref1 = field.chain;
        for (k = 0, len = ref1.length; k < len; k++) {
          c = ref1[k];
          this.compile(c);
          this.routine.LOAD_PROPERTY(field);
        }
      }
    }

    compileFieldParent(field) {
      var c, i, j, ref;
      this.compile(field.expression);
      for (i = j = 0, ref = field.chain.length - 2; j <= ref; i = j += 1) {
        c = field.chain[i];
        this.compile(c);
        this.routine.LOAD_PROPERTY(field);
      }
    }

    compileFunctionCall(call) {
      var a, funk, i, index, j, k, l, len, len1, len2, len3, len4, m, n, ref, ref1, ref2, ref3, ref4;
      if (call.expression instanceof Program.Field) {
        ref = call.args;
        for (i = j = 0, len = ref.length; j < len; i = ++j) {
          a = ref[i];
          this.compile(a);
        }
        this.compileFieldParent(call.expression);
        this.compile(call.expression.chain[call.expression.chain.length - 1]);
        return this.routine.FUNCTION_APPLY_PROPERTY(call.args.length, call);
      } else if (call.expression instanceof Program.Variable) {
        if (Compiler.predefined_unary_functions[call.expression.identifier] != null) {
          funk = Compiler.predefined_unary_functions[call.expression.identifier];
          if (call.args.length > 0) {
            this.compile(call.args[0]);
          } else {
            this.routine.LOAD_VALUE(0, call);
          }
          return this.routine.UNARY_OP(funk, call);
        } else if (Compiler.predefined_binary_functions[call.expression.identifier] != null) {
          funk = Compiler.predefined_binary_functions[call.expression.identifier];
          if (call.args.length > 0) {
            this.compile(call.args[0]);
          } else {
            this.routine.LOAD_VALUE(0, call);
          }
          if (call.args.length > 1) {
            this.compile(call.args[1]);
          } else {
            this.routine.LOAD_VALUE(0, call);
          }
          return this.routine.BINARY_OP(funk, call);
        } else if (call.expression.identifier === "super") {
          ref1 = call.args;
          for (i = k = 0, len1 = ref1.length; k < len1; i = ++k) {
            a = ref1[i];
            this.compile(a);
          }
          return this.routine.SUPER_CALL(call.args.length, call);
        } else if (this.locals.get(call.expression.identifier) != null) {
          ref2 = call.args;
          for (i = l = 0, len2 = ref2.length; l < len2; i = ++l) {
            a = ref2[i];
            this.compile(a);
          }
          index = this.locals.get(call.expression.identifier);
          this.routine.LOAD_LOCAL(index, call);
          return this.routine.FUNCTION_CALL(call.args.length, call);
        } else {
          ref3 = call.args;
          for (i = m = 0, len3 = ref3.length; m < len3; i = ++m) {
            a = ref3[i];
            this.compile(a);
          }
          this.routine.LOAD_VALUE(call.expression.identifier, call);
          return this.routine.FUNCTION_APPLY_VARIABLE(call.args.length, call);
        }
      } else {
        ref4 = call.args;
        for (n = 0, len4 = ref4.length; n < len4; n++) {
          a = ref4[n];
          this.compile(a);
        }
        this.compile(call.expression);
        return this.routine.FUNCTION_CALL(call.args.length, call);
      }
    }

    compileFor(forloop) {
      var for_continue, for_end, for_start, iterator, save_break, save_continue;
      iterator = this.locals.register(forloop.iterator);
      this.locals.allocate(); // range_to
      this.locals.allocate(); // step
      this.compile(forloop.range_from);
      this.routine.STORE_LOCAL(iterator, forloop);
      this.routine.POP(forloop);
      this.compile(forloop.range_to);
      if (forloop.range_by !== 0) {
        this.compile(forloop.range_by);
      } else {
        this.routine.LOAD_VALUE(0, forloop);
      }
      for_start = this.routine.createLabel("for_start");
      for_continue = this.routine.createLabel("for_continue");
      for_end = this.routine.createLabel("for_end");
      this.routine.FORLOOP_INIT([iterator, for_end], forloop);
      this.routine.setLabel(for_start);
      this.locals.push();
      save_break = this.break_label;
      save_continue = this.continue_label;
      this.break_label = for_end;
      this.continue_label = for_continue;
      this.compileSequence(forloop.sequence);
      this.break_label = save_break;
      this.continue_label = save_continue;
      this.routine.setLabel(for_continue);
      this.routine.FORLOOP_CONTROL([iterator, for_start], forloop);
      this.routine.setLabel(for_end);
      return this.locals.pop();
    }

    compileForIn(forloop) {
      var for_continue, for_end, for_start, iterator, save_break, save_continue;
      iterator = this.locals.register(forloop.iterator);
      this.locals.allocate(); // array
      this.locals.allocate(); // index
      this.compile(forloop.list);
      for_start = this.routine.createLabel("for_start");
      for_continue = this.routine.createLabel("for_continue");
      for_end = this.routine.createLabel("for_end");
      this.routine.FORIN_INIT([iterator, for_end], forloop);
      this.routine.setLabel(for_start);
      this.locals.push();
      save_break = this.break_label;
      save_continue = this.continue_label;
      this.break_label = for_end;
      this.continue_label = for_continue;
      this.compileSequence(forloop.sequence);
      this.break_label = save_break;
      this.continue_label = save_continue;
      this.routine.setLabel(for_continue);
      this.routine.FORIN_CONTROL([iterator, for_start], forloop);
      this.routine.setLabel(for_end);
      return this.locals.pop();
    }

    compileSequence(sequence) {
      var i, j, ref;
      for (i = j = 0, ref = sequence.length - 1; j <= ref; i = j += 1) {
        if (!sequence[i].nopop) {
          this.routine.POP(sequence[i]);
        }
        this.compile(sequence[i]);
      }
    }

    compileWhile(whiloop) {
      var end, save_break, save_continue, start;
      this.locals.push();
      start = this.routine.createLabel("while_start");
      end = this.routine.createLabel("while_end");
      this.routine.LOAD_VALUE(0, whiloop);
      this.routine.setLabel(start);
      this.compile(whiloop.condition);
      this.routine.JUMPN(end);
      save_break = this.break_label;
      save_continue = this.continue_label;
      this.break_label = end;
      this.continue_label = start;
      this.compileSequence(whiloop.sequence);
      this.routine.JUMP(start, whiloop);
      this.break_label = save_break;
      this.continue_label = save_continue;
      this.routine.setLabel(end);
      return this.locals.pop();
    }

    compileBreak(statement) {
      if (this.break_label != null) {
        return this.routine.JUMP(this.break_label);
      }
    }

    compileContinue(statement) {
      if (this.continue_label != null) {
        return this.routine.JUMP(this.continue_label);
      }
    }

    compileFunction(func) {
      var r;
      r = this.compileFunctionBody(func);
      return this.routine.LOAD_ROUTINE(r, func);
    }

    compileFunctionBody(func) {
      var a, args, i, index, j, k, l, label, len, local_index, locals, m, numargs, r, ref, ref1, ref2, ref3, routine;
      routine = this.routine;
      locals = this.locals;
      this.routine = new Routine(func.args != null ? func.args.length : 0);
      this.locals = new Locals(this, locals);
      local_index = this.locals.index;
      this.routine.uses_arguments = true;
      if (func.args != null) {
        if (this.routine.uses_arguments) {
          args = this.locals.register("arguments");
          this.routine.STORE_LOCAL(args, func);
          this.routine.POP(func);
        }
        numargs = this.locals.register("+numargs");
        this.routine.STORE_LOCAL(numargs, func);
        this.routine.POP(func);
        for (i = j = ref = func.args.length - 1; j >= 0; i = j += -1) {
          a = func.args[i];
          index = this.locals.register(a.name);
          this.routine.STORE_LOCAL(index, func);
          this.routine.POP(func);
        }
        for (i = k = 0, ref1 = func.args.length - 1; k <= ref1; i = k += 1) {
          a = func.args[i];
          if (a.default != null) {
            index = this.locals.get(a.name);
            label = this.routine.createLabel("default_arg");
            this.routine.LOAD_VALUE(i, func);
            this.routine.LOAD_LOCAL(numargs, func);
            this.routine.LT(func);
            this.routine.JUMPY(label, func);
            this.compile(a.default);
            this.routine.STORE_LOCAL(index, func);
            this.routine.POP(func);
            this.routine.setLabel(label);
          }
        }
      }
      if (func.sequence.length > 0) {
        for (i = l = 0, ref2 = func.sequence.length - 1; l <= ref2; i = l += 1) {
          this.compile(func.sequence[i]);
          if (i < func.sequence.length - 1) {
            this.routine.POP(func.sequence[i]);
          } else {
            this.routine.RETURN(func.sequence[i]);
          }
        }
      } else {
        this.routine.LOAD_VALUE(0, func);
        this.routine.RETURN(func);
      }
      if ((func.args != null) && !this.locals.arguments_used) {
        this.routine.uses_arguments = false;
        this.routine.remove(0);
        this.routine.remove(0);
      }
      index = 0;
      ref3 = this.locals.imports;
      for (m = 0, len = ref3.length; m < len; m++) {
        i = ref3[m];
        this.routine.OP_INSERT(OPCODES.LOAD_IMPORT, func, index, index * 3);
        this.routine.OP_INSERT(OPCODES.STORE_LOCAL, func, i.index, index * 3 + 1);
        this.routine.OP_INSERT(OPCODES.POP, func, 0, index * 3 + 2);
        this.routine.import_refs.push(i.source);
        index += 1;
      }
      this.routine.optimize();
      this.routine.resolveLabels();
      this.count += this.routine.opcodes.length;
      r = this.routine;
      // console.info r.toString()
      this.routine.locals_size = this.locals.max_index;
      this.routine = routine;
      this.locals = locals;
      return r;
    }

    compileReturn(ret) {
      if (ret.expression != null) {
        this.compile(ret.expression);
        return this.routine.RETURN(ret);
      } else {
        this.routine.LOAD_VALUE(0, ret);
        return this.routine.RETURN(ret);
      }
    }

    compileCondition(condition) {
      var c, chain, condition_end, condition_next, i, j, ref;
      chain = condition.chain;
      this.routine.LOAD_VALUE(0, condition);
      condition_end = this.routine.createLabel("condition_end");
      for (i = j = 0, ref = chain.length - 1; j <= ref; i = j += 1) {
        condition_next = this.routine.createLabel("condition_next");
        c = chain[i];
        c.condition.nowarning = true;
        this.compile(c.condition);
        this.routine.JUMPN(condition_next);
        this.locals.push();
        this.compileSequence(c.sequence);
        this.locals.pop();
        this.routine.JUMP(condition_end, condition);
        this.routine.setLabel(condition_next);
        if (i === chain.length - 1 && (c.else != null)) {
          this.locals.push();
          this.compileSequence(c.else);
          this.locals.pop();
        }
      }
      this.routine.setLabel(condition_end);
    }

    formatField(field) {
      if (field === "constructor") {
        field = "_constructor";
      }
      return field.toString().replace(/"/g, "\\\"");
    }

    compileCreateObject(statement) {
      var f, j, len, ref;
      this.routine.CREATE_OBJECT(statement);
      ref = statement.fields;
      for (j = 0, len = ref.length; j < len; j++) {
        f = ref[j];
        this.routine.LOAD_VALUE(f.field, statement);
        this.compile(f.value);
        this.routine.CREATE_PROPERTY(statement);
      }
    }

    compileCreateClass(statement) {
      var f, j, len, ref, variable;
      if (statement.ext != null) {
        statement.ext.nowarning = true;
        this.compile(statement.ext);
      } else {
        this.routine.LOAD_VALUE(0, statement);
      }
      variable = (statement.ext != null) && statement.ext instanceof Program.Variable ? statement.ext.identifier : 0;
      this.routine.CREATE_CLASS(variable, statement);
      ref = statement.fields;
      for (j = 0, len = ref.length; j < len; j++) {
        f = ref[j];
        this.routine.LOAD_VALUE(f.field, statement);
        this.compile(f.value);
        this.routine.CREATE_PROPERTY(statement);
      }
    }

    compileUpdateClass(statement, variable) {
      this.compileCreateClass(statement);
      return this.routine.UPDATE_CLASS(variable, statement);
    }

    compileNewCall(statement) {
      var a, call, i, j, len, ref;
      call = statement.expression;
      this.routine.LOAD_VALUE(0, statement); // reserve spot on stack for the class instance
      ref = call.args;
      for (i = j = 0, len = ref.length; j < len; i = ++j) {
        a = ref[i];
        this.compile(a);
      }
      this.compile(call.expression);
      this.routine.NEW_CALL(call.args.length, statement);
      return this.routine.POP(statement); // pop return value of class constructor
    }

    compileAfter(after) {
      var r;
      r = this.compileFunctionBody(after);
      this.routine.LOAD_ROUTINE(r, after);
      this.compile(after.delay);
      if ((after.multiplier != null) && after.multiplier !== 1) {
        this.routine.LOAD_VALUE(after.multiplier, after);
        this.routine.MUL(after);
      }
      return this.routine.AFTER(after);
    }

    compileEvery(every) {
      var r;
      r = this.compileFunctionBody(every);
      this.routine.LOAD_ROUTINE(r, every);
      this.compile(every.delay);
      if ((every.multiplier != null) && every.multiplier !== 1) {
        this.routine.LOAD_VALUE(every.multiplier, every);
        this.routine.MUL(every);
      }
      return this.routine.EVERY(every);
    }

    compileDo(dostuff) {
      var r;
      r = this.compileFunctionBody(dostuff);
      this.routine.LOAD_ROUTINE(r, dostuff);
      return this.routine.DO(dostuff);
    }

    compileSleep(sleep) {
      this.compile(sleep.delay);
      if ((sleep.multiplier != null) && sleep.multiplier !== 1) {
        this.routine.LOAD_VALUE(sleep.multiplier, sleep);
        this.routine.MUL(sleep);
      }
      return this.routine.SLEEP(sleep);
    }

    compileDelete(del) {
      var chain, i, j, ref;
      if (del.field instanceof Program.Variable) {
        this.routine.LOAD_THIS(del);
        this.routine.LOAD_VALUE(del.field.identifier, del);
        this.routine.DELETE(del);
      } else {
        this.compile(del.field.expression);
        chain = del.field.chain;
        for (i = j = 0, ref = chain.length - 1; j <= ref; i = j += 1) {
          this.compile(chain[i]);
          if (i < chain.length - 1) {
            this.routine.LOAD_PROPERTY(del);
          }
        }
        this.routine.DELETE(del);
      }
    }

    exec(context) {
      this.processor = new Processor();
      this.processor.load(this.routine);
      return this.processor.run(context);
    }

  };

  Compiler.predefined_unary_functions = {
    "round": Math.round,
    "floor": Math.floor,
    "ceil": Math.ceil,
    "abs": Math.abs,
    "sqrt": Math.sqrt,
    "sin": Math.sin,
    "cos": Math.cos,
    "tan": Math.tan,
    "acos": Math.acos,
    "asin": Math.asin,
    "atan": Math.atan,
    "sind": function(x) {
      return Math.sin(x * Math.PI / 180);
    },
    "cosd": function(x) {
      return Math.cos(x * Math.PI / 180);
    },
    "tand": function(x) {
      return Math.tan(x * Math.PI / 180);
    },
    "asind": function(x) {
      return Math.asin(x) / Math.PI * 180;
    },
    "acosd": function(x) {
      return Math.acos(x) / Math.PI * 180;
    },
    "atand": function(x) {
      return Math.atan(x) / Math.PI * 180;
    },
    "log": Math.log,
    "exp": Math.exp
  };

  Compiler.predefined_binary_functions = {
    "min": Math.min,
    "max": Math.max,
    "pow": Math.pow,
    "atan2": Math.atan2,
    "atan2d": function(y, x) {
      return Math.atan2(y, x) / Math.PI * 180;
    }
  };

  Compiler.predefined_values = {
    PI: Math.PI,
    true: 1,
    false: 0
  };

  return Compiler;

}).call(this);

this.Locals = class Locals {
  constructor(compiler, parent = null) {
    this.compiler = compiler;
    this.parent = parent;
    this.layers = [];
    this.index = 0;
    this.max_index = 0;
    this.push();
    this.imports = [];
  }

  increment() {
    var spot;
    spot = this.index++;
    this.max_index = Math.max(this.index, this.max_index);
    return spot;
  }

  push() {
    return this.layers.push(new LocalLayer(this));
  }

  pop() {
    // resetting the @index below was causing erasure of outer locals
    // when used after the block ; such reset is not needed
    //@index = @layers[@layers.length-1].start_index
    return this.layers.splice(this.layers.length - 1, 1);
  }

  register(name) {
    return this.layers[this.layers.length - 1].register(name);
  }

  allocate() {
    return this.layers[this.layers.length - 1].allocate();
  }

  get(name) {
    var i, index, j, ref, v;
    if (name === "arguments") {
      this.arguments_used = true;
    }
    for (i = j = ref = this.layers.length - 1; j >= 0; i = j += -1) {
      v = this.layers[i].get(name);
      if (v != null) {
        return v;
      }
    }
    if (this.parent != null) {
      v = this.parent.get(name);
      if (v != null) {
        index = this.register(name);
        this.imports.push({
          name: name,
          index: index,
          source: v
        });
        return index;
      }
    }
    return null;
  }

};

LocalLayer = class LocalLayer {
  constructor(locals1) {
    this.locals = locals1;
    this.start_index = this.locals.index;
    this.registered = {};
  }

  register(name) {
    return this.registered[name] = this.locals.increment();
  }

  allocate() {
    return this.locals.increment();
  }

  get(name) {
    if (this.registered[name] != null) {
      return this.registered[name];
    } else {
      return null;
    }
  }

};


this.Parser = (function() {
  class Parser {
    constructor(input, filename = "") {
      this.input = input;
      this.filename = filename;
      if (/^\s*\/\/\s*javascript\s*\n/.test(this.input)) {
        this.input = 'system.javascript("""\n\n' + this.input.replace(/\\/g, "\\\\") + '\n\n""")';
      }
      this.tokenizer = new Tokenizer(this.input, this.filename);
      this.program = new Program();
      this.current_block = [];
      this.current = {
        line: 1,
        column: 1
      };
      this.verbose = false;
      this.nesting = 0;
      this.object_nesting = 0;
      this.not_terminated = [];
      this.api_reserved = {
        screen: true,
        audio: true,
        keyboard: true,
        gamepad: true,
        sprites: true,
        sounds: true,
        music: true,
        assets: true,
        asset_manager: true,
        maps: true,
        touch: true,
        mouse: true,
        fonts: true,
        Sound: true,
        Image: true,
        Sprite: true,
        Map: true,
        system: true,
        storage: true,
        print: true,
        random: true,
        Function: true,
        List: true,
        Object: true,
        String: true,
        Number: true
      };
    }

    nextToken() {
      var token;
      token = this.tokenizer.next();
      if (token == null) {
        this.unexpected_eof = true;
        throw "Unexpected end of file";
      }
      return this.current = token;
    }

    nextTokenOptional() {
      var token;
      token = this.tokenizer.next();
      if (token != null) {
        this.current = token;
      }
      return token;
    }

    parse() {
      var err, expression, nt, token;
      try {
        this.warnings = [];
        while (true) {
          expression = this.parseLine();
          if ((expression == null) && !this.tokenizer.finished()) {
            token = this.tokenizer.next();
            if ((token != null) && token.reserved_keyword) {
              if (token.value === "end") {
                this.error("Too many 'end'");
              } else {
                this.error(`Misuse of reserved keyword: '${token.value}'`);
              }
            } else {
              this.error("Unexpected data");
            }
          }
          if (expression === null) {
            break;
          }
          this.current_block.push(expression);
          this.program.add(expression);
          if (this.verbose) {
            console.info(expression);
          }
        }
        return this;
      } catch (error1) {
        err = error1;
        //console.info "Error at line: #{@current.line} column: #{@current.column}"
        if (this.not_terminated.length > 0 && err === "Unexpected end of file") {
          nt = this.not_terminated[this.not_terminated.length - 1];
          return this.error_info = {
            error: `Unterminated '${nt.value}' ; no matching 'end' found`,
            line: nt.line,
            column: nt.column
          };
        } else {
          return this.error_info = {
            error: err,
            line: this.current.line,
            column: this.current.column
          };
        }
      }
    }

    //console.error err
    parseLine() {
      var token;
      token = this.nextTokenOptional();
      if (token == null) {
        return null;
      }
      switch (token.type) {
        case Token.TYPE_RETURN:
          return new Program.Return(token, this.parseExpression());
        case Token.TYPE_BREAK:
          return new Program.Break(token);
        case Token.TYPE_CONTINUE:
          return new Program.Continue(token);
        case Token.TYPE_LOCAL:
          return this.parseLocalAssignment(token);
        default:
          this.tokenizer.pushBack(token);
          return this.parseExpression();
      }
    }

    parseExpression(filter, first_function_call = false) {
      var access, expression;
      expression = this.parseExpressionStart();
      if (expression == null) {
        return null;
      }
      while (true) {
        access = this.parseExpressionSuffix(expression, filter);
        if (access == null) {
          return expression;
        }
        if (first_function_call && access instanceof Program.FunctionCall) {
          return access;
        }
        expression = access;
      }
    }

    assertExpression(filter, first_function_call = false) {
      var exp;
      exp = this.parseExpression(filter, first_function_call);
      if (exp == null) {
        throw "Expression expected";
      }
      return exp;
    }

    parseExpressionSuffix(expression, filter) {
      var field, identifier, token;
      token = this.nextTokenOptional();
      if (token == null) {
        return (filter === "self" ? expression : null);
      }
      switch (token.type) {
        case Token.TYPE_DOT:
          if (expression instanceof Program.Value && expression.type === Program.Value.TYPE_NUMBER) {
            this.tokenizer.pushBack(token);
            return null;
          } else {
            this.tokenizer.changeNumberToIdentifier();
            identifier = this.assertBroadIdentifier("Expected identifier");
            return Program.CreateFieldAccess(token, expression, new Program.Value(identifier, Program.Value.TYPE_STRING, identifier.value));
          }
          break;
        case Token.TYPE_OPEN_BRACKET:
          field = this.assertExpression();
          this.assert(Token.TYPE_CLOSED_BRACKET, "Expected ']'");
          return Program.CreateFieldAccess(token, expression, field);
        case Token.TYPE_OPEN_BRACE:
          return this.parseFunctionCall(token, expression);
        case Token.TYPE_EQUALS:
          return this.parseAssignment(token, expression);
        case Token.TYPE_PLUS_EQUALS:
          return this.parseSelfAssignment(token, expression, token.type);
        case Token.TYPE_MINUS_EQUALS:
          return this.parseSelfAssignment(token, expression, token.type);
        case Token.TYPE_MULTIPLY_EQUALS:
          return this.parseSelfAssignment(token, expression, token.type);
        case Token.TYPE_DIVIDE_EQUALS:
          return this.parseSelfAssignment(token, expression, token.type);
        case Token.TYPE_MODULO_EQUALS:
        case Token.TYPE_AND_EQUALS:
        case Token.TYPE_OR_EQUALS:
          return this.parseSelfAssignment(token, expression, token.type);
        default:
          if (filter === "self") {
            this.tokenizer.pushBack(token);
            return expression;
          } else if (token.is_binary_operator && filter !== "noop") {
            return this.parseBinaryOperation(token, expression);
          } else {
            this.tokenizer.pushBack(token);
            return null;
          }
      }
    }

    parseExpressionStart() {
      var next, token;
      token = this.nextTokenOptional();
      if (token == null) {
        return null;
      }
      switch (token.type) {
        case Token.TYPE_IDENTIFIER: // variable name
          return new Program.Variable(token, token.value);
        case Token.TYPE_NUMBER:
          return this.parseNumberExpression(token);
        case Token.TYPE_PLUS:
          return this.assertExpression();
        case Token.TYPE_MINUS:
          return this.parseExpressionSuffix(new Program.Negate(token, this.assertExpression("noop")), "self");
        case Token.TYPE_NOT:
          return this.parseExpressionSuffix(new Program.Not(token, this.assertExpression("noop")), "self");
        case Token.TYPE_STRING:
          return this.parseStringExpression(token);
        case Token.TYPE_IF:
          return this.parseIf(token);
        case Token.TYPE_FOR:
          return this.parseFor(token);
        case Token.TYPE_WHILE:
          return this.parseWhile(token);
        case Token.TYPE_OPEN_BRACE:
          return this.parseBracedExpression(token);
        case Token.TYPE_OPEN_BRACKET:
          return this.parseArray(token);
        case Token.TYPE_FUNCTION:
          return this.parseFunction(token);
        case Token.TYPE_OBJECT:
          return this.parseObject(token);
        case Token.TYPE_CLASS:
          return this.parseClass(token);
        case Token.TYPE_NEW:
          return this.parseNew(token);
        case Token.TYPE_DOT:
          next = this.assert(Token.TYPE_NUMBER, "malformed number");
          if (!Number.isInteger(next.value)) {
            throw "malformed number";
          }
          return new Program.Value(token, Program.Value.TYPE_NUMBER, Number.parseFloat(`.${next.string_value}`));
        case Token.TYPE_AFTER:
          return this.parseAfter(token);
        case Token.TYPE_EVERY:
          return this.parseEvery(token);
        case Token.TYPE_DO:
          return this.parseDo(token);
        case Token.TYPE_SLEEP:
          return this.parseSleep(token);
        case Token.TYPE_DELETE:
          return this.parseDelete(token);
        default:
          this.tokenizer.pushBack(token);
          return null;
      }
    }

    parseNumberExpression(number) {
      return new Program.Value(number, Program.Value.TYPE_NUMBER, number.value);
    }

    parseStringExpression(string) {
      var token;
      token = this.nextTokenOptional();
      if (token == null) {
        return new Program.Value(string, Program.Value.TYPE_STRING, string.value);
      } else {
        this.tokenizer.pushBack(token);
        return new Program.Value(string, Program.Value.TYPE_STRING, string.value);
      }
    }

    parseArray(bracket) {
      var res, token;
      res = [];
      while (true) {
        token = this.nextToken();
        if (token.type === Token.TYPE_CLOSED_BRACKET) {
          return new Program.Value(bracket, Program.Value.TYPE_ARRAY, res);
        } else if (token.type === Token.TYPE_COMMA) {
          continue;
        } else {
          this.tokenizer.pushBack(token);
          res.push(this.assertExpression());
        }
      }
    }

    parseBinaryOperation(operation, term1) {
      var ops, terms, token;
      ops = [new Program.Operation(operation, operation.value)];
      terms = [term1];
      terms.push(this.assertExpression("noop"));
      while (true) {
        token = this.nextTokenOptional();
        if (token == null) {
          break;
        }
        if (!token.is_binary_operator) {
          this.tokenizer.pushBack(token);
          break;
        }
        ops.push(new Program.Operation(token, token.value));
        terms.push(this.assertExpression("noop"));
      }
      return Program.BuildOperations(ops, terms);
    }

    parseAssignment(token, expression) {
      var res;
      if (!(expression instanceof Program.Variable) && !(expression instanceof Program.Field)) {
        throw "Expected variable identifier or property";
      }
      if (this.object_nesting === 0 && expression instanceof Program.Variable && this.api_reserved[expression.identifier]) {
        this.warnings.push({
          type: "assigning_api_variable",
          identifier: expression.identifier,
          line: token.line,
          column: token.column
        });
      }
      if (expression instanceof Program.Field) {
        this.object_nesting += 1;
        res = new Program.Assignment(token, expression, this.assertExpression());
        this.object_nesting -= 1;
      } else {
        res = new Program.Assignment(token, expression, this.assertExpression());
      }
      return res;
    }

    parseSelfAssignment(token, expression, operation) {
      if (!(expression instanceof Program.Variable) && !(expression instanceof Program.Field)) {
        throw "Expected variable identifier or property";
      }
      return new Program.SelfAssignment(token, expression, operation, this.assertExpression());
    }

    parseLocalAssignment(local) {
      var identifier;
      identifier = this.assert(Token.TYPE_IDENTIFIER, "Expected identifier");
      this.assert(Token.TYPE_EQUALS, "Expected '='");
      return new Program.Assignment(local, new Program.Variable(identifier, identifier.value), this.assertExpression(), true);
    }

    parseBracedExpression(open) {
      var expression, token;
      expression = this.assertExpression();
      token = this.nextToken();
      if (token.type === Token.TYPE_CLOSED_BRACE) {
        return new Program.Braced(open, expression);
      } else {
        return this.error("missing closing parenthese");
      }
    }

    parseFunctionCall(brace_token, expression) {
      var args, start, token;
      args = [];
      this.last_function_call = new Program.FunctionCall(brace_token, expression, args);
      this.last_function_call.argslimits = [];
      while (true) {
        token = this.nextTokenOptional();
        if (token == null) {
          return this.error("missing closing parenthese");
        } else if (token.type === Token.TYPE_CLOSED_BRACE) {
          return new Program.FunctionCall(token, expression, args);
        } else if (token.type === Token.TYPE_COMMA) {
          continue;
        } else {
          this.tokenizer.pushBack(token);
          start = token.start;
          args.push(this.assertExpression());
          this.last_function_call.argslimits.push({
            start: start,
            end: this.tokenizer.index - 1
          });
        }
      }
    }

    addTerminable(token) {
      return this.not_terminated.push(token);
    }

    endTerminable() {
      if (this.not_terminated.length > 0) {
        this.not_terminated.splice(this.not_terminated.length - 1, 1);
      }
    }

    parseFunction(funk) {
      var args, line, sequence, token;
      this.nesting += 1;
      this.addTerminable(funk);
      args = this.parseFunctionArgs();
      sequence = [];
      while (true) {
        token = this.nextToken();
        if (token.type === Token.TYPE_END) {
          this.nesting -= 1;
          this.endTerminable();
          return new Program.Function(funk, args, sequence, token);
        } else {
          this.tokenizer.pushBack(token);
          line = this.parseLine();
          if (line != null) {
            sequence.push(line);
          } else {
            this.error("Unexpected data while parsing function");
          }
        }
      }
    }

    parseFunctionArgs() {
      var args, exp, last, token;
      token = this.nextToken();
      args = [];
      last = null;
      if (token.type !== Token.TYPE_OPEN_BRACE) {
        return this.error("Expected opening parenthese");
      }
      while (true) {
        token = this.nextToken();
        if (token.type === Token.TYPE_CLOSED_BRACE) {
          return args;
        } else if (token.type === Token.TYPE_COMMA) {
          last = null;
          continue;
        } else if (token.type === Token.TYPE_EQUALS && last === "argument") {
          exp = this.assertExpression();
          args[args.length - 1].default = exp;
        } else if (token.type === Token.TYPE_IDENTIFIER) {
          last = "argument";
          args.push({
            name: token.value
          });
        } else {
          return this.error("Unexpected token");
        }
      }
    }

    warningAssignmentCondition(expression) {
      if (expression instanceof Program.Assignment) {
        return this.warnings.push({
          type: "assignment_as_condition",
          line: expression.token.line,
          column: expression.token.column
        });
      }
    }

    parseIf(iftoken) {
      var chain, current, line, token;
      this.addTerminable(iftoken);
      current = {
        condition: this.assertExpression(),
        sequence: []
      };
      this.warningAssignmentCondition(current.condition);
      chain = [];
      token = this.nextToken();
      if (token.type !== Token.TYPE_THEN) {
        return this.error("Expected 'then'");
      }
      while (true) {
        token = this.nextToken();
        if (token.type === Token.TYPE_ELSIF) {
          chain.push(current);
          current = {
            condition: this.assertExpression(),
            sequence: []
          };
          this.warningAssignmentCondition(current.condition);
          this.assert(Token.TYPE_THEN, "Expected 'then'");
        } else if (token.type === Token.TYPE_ELSE) {
          current.else = [];
        } else if (token.type === Token.TYPE_END) {
          chain.push(current);
          this.endTerminable();
          return new Program.Condition(iftoken, chain);
        } else {
          this.tokenizer.pushBack(token);
          line = this.parseLine();
          if (line == null) {
            throw Error("Unexpected data while parsing if");
          }
          if (current.else != null) {
            current.else.push(line);
          } else {
            current.sequence.push(line);
          }
        }
      }
    }

    assert(type, error) {
      var token;
      token = this.nextToken();
      if (token.type !== type) {
        throw error;
      }
      return token;
    }

    assertBroadIdentifier(error) {
      var token;
      token = this.nextToken();
      if (token.type !== Token.TYPE_IDENTIFIER && token.reserved_keyword) {
        token.type = Token.TYPE_IDENTIFIER;
      }
      if (token.type !== Token.TYPE_IDENTIFIER) {
        throw error;
      }
      return token;
    }

    error(text) {
      throw text;
    }

    parseFor(fortoken) {
      var iterator, list, range_by, range_from, range_to, token;
      iterator = this.assertExpression();
      if (iterator instanceof Program.Assignment) {
        range_from = iterator.expression;
        iterator = iterator.field;
        token = this.nextToken();
        if (token.type !== Token.TYPE_TO) {
          return this.error("Expected 'to'");
        }
        range_to = this.assertExpression();
        token = this.nextToken();
        if (token.type === Token.TYPE_BY) {
          range_by = this.assertExpression();
        } else {
          range_by = 0;
          this.tokenizer.pushBack(token);
        }
        return new Program.For(fortoken, iterator.identifier, range_from, range_to, range_by, this.parseSequence(fortoken));
      } else if (iterator instanceof Program.Variable) {
        this.assert(Token.TYPE_IN, "Error expected keyword 'in'");
        list = this.assertExpression();
        return new Program.ForIn(fortoken, iterator.identifier, list, this.parseSequence(fortoken));
      } else {
        return this.error("Malformed for loop");
      }
    }

    parseWhile(whiletoken) {
      var condition;
      condition = this.assertExpression();
      return new Program.While(whiletoken, condition, this.parseSequence(whiletoken));
    }

    parseSequence(start_token) {
      var line, sequence, token;
      if (start_token != null) {
        this.addTerminable(start_token);
      }
      this.nesting += 1;
      sequence = [];
      while (true) {
        token = this.nextToken();
        if (token.type === Token.TYPE_END) {
          if (start_token != null) {
            this.endTerminable();
          }
          this.nesting -= 1;
          return sequence;
        } else {
          this.tokenizer.pushBack(token);
          line = this.parseLine();
          if (line == null) {
            this.error("Unexpected data");
          }
          sequence.push(line);
        }
      }
      return sequence;
    }

    parseObject(object) {
      var exp, fields, token;
      this.nesting += 1;
      this.object_nesting += 1;
      this.addTerminable(object);
      fields = [];
      while (true) {
        token = this.nextToken();
        if (token.type === Token.TYPE_END) {
          this.nesting -= 1;
          this.object_nesting -= 1;
          this.endTerminable();
          return new Program.CreateObject(object, fields);
        } else {
          if (token.type !== Token.TYPE_IDENTIFIER && token.reserved_keyword) {
            token.type = Token.TYPE_IDENTIFIER;
          }
          if (token.type === Token.TYPE_STRING) {
            token.type = Token.TYPE_IDENTIFIER;
          }
          if (token.type === Token.TYPE_IDENTIFIER) {
            this.assert(Token.TYPE_EQUALS, "Expected '='");
            exp = this.assertExpression();
            fields.push({
              field: token.value,
              value: exp
            });
          } else {
            return this.error("Malformed object");
          }
        }
      }
    }

    parseClass(object) {
      var exp, ext, fields, token;
      this.nesting += 1;
      this.object_nesting += 1;
      this.addTerminable(object);
      fields = [];
      token = this.nextToken();
      if (token.type === Token.TYPE_EXTENDS) {
        ext = this.assertExpression();
        token = this.nextToken();
      }
      while (true) {
        if (token.type === Token.TYPE_END) {
          this.nesting -= 1;
          this.object_nesting -= 1;
          this.endTerminable();
          return new Program.CreateClass(object, ext, fields);
        } else {
          if (token.type !== Token.TYPE_IDENTIFIER && token.reserved_keyword) {
            token.type = Token.TYPE_IDENTIFIER;
          }
          if (token.type === Token.TYPE_STRING) {
            token.type = Token.TYPE_IDENTIFIER;
          }
          if (token.type === Token.TYPE_IDENTIFIER) {
            this.assert(Token.TYPE_EQUALS, "Expected '='");
            exp = this.assertExpression();
            fields.push({
              field: token.value,
              value: exp
            });
          } else {
            return this.error("Malformed object");
          }
        }
        token = this.nextToken();
      }
    }

    parseNew(token) {
      var exp;
      exp = this.assertExpression(null, true);
      return new Program.NewCall(token, exp);
    }

    parseAfter(after) {
      var delay, line, multiplier, sequence, token;
      this.nesting += 1;
      this.addTerminable(after);
      delay = this.assertExpression();
      token = this.nextToken();
      multiplier = null;
      if (token.type === Token.TYPE_IDENTIFIER && this.multipliers[token.value]) {
        multiplier = this.multipliers[token.value];
        token = this.nextToken();
      }
      if ((token == null) || token.type !== Token.TYPE_DO) {
        this.error("Expected keyword 'do'");
      }
      sequence = [];
      while (true) {
        token = this.nextToken();
        if (token.type === Token.TYPE_END) {
          this.nesting -= 1;
          this.endTerminable();
          return new Program.After(after, delay, sequence, token, multiplier);
        } else {
          this.tokenizer.pushBack(token);
          line = this.parseLine();
          if (line != null) {
            sequence.push(line);
          } else {
            this.error("Unexpected data while parsing after");
          }
        }
      }
    }

    parseEvery(every) {
      var delay, line, multiplier, sequence, token;
      this.nesting += 1;
      this.addTerminable(every);
      delay = this.assertExpression();
      token = this.nextToken();
      multiplier = null;
      if (token.type === Token.TYPE_IDENTIFIER && this.multipliers[token.value]) {
        multiplier = this.multipliers[token.value];
        token = this.nextToken();
      }
      if ((token == null) || token.type !== Token.TYPE_DO) {
        this.error("Expected keyword 'do'");
      }
      sequence = [];
      while (true) {
        token = this.nextToken();
        if (token.type === Token.TYPE_END) {
          this.nesting -= 1;
          this.endTerminable();
          return new Program.Every(every, delay, sequence, token, multiplier);
        } else {
          this.tokenizer.pushBack(token);
          line = this.parseLine();
          if (line != null) {
            sequence.push(line);
          } else {
            this.error("Unexpected data while parsing after");
          }
        }
      }
    }

    parseDo(do_token) {
      var line, sequence, token;
      this.nesting += 1;
      this.addTerminable(do_token);
      sequence = [];
      while (true) {
        token = this.nextToken();
        if (token.type === Token.TYPE_END) {
          this.nesting -= 1;
          this.endTerminable();
          return new Program.Do(do_token, sequence, token);
        } else {
          this.tokenizer.pushBack(token);
          line = this.parseLine();
          if (line != null) {
            sequence.push(line);
          } else {
            this.error("Unexpected data while parsing after");
          }
        }
      }
    }

    parseSleep(sleep) {
      var delay, multiplier, token;
      delay = this.assertExpression();
      token = this.nextToken();
      multiplier = null;
      if (token != null) {
        if (token.type === Token.TYPE_IDENTIFIER && this.multipliers[token.value]) {
          multiplier = this.multipliers[token.value];
        } else {
          this.tokenizer.pushBack(token);
        }
      }
      return new Program.Sleep(sleep, delay, multiplier);
    }

    parseDelete(del) {
      var v;
      v = this.parseExpression();
      if ((v == null) || (!(v instanceof Program.Variable) && !(v instanceof Program.Field))) {
        return this.error("expecting variable name or property access after keyword `delete`");
      } else {
        return new Program.Delete(del, v);
      }
    }

  };

  Parser.prototype.multipliers = {
    millisecond: 1,
    milliseconds: 1,
    second: 1000,
    seconds: 1000,
    minute: 60000,
    minutes: 60000,
    hour: 60000 * 60,
    hours: 60000 * 60,
    day: 60000 * 60 * 24,
    days: 60000 * 60 * 24
  };

  return Parser;

}).call(this);


this.Processor = class Processor {
  constructor(runner) {
    this.runner = runner;
    this.locals = [];
    this.stack = [];
    this.call_stack = [];
    this.log = false;
    this.time_limit = 2e308;
    this.done = true;
  }

  load(routine1) {
    this.routine = routine1;
    return this.resetState();
  }

  resetState() {
    this.local_index = 0;
    this.stack_index = -1;
    this.op_index = 0;
    this.call_stack_index = 0;
    this.global = null;
    this.object = this.routine.object || null;
    this.locals_offset = 0;
    this.call_super = null;
    this.call_supername = "";
    return this.done = false;
  }

  resolveParentClass(obj, global) {
    if ((obj.class != null) && typeof obj.class === "string") {
      if (global[obj.class] != null) {
        obj.class = global[obj.class];
        return this.resolveParentClass(obj.class, global);
      }
    } else if (obj.class != null) {
      return this.resolveParentClass(obj.class, global);
    }
  }

  applyFunction(args) {}

  routineAsFunction(routine, context) {
    var f, proc;
    proc = new Processor(this.runner);
    f = function() {
      var a, count, i, j, k, ref, ref1;
      count = Math.min(routine.num_args, arguments.length);
      proc.load(routine);
      for (i = j = 0, ref = count - 1; j <= ref; i = j += 1) {
        proc.stack[++proc.stack_index] = arguments[i] || 0;
      }
      proc.stack[++proc.stack_index] = arguments.length;
      if (routine.uses_arguments) {
        a = [...arguments];
        for (i = k = 0, ref1 = a.length - 1; k <= ref1; i = k += 1) {
          if (a[i] == null) {
            a[i] = 0;
          }
        }
        proc.stack[++proc.stack_index] = a;
      }
      return proc.run(context);
    };
    //res = proc.stack[0]
    return f;
  }

  routineAsApplicableFunction(routine, context) {
    var f, proc;
    proc = new Processor(this.runner);
    f = function() {
      var a, count, i, j, k, ref, ref1, res;
      count = routine.num_args;
      proc.load(routine);
      proc.object = this;
      for (i = j = 0, ref = count - 1; j <= ref; i = j += 1) {
        proc.stack[++proc.stack_index] = arguments[i] || 0;
      }
      proc.stack[++proc.stack_index] = arguments.length;
      if (routine.uses_arguments) {
        a = [...arguments];
        for (i = k = 0, ref1 = a.length - 1; k <= ref1; i = k += 1) {
          if (a[i] == null) {
            a[i] = 0;
          }
        }
        proc.stack[++proc.stack_index] = a;
      }
      proc.run(context);
      return res = proc.stack[0];
    };
    return f;
  }

  argToNative(arg, context) {
    if (arg instanceof Routine) {
      return this.routineAsFunction(arg, context);
    } else {
      if (arg != null) {
        return arg;
      } else {
        return 0;
      }
    }
  }

  modulo(context, a, b) {
    var f, obj;
    if (Array.isArray(a)) {
      obj = context.global.List;
    } else if (typeof a === "string") {
      if (isFinite(a)) {
        a %= b;
        if (isFinite(a)) {
          return a;
        } else {
          return 0;
        }
      } else {
        obj = context.global.String;
      }
    } else {
      obj = a;
    }
    f = obj["%"];
    while ((f == null) && (obj.class != null)) {
      obj = obj.class;
      f = obj["%"];
    }
    if (f == null) {
      f = context.global.Object["%"];
    }
    if ((f != null) && f instanceof Routine) {
      if (f.as_function == null) {
        f.as_function = this.routineAsApplicableFunction(f, context);
      }
      f = f.as_function;
      return f.call(context.global, a, b);
    } else {
      return 0;
    }
  }

  add(context, a, b, self) {
    var f, obj;
    if (Array.isArray(a)) {
      obj = context.global.List;
    } else if (typeof a === "string") {
      obj = context.global.String;
    } else {
      obj = a;
    }
    f = obj["+"];
    while ((f == null) && (obj.class != null)) {
      obj = obj.class;
      f = obj["+"];
    }
    if (f == null) {
      f = context.global.Object["+"];
    }
    if (f != null) {
      if (f instanceof Routine) {
        if (f.as_function == null) {
          f.as_function = this.routineAsApplicableFunction(f, context);
        }
        f = f.as_function;
        return f.call(context.global, a, b, self);
      } else if (typeof f === "function") {
        return f.call(context.global, a, b, self);
      }
    } else {
      return 0;
    }
  }

  sub(context, a, b, self) {
    var f, obj;
    if (Array.isArray(a)) {
      obj = context.global.List;
    } else if (typeof a === "string") {
      if (isFinite(a)) {
        a -= b;
        if (isFinite(a)) {
          return a;
        } else {
          return 0;
        }
      } else {
        obj = context.global.String;
      }
    } else {
      obj = a;
    }
    f = obj["-"];
    while ((f == null) && (obj.class != null)) {
      obj = obj.class;
      f = obj["-"];
    }
    if (f == null) {
      f = context.global.Object["-"];
    }
    if (f != null) {
      if (f instanceof Routine) {
        if (f.as_function == null) {
          f.as_function = this.routineAsApplicableFunction(f, context);
        }
        f = f.as_function;
        return f.call(context.global, a, b, self);
      } else if (typeof f === "function") {
        return f.call(context.global, a, b, self);
      }
    } else {
      return 0;
    }
  }

  negate(context, a) {
    var f, obj;
    if (Array.isArray(a)) {
      obj = context.global.List;
    } else if (typeof a === "string") {
      if (isFinite(a)) {
        return -a;
      } else {
        obj = context.global.String;
      }
    } else {
      obj = a;
    }
    f = obj["-"];
    while ((f == null) && (obj.class != null)) {
      obj = obj.class;
      f = obj["-"];
    }
    if (f == null) {
      f = context.global.Object["-"];
    }
    if (f != null) {
      if (f instanceof Routine) {
        if (f.as_function == null) {
          f.as_function = this.routineAsApplicableFunction(f, context);
        }
        f = f.as_function;
        return f.call(context.global, 0, a);
      } else if (typeof f === "function") {
        return f.call(context.global, 0, a);
      }
    } else {
      return 0;
    }
  }

  mul(context, a, b, self) {
    var f, obj;
    if (Array.isArray(a)) {
      obj = context.global.List;
    } else if (typeof a === "string") {
      if (isFinite(a)) {
        a *= b;
        if (isFinite(a)) {
          return a;
        } else {
          return 0;
        }
      } else {
        obj = context.global.String;
      }
    } else {
      obj = a;
    }
    f = obj["*"];
    while ((f == null) && (obj.class != null)) {
      obj = obj.class;
      f = obj["*"];
    }
    if (f == null) {
      f = context.global.Object["*"];
    }
    if (f != null) {
      if (f instanceof Routine) {
        if (f.as_function == null) {
          f.as_function = this.routineAsApplicableFunction(f, context);
        }
        f = f.as_function;
        return f.call(context.global, a, b, self);
      } else if (typeof f === "function") {
        return f.call(context.global, a, b, self);
      }
    } else {
      return 0;
    }
  }

  div(context, a, b, self) {
    var f, obj;
    if (Array.isArray(a)) {
      obj = context.global.List;
    } else if (typeof a === "string") {
      if (isFinite(a)) {
        a /= b;
        if (isFinite(a)) {
          return a;
        } else {
          return 0;
        }
      } else {
        obj = context.global.String;
      }
    } else {
      obj = a;
    }
    f = obj["/"];
    while ((f == null) && (obj.class != null)) {
      obj = obj.class;
      f = obj["/"];
    }
    if (f == null) {
      f = context.global.Object["/"];
    }
    if (f != null) {
      if (f instanceof Routine) {
        if (f.as_function == null) {
          f.as_function = this.routineAsApplicableFunction(f, context);
        }
        f = f.as_function;
        return f.call(context.global, a, b, self);
      } else if (typeof f === "function") {
        return f.call(context.global, a, b, self);
      }
    } else {
      return 0;
    }
  }

  band(context, a, b, self) {
    var f, obj;
    if (Array.isArray(a)) {
      obj = context.global.List;
    } else if (typeof a === "string") {
      if (isFinite(a)) {
        a &= b;
        if (isFinite(a)) {
          return a;
        } else {
          return 0;
        }
      } else {
        obj = context.global.String;
      }
    } else {
      obj = a;
    }
    f = obj["&"];
    while ((f == null) && (obj.class != null)) {
      obj = obj.class;
      f = obj["&"];
    }
    if (f == null) {
      f = context.global.Object["&"];
    }
    if (f != null) {
      if (f instanceof Routine) {
        if (f.as_function == null) {
          f.as_function = this.routineAsApplicableFunction(f, context);
        }
        f = f.as_function;
        return f.call(context.global, a, b, self);
      } else if (typeof f === "function") {
        return f.call(context.global, a, b, self);
      }
    } else {
      return 0;
    }
  }

  bor(context, a, b, self) {
    var f, obj;
    if (Array.isArray(a)) {
      obj = context.global.List;
    } else if (typeof a === "string") {
      if (isFinite(a)) {
        a |= b;
        if (isFinite(a)) {
          return a;
        } else {
          return 0;
        }
      } else {
        obj = context.global.String;
      }
    } else {
      obj = a;
    }
    f = obj["|"];
    while ((f == null) && (obj.class != null)) {
      obj = obj.class;
      f = obj["|"];
    }
    if (f == null) {
      f = context.global.Object["|"];
    }
    if (f != null) {
      if (f instanceof Routine) {
        if (f.as_function == null) {
          f.as_function = this.routineAsApplicableFunction(f, context);
        }
        f = f.as_function;
        return f.call(context.global, a, b, self);
      } else if (typeof f === "function") {
        return f.call(context.global, a, b, self);
      }
    } else {
      return 0;
    }
  }

  run(context) {
    var a, arg1, args, argv, b, c, call_stack, call_stack_index, call_super, call_supername, con, cs, err, f, fc, field, global, i, i1, i2, id, index, ir, iter, iterator, j, k, key, l, len, length, local_index, locals, locals_offset, loop_by, loop_to, m, n, name, o, obj, object, op_count, op_index, opcodes, p, parent, q, r, rc, ref, ref1, ref10, ref11, ref12, ref13, ref14, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, res, restore_op_index, routine, s, sleep_time, src, stack, stack_index, sup, t, token, u, v, value, w;
    routine = this.routine;
    opcodes = this.routine.opcodes;
    arg1 = this.routine.arg1;
    length = opcodes.length;
    op_index = this.op_index;
    stack = this.stack;
    stack_index = this.stack_index;
    locals = this.locals;
    local_index = this.local_index;
    global = this.global || context.global;
    object = this.object || global;
    call_stack = this.call_stack;
    call_stack_index = this.call_stack_index;
    call_super = this.call_super || global;
    call_supername = this.call_supername || "";
    locals_offset = this.locals_offset;
    op_count = 0;
    restore_op_index = -1;
    while (op_index < length) {
      switch (opcodes[op_index]) {
        case 1: // OPCODE_TYPE
          v = stack[stack_index];
          switch (typeof v) {
            case "number":
              stack[stack_index] = "number";
              break;
            case "string":
              stack[stack_index] = "string";
              break;
            case "function":
              stack[stack_index] = "function";
              break;
            case "object":
              if (Array.isArray(v)) {
                stack[stack_index] = "list";
              } else if (v instanceof Routine) {
                stack[stack_index] = "function";
              } else {
                stack[stack_index] = "object";
              }
          }
          op_index++;
          break;
        case 2: // OPCODE_TYPE_VARIABLE
          v = object[arg1[op_index]];
          if (v == null) {
            v = global[arg1[op_index]];
          }
          if (v == null) {
            stack[++stack_index] = 0;
          } else {
            switch (typeof v) {
              case "number":
                stack[++stack_index] = "number";
                break;
              case "string":
                stack[++stack_index] = "string";
                break;
              case "function":
                stack[++stack_index] = "function";
                break;
              default:
                if (Array.isArray(v)) {
                  stack[++stack_index] = "list";
                } else if (v instanceof Routine) {
                  stack[++stack_index] = "function";
                } else {
                  stack[++stack_index] = "object";
                }
            }
          }
          op_index++;
          break;
        case 3: // OPCODE_TYPE_PROPERTY
          v = stack[stack_index - 1][stack[stack_index]];
          if (v == null) {
            stack[--stack_index] = 0;
          } else {
            switch (typeof v) {
              case "number":
                stack[--stack_index] = "number";
                break;
              case "string":
                stack[--stack_index] = "string";
                break;
              case "function":
                stack[--stack_index] = "function";
                break;
              default:
                if (Array.isArray(v)) {
                  stack[--stack_index] = "list";
                } else if (v instanceof Routine) {
                  stack[--stack_index] = "function";
                } else {
                  stack[--stack_index] = "object";
                }
            }
          }
          op_index++;
          break;
        case 4: // OPCODE_LOAD_IMPORT
          stack[++stack_index] = routine.import_values[arg1[op_index++]];
          break;
        case 5: // OPCODE_LOAD_THIS
          stack[++stack_index] = object;
          op_index++;
          break;
        case 6: // OPCODE_LOAD_GLOBAL
          stack[++stack_index] = global;
          op_index++;
          break;
        case 10: // CODE_LOAD_VALUE
          stack[++stack_index] = arg1[op_index++];
          break;
        case 11: // OPCODE_LOAD_LOCAL
          stack[++stack_index] = locals[locals_offset + arg1[op_index++]];
          break;
        case 12: // OPCODE_LOAD_VARIABLE
          name = arg1[op_index];
          v = object[name];
          if ((v == null) && (object.class != null)) {
            obj = object;
            while ((v == null) && (obj.class != null)) {
              obj = obj.class;
              v = obj[name];
            }
          }
          if (v == null) {
            v = global[name];
          }
          if ((v == null) && !routine.ref[op_index].nowarning) {
            token = routine.ref[op_index].token;
            id = token.tokenizer.filename + "-" + token.line + "-" + token.column;
            if (!context.warnings.using_undefined_variable[id]) {
              context.warnings.using_undefined_variable[id] = {
                file: token.tokenizer.filename,
                line: token.line,
                column: token.column,
                expression: name
              };
            }
          }
          stack[++stack_index] = v != null ? v : 0;
          op_index++;
          break;
        case 13: // OPCODE_LOAD_LOCAL_OBJECT
          o = locals[locals_offset + arg1[op_index]];
          if (typeof o !== "object") {
            o = locals[locals_offset + arg1[op_index]] = {};
            token = routine.ref[op_index].token;
            id = token.tokenizer.filename + "-" + token.line + "-" + token.column;
            if (!context.warnings.assigning_field_to_undefined[id]) {
              context.warnings.assigning_field_to_undefined[id] = {
                file: token.tokenizer.filename,
                line: token.line,
                column: token.column,
                expression: token.value
              };
            }
          }
          stack[++stack_index] = o;
          op_index++;
          break;
        case 14: // OPCODE_LOAD_VARIABLE_OBJECT
          name = arg1[op_index];
          obj = object;
          v = obj[name];
          while ((v == null) && (obj.class != null)) {
            obj = obj.class;
            v = obj[name];
          }
          if ((v == null) && (global[name] != null)) {
            obj = global;
            v = global[name];
          }
          if ((v == null) || typeof v !== "object") {
            v = obj[name] = {};
            token = routine.ref[op_index].token;
            id = token.tokenizer.filename + "-" + token.line + "-" + token.column;
            if (!context.warnings.assigning_field_to_undefined[id]) {
              context.warnings.assigning_field_to_undefined[id] = {
                file: token.tokenizer.filename,
                line: token.line,
                column: token.column,
                expression: arg1[op_index]
              };
            }
          }
          stack[++stack_index] = v;
          op_index++;
          break;
        case 15: // OPCODE_POP
          stack_index--;
          op_index++;
          break;
        case 16: // OPCODE_LOAD_PROPERTY
          obj = stack[stack_index - 1];
          name = stack[stack_index];
          v = obj[name];
          while ((v == null) && (obj.class != null)) {
            obj = obj.class;
            v = obj[name];
          }
          if (v == null) {
            v = 0;
            if (!routine.ref[op_index].nowarning) {
              routine.ref[op_index].nowarning = true;
              if (!Array.isArray(obj)) {
                token = routine.ref[op_index].token;
                id = token.tokenizer.filename + "-" + token.line + "-" + token.column;
                context.warnings.using_undefined_variable[id] = {
                  file: token.tokenizer.filename,
                  line: token.line,
                  column: token.column,
                  expression: name
                };
              }
            }
          }
          stack[--stack_index] = v;
          op_index++;
          break;
        case 17: // OPCODE_LOAD_PROPERTY_OBJECT
          v = stack[stack_index - 1][stack[stack_index]];
          if (typeof v !== "object") {
            v = stack[stack_index - 1][stack[stack_index]] = {};
            token = routine.ref[op_index].token;
            id = token.tokenizer.filename + "-" + token.line + "-" + token.column;
            if (!context.warnings.assigning_field_to_undefined[id]) {
              context.warnings.assigning_field_to_undefined[id] = {
                file: token.tokenizer.filename,
                line: token.line,
                column: token.column,
                expression: stack[stack_index]
              };
            }
          }
          stack[--stack_index] = v;
          op_index++;
          break;
        case 18: // OPCODE_CREATE_OBJECT
          stack[++stack_index] = {};
          op_index++;
          break;
        case 19: // OPCODE_MAKE_OBJECT
          if (typeof stack[stack_index] !== "object") {
            stack[stack_index] = {};
          }
          op_index++;
          break;
        case 20: // OPCODE_CREATE_ARRAY
          stack[++stack_index] = [];
          op_index++;
          break;
        case 21: // OPCODE_STORE_LOCAL
          locals[locals_offset + arg1[op_index]] = stack[stack_index];
          op_index++;
          break;
        case 22: // OPCODE_STORE_LOCAL_POP
          locals[locals_offset + arg1[op_index]] = stack[stack_index--];
          op_index++;
          break;
        case 23: // OPCODE_STORE_VARIABLE
          object[arg1[op_index++]] = stack[stack_index];
          break;
        case 24: // OPCODE_CREATE_PROPERTY
          obj = stack[stack_index - 2];
          field = stack[stack_index - 1];
          obj[field] = stack[stack_index];
          stack_index -= 2;
          op_index++;
          break;
        case 25: // OPCODE_STORE_PROPERTY
          obj = stack[stack_index - 2];
          field = stack[stack_index - 1];
          stack[stack_index - 2] = obj[field] = stack[stack_index];
          stack_index -= 2;
          op_index++;
          break;
        case 26: // OPCODE_DELETE
          obj = stack[stack_index - 1];
          field = stack[stack_index];
          delete obj[field];
          stack[stack_index -= 1] = 0;
          op_index++;
          break;
        case 27: // OPCODE_UPDATE_CLASS
          name = arg1[op_index];
          // TODO: set classname to variable name
          if ((object[name] != null) && typeof object[name] === "object") {
            obj = object[name];
            src = stack[stack_index];
            for (key in src) {
              value = src[key];
              obj[key] = value;
            }
          } else {
            object[name] = stack[stack_index];
          }
          op_index++;
          break;
        case 28: // OPCODE_CREATE_CLASS
          res = {};
          parent = stack[stack_index];
          if (parent) {
            res.class = parent;
          } else if (arg1[op_index]) {
            res.class = arg1[op_index];
          }
          stack[stack_index] = res;
          op_index++;
          break;
        case 29: // OPCODE_NEW_CALL
          c = stack[stack_index];
          args = arg1[op_index];
          if (typeof c === "function") {
            a = [];
            for (i = j = 0, ref = args - 1; j <= ref; i = j += 1) {
              a.push(stack[stack_index - args + i]);
            }
            stack_index -= args;
            // NEW CALL is followed by a POP (to get rid of constructor return value)
            stack[stack_index - 1] = new c(...a);
            op_index++;
          } else {
            this.resolveParentClass(c, global);
            res = {
              class: c
            };
            con = c.constructor;
            while (!con && (c.class != null)) {
              c = c.class;
              con = c.constructor;
            }
            if ((con != null) && con instanceof Routine) {
              stack[stack_index - args - 1] = res;
              stack_index--;
              cs = call_stack[call_stack_index] || (call_stack[call_stack_index] = {});
              call_stack_index++;
              cs.routine = routine;
              cs.object = object;
              cs.super = call_super;
              cs.supername = call_supername;
              cs.op_index = op_index + 1;
              locals_offset += routine.locals_size;
              routine = con;
              opcodes = con.opcodes;
              arg1 = con.arg1;
              op_index = 0;
              length = opcodes.length;
              object = res;
              call_super = c;
              call_supername = "constructor";
              if (routine.uses_arguments) {
                argv = stack.slice(stack_index - args + 1, stack_index + 1);
              }
              if (args < con.num_args) {
                for (i = k = ref1 = args + 1, ref2 = con.num_args; k <= ref2; i = k += 1) {
                  stack[++stack_index] = 0;
                }
              } else if (args > con.num_args) {
                stack_index -= args - con.num_args;
              }
              stack[++stack_index] = args;
              if (routine.uses_arguments) {
                stack[++stack_index] = argv;
              }
            } else {
              stack_index -= args;
              stack[stack_index - 1] = res;
              op_index++;
            }
          }
          break;
        case 30: // OPCODE_ADD
          b = stack[stack_index--];
          a = stack[stack_index];
          if (typeof a === "number") {
            a += b;
            stack[stack_index] = isFinite(a) || typeof b === "string" ? a : 0;
          } else {
            stack[stack_index] = this.add(context, a, b, arg1[op_index]);
          }
          op_index++;
          break;
        case 31: // OPCODE_SUB
          b = stack[stack_index--];
          a = stack[stack_index];
          if (typeof a === "number") {
            a -= b;
            stack[stack_index] = isFinite(a) ? a : 0;
          } else {
            stack[stack_index] = this.sub(context, a, b, arg1[op_index]);
          }
          op_index++;
          break;
        case 32: // OPCODE_MUL
          b = stack[stack_index--];
          a = stack[stack_index];
          if (typeof a === "number") {
            a *= b;
            stack[stack_index] = isFinite(a) ? a : 0;
          } else {
            stack[stack_index] = this.mul(context, a, b);
          }
          op_index++;
          break;
        case 33: // OPCODE_DIV
          b = stack[stack_index--];
          a = stack[stack_index];
          if (typeof a === "number") {
            a /= b;
            stack[stack_index] = isFinite(a) ? a : 0;
          } else {
            stack[stack_index] = this.div(context, a, b);
          }
          op_index++;
          break;
        case 34: // OPCODE_MODULO
          b = stack[stack_index--];
          a = stack[stack_index];
          if (typeof a === "number" && typeof b === "number") {
            a %= b;
            stack[stack_index] = isFinite(a) ? a : 0;
          } else {
            stack[stack_index] = this.modulo(context, a, b);
          }
          op_index++;
          break;
        case 35: // OPCODE_BINARY_AND
          b = stack[stack_index--];
          a = stack[stack_index];
          if (typeof a === "number") {
            a &= b;
            stack[stack_index] = isFinite(a) ? a : 0;
          } else {
            stack[stack_index] = this.band(context, a, b);
          }
          op_index++;
          break;
        case 36: // OPCODE_BINARY_OR
          b = stack[stack_index--];
          a = stack[stack_index];
          if (typeof a === "number") {
            a |= b;
            stack[stack_index] = isFinite(a) ? a : 0;
          } else {
            stack[stack_index] = this.bor(context, a, b);
          }
          op_index++;
          break;
        case 37: // OPCODE_SHIFT_LEFT
          v = stack[stack_index - 1] << stack[stack_index];
          stack[--stack_index] = isFinite(v) ? v : 0;
          op_index++;
          break;
        case 38: // OPCODE_SHIFT_RIGHT
          v = stack[stack_index - 1] >> stack[stack_index];
          stack[--stack_index] = isFinite(v) ? v : 0;
          op_index++;
          break;
        case 39: // OPCODE_NEGATE
          a = stack[stack_index];
          if (typeof a === "number") {
            stack[stack_index] = -a;
          } else {
            stack[stack_index] = this.negate(context, a);
          }
          op_index++;
          break;
        case 50: // OPCODE_NOT
          stack[stack_index] = stack[stack_index] ? 0 : 1;
          op_index++;
          break;
        case 68: // OPCODE_LOAD_PROPERTY_ATOP
          obj = stack[stack_index - 1];
          name = stack[stack_index];
          v = obj[name];
          while ((v == null) && (obj.class != null)) {
            obj = obj.class;
            v = obj[name];
          }
          if (v == null) {
            v = 0;
            if (!routine.ref[op_index].nowarning) {
              routine.ref[op_index].nowarning = true;
              if (!Array.isArray(obj)) {
                token = routine.ref[op_index].token;
                id = token.tokenizer.filename + "-" + token.line + "-" + token.column;
                context.warnings.using_undefined_variable[id] = {
                  file: token.tokenizer.filename,
                  line: token.line,
                  column: token.column,
                  expression: name
                };
              }
            }
          }
          stack[++stack_index] = v;
          op_index++;
          break;
        case 40: // OPCODE_EQ
          stack[stack_index - 1] = stack[stack_index] === stack[stack_index - 1] ? 1 : 0;
          stack_index--;
          op_index++;
          break;
        case 41: // OPCODE_NEQ
          stack[stack_index - 1] = stack[stack_index] !== stack[stack_index - 1] ? 1 : 0;
          stack_index--;
          op_index++;
          break;
        case 42: // OPCODE_LT
          stack[stack_index - 1] = stack[stack_index - 1] < stack[stack_index] ? 1 : 0;
          stack_index--;
          op_index++;
          break;
        case 43: // OPCODE_GT
          stack[stack_index - 1] = stack[stack_index - 1] > stack[stack_index] ? 1 : 0;
          stack_index--;
          op_index++;
          break;
        case 44: // OPCODE_LTE
          stack[stack_index - 1] = stack[stack_index - 1] <= stack[stack_index] ? 1 : 0;
          stack_index--;
          op_index++;
          break;
        case 45: // OPCODE_GTE
          stack[stack_index - 1] = stack[stack_index - 1] >= stack[stack_index] ? 1 : 0;
          stack_index--;
          op_index++;
          break;
        case 95: // FORLOOP_INIT
          // fix loop_by if not set
          iter = arg1[op_index][0];
          loop_to = locals[locals_offset + iter + 1] = stack[stack_index - 1];
          loop_by = stack[stack_index];
          iterator = locals[locals_offset + iter];
          stack[--stack_index] = 0; // unload 2 values and load default value
          if (loop_by === 0) {
            locals[locals_offset + iter + 2] = loop_to > iterator ? 1 : -1;
            op_index++;
          } else {
            locals[locals_offset + iter + 2] = loop_by;
            if ((loop_by > 0 && iterator > loop_to) || (loop_by < 0 && iterator < loop_to)) {
              op_index = arg1[op_index][1];
            } else {
              op_index++;
            }
          }
          break;
        case 96: // FORLOOP_CONTROL
          iter = arg1[op_index][0];
          loop_by = locals[locals_offset + iter + 2];
          loop_to = locals[locals_offset + iter + 1];
          iterator = locals[locals_offset + iter];
          iterator += loop_by;
          if ((loop_by > 0 && iterator > loop_to) || (loop_by < 0 && iterator < loop_to)) {
            op_index++;
          } else {
            locals[locals_offset + iter] = iterator;
            op_index = arg1[op_index][1];
          }
          if (op_count++ > 100) {
            op_count = 0;
            if (Date.now() > this.time_limit) {
              restore_op_index = op_index;
              op_index = length; // stop the loop without adding a condition statement
            }
          }
          break;
        case 97: // FORIN_INIT
          v = stack[stack_index];
          stack[stack_index] = 0; // default result
          iterator = arg1[op_index][0];
          if (typeof v === "object") {
            if (Array.isArray(v)) {
              locals[locals_offset + iterator + 1] = v;
            } else {
              v = locals[locals_offset + iterator + 1] = Object.keys(v);
            }
          } else if (typeof v === "string") {
            v = locals[locals_offset + iterator + 1] = v.split("");
          } else {
            v = locals[locals_offset + iterator + 1] = [];
          }
          if (v.length === 0) {
            op_index = arg1[op_index][1];
          } else {
            value = v[0];
            // value could be undefined if the array is sparse
            locals[locals_offset + arg1[op_index][0]] = value != null ? value : 0;
            locals[locals_offset + iterator + 2] = 0;
            op_index++;
          }
          break;
        case 98: // FORIN_CONTROL
          iterator = arg1[op_index][0];
          index = locals[locals_offset + iterator + 2] += 1;
          v = locals[locals_offset + iterator + 1];
          if (index < v.length) {
            value = v[index];
            // value could be undefined if the array is sparse
            locals[locals_offset + iterator] = value != null ? value : 0;
            op_index = arg1[op_index][1];
          } else {
            op_index++;
          }
          if (op_count++ > 100) {
            op_count = 0;
            if (Date.now() > this.time_limit) {
              restore_op_index = op_index;
              op_index = length; // stop the loop without adding a condition statement
            }
          }
          break;
        case 80: // OPCODE_JUMP
          op_index = arg1[op_index];
          if (op_count++ > 100) {
            op_count = 0;
            if (Date.now() > this.time_limit) {
              restore_op_index = op_index;
              op_index = length; // stop the loop without adding a condition statement
            }
          }
          break;
        case 81: // OPCODE_JUMPY
          if (stack[stack_index--]) {
            op_index = arg1[op_index];
          } else {
            op_index++;
          }
          break;
        case 82: // OPCODE_JUMPN
          if (!stack[stack_index--]) {
            op_index = arg1[op_index];
          } else {
            op_index++;
          }
          break;
        case 83: // OPCODE_JUMPY_NOPOP
          if (stack[stack_index]) {
            op_index = arg1[op_index];
          } else {
            op_index++;
          }
          break;
        case 84: // OPCODE_JUMPN_NOPOP
          if (!stack[stack_index]) {
            op_index = arg1[op_index];
          } else {
            op_index++;
          }
          break;
        case 89: // OPCODE_LOAD_ROUTINE
          r = arg1[op_index++];
          rc = r.clone();
          ref3 = r.import_refs;
          for (l = 0, len = ref3.length; l < len; l++) {
            ir = ref3[l];
            if (ir === r.import_self) {
              rc.import_values.push(rc);
            } else {
              rc.import_values.push(locals[locals_offset + ir]);
            }
          }
          rc.object = object;
          stack[++stack_index] = rc;
          break;
        case 90: // OPCODE_FUNCTION_CALL
          args = arg1[op_index];
          f = stack[stack_index];
          if (f instanceof Routine) {
            stack_index--;
            cs = call_stack[call_stack_index] || (call_stack[call_stack_index] = {});
            call_stack_index++;
            cs.routine = routine;
            cs.object = object;
            cs.super = call_super;
            cs.supername = call_supername;
            cs.op_index = op_index + 1;
            locals_offset += routine.locals_size;
            routine = f;
            opcodes = f.opcodes;
            arg1 = f.arg1;
            op_index = 0;
            length = opcodes.length;
            object = routine.object != null ? routine.object : global;
            call_super = global;
            call_supername = "";
            if (routine.uses_arguments) {
              argv = stack.slice(stack_index - args + 1, stack_index + 1);
            }
            if (args < f.num_args) {
              for (i = m = ref4 = args + 1, ref5 = f.num_args; m <= ref5; i = m += 1) {
                stack[++stack_index] = 0;
              }
            } else if (args > f.num_args) {
              stack_index -= args - f.num_args;
            }
            stack[++stack_index] = args;
            if (routine.uses_arguments) {
              stack[++stack_index] = argv;
            }
          } else if (typeof f === "function") {
            switch (args) {
              case 0:
                try {
                  v = f();
                } catch (error) {
                  err = error;
                  console.error(err);
                  v = 0;
                }
                stack[stack_index] = v != null ? v : 0;
                break;
              case 1:
                try {
                  v = f(this.argToNative(stack[stack_index - 1], context));
                } catch (error) {
                  err = error;
                  console.error(err);
                  v = 0;
                }
                stack[stack_index - 1] = v != null ? v : 0;
                stack_index -= 1;
                break;
              default:
                argv = [];
                stack_index -= args;
                for (i = n = 0, ref6 = args - 1; n <= ref6; i = n += 1) {
                  argv[i] = this.argToNative(stack[stack_index + i], context);
                }
                try {
                  v = f.apply(null, argv);
                } catch (error) {
                  err = error;
                  console.error(err);
                  v = 0;
                }
                stack[stack_index] = v != null ? v : 0;
            }
            op_index++;
          } else {
            stack_index -= args;
            stack[stack_index] = f != null ? f : 0;
            token = routine.ref[op_index].token;
            id = token.tokenizer.filename + "-" + token.line + "-" + token.column;
            if (!context.warnings.invoking_non_function[id]) {
              fc = routine.ref[op_index];
              i1 = fc.expression.token.start;
              i2 = fc.token.start + fc.token.length;
              context.warnings.invoking_non_function[id] = {
                file: token.tokenizer.filename,
                line: token.line,
                column: token.column,
                expression: fc.token.tokenizer.input.substring(i1, i2)
              };
            }
            op_index++;
          }
          break;
        case 91: // OPCODE_FUNCTION_APPLY_VARIABLE
          name = stack[stack_index];
          sup = obj = object;
          f = obj[name];
          if (f == null) {
            while ((f == null) && (sup.class != null)) {
              sup = sup.class;
              f = sup[name];
            }
            if (f == null) {
              f = global.Object[name];
            }
            if (f == null) {
              f = global[name];
              sup = global;
              obj = global;
            }
          }
          args = arg1[op_index];
          if (f instanceof Routine) {
            stack_index -= 1;
            cs = call_stack[call_stack_index] || (call_stack[call_stack_index] = {});
            call_stack_index++;
            cs.routine = routine;
            cs.object = object;
            cs.super = call_super;
            cs.supername = call_supername;
            cs.op_index = op_index + 1;
            locals_offset += routine.locals_size;
            routine = f;
            opcodes = f.opcodes;
            arg1 = f.arg1;
            op_index = 0;
            length = opcodes.length;
            object = obj;
            call_super = sup;
            call_supername = name;
            if (routine.uses_arguments) {
              argv = stack.slice(stack_index - args + 1, stack_index + 1);
            }
            if (args < f.num_args) {
              for (i = p = ref7 = args + 1, ref8 = f.num_args; p <= ref8; i = p += 1) {
                stack[++stack_index] = 0;
              }
            } else if (args > f.num_args) {
              stack_index -= args - f.num_args;
            }
            stack[++stack_index] = args;
            if (routine.uses_arguments) {
              stack[++stack_index] = argv;
            }
          } else if (typeof f === "function") {
            switch (args) {
              case 0:
                try {
                  v = f.call(obj);
                } catch (error) {
                  err = error;
                  console.error(err);
                  v = 0;
                }
                stack[stack_index] = v != null ? v : 0;
                break;
              case 1:
                try {
                  v = f.call(obj, this.argToNative(stack[stack_index - 1], context));
                } catch (error) {
                  err = error;
                  console.error(err);
                  v = 0;
                }
                stack[--stack_index] = v != null ? v : 0;
                break;
              default:
                argv = [];
                stack_index -= args;
                for (i = q = 0, ref9 = args - 1; q <= ref9; i = q += 1) {
                  argv[i] = this.argToNative(stack[stack_index + i], context);
                }
                try {
                  v = f.apply(obj, argv);
                } catch (error) {
                  err = error;
                  console.error(err);
                  v = 0;
                }
                stack[stack_index] = v != null ? v : 0;
            }
            op_index++;
          } else {
            stack_index -= args;
            stack[stack_index] = f != null ? f : 0;
            token = routine.ref[op_index].token;
            id = token.tokenizer.filename + "-" + token.line + "-" + token.column;
            if (!context.warnings.invoking_non_function[id]) {
              fc = routine.ref[op_index];
              i1 = fc.expression.token.start;
              i2 = fc.token.start + fc.token.length;
              context.warnings.invoking_non_function[id] = {
                file: token.tokenizer.filename,
                line: token.line,
                column: token.column,
                expression: fc.token.tokenizer.input.substring(i1, i2)
              };
            }
            op_index++;
          }
          break;
        case 92: // OPCODE_FUNCTION_APPLY_PROPERTY
          obj = stack[stack_index - 1];
          sup = obj;
          name = stack[stack_index];
          f = obj[name];
          while ((f == null) && (sup.class != null)) {
            sup = sup.class;
            f = sup[name];
          }
          args = arg1[op_index];
          if (f == null) {
            if (obj instanceof Routine) {
              f = global.Function[name];
            } else if (typeof obj === "string") {
              f = global.String[name];
            } else if (typeof obj === "number") {
              f = global.Number[name];
            } else if (Array.isArray(obj)) {
              f = global.List[name];
            } else if (typeof obj === "object") {
              f = global.Object[name];
            }
          }
          if (f instanceof Routine) {
            stack_index -= 2;
            cs = call_stack[call_stack_index] || (call_stack[call_stack_index] = {});
            call_stack_index++;
            cs.object = object;
            cs.super = call_super;
            cs.supername = call_supername;
            cs.routine = routine;
            cs.op_index = op_index + 1;
            locals_offset += routine.locals_size;
            routine = f;
            opcodes = f.opcodes;
            arg1 = f.arg1;
            op_index = 0;
            length = opcodes.length;
            object = obj;
            call_super = sup;
            call_supername = name;
            if (routine.uses_arguments) {
              argv = stack.slice(stack_index - args + 1, stack_index + 1);
            }
            if (args < f.num_args) {
              for (i = s = ref10 = args + 1, ref11 = f.num_args; s <= ref11; i = s += 1) {
                stack[++stack_index] = 0;
              }
            } else if (args > f.num_args) {
              stack_index -= args - f.num_args;
            }
            stack[++stack_index] = args;
            if (routine.uses_arguments) {
              stack[++stack_index] = argv;
            }
          } else if (typeof f === "function") {
            switch (args) {
              case 0:
                try {
                  v = f.call(obj);
                } catch (error) {
                  err = error;
                  console.error(err);
                  v = 0;
                }
                stack[--stack_index] = v != null ? v : 0;
                break;
              case 1:
                try {
                  v = f.call(obj, this.argToNative(stack[stack_index - 2], context));
                } catch (error) {
                  err = error;
                  console.error(err);
                  v = 0;
                }
                stack[stack_index - 2] = v != null ? v : 0;
                stack_index -= 2;
                break;
              default:
                argv = [];
                stack_index -= args + 1;
                for (i = u = 0, ref12 = args - 1; u <= ref12; i = u += 1) {
                  argv[i] = this.argToNative(stack[stack_index + i], context);
                }
                try {
                  v = f.apply(obj, argv);
                } catch (error) {
                  err = error;
                  console.error(err);
                  v = 0;
                }
                stack[stack_index] = v != null ? v : 0;
            }
            op_index++;
          } else {
            stack_index -= args + 1;
            stack[stack_index] = f != null ? f : 0;
            token = routine.ref[op_index].token;
            id = token.tokenizer.filename + "-" + token.line + "-" + token.column;
            if (!context.warnings.invoking_non_function[id]) {
              fc = routine.ref[op_index];
              i1 = fc.expression.token.start;
              i2 = fc.token.start + fc.token.length;
              context.warnings.invoking_non_function[id] = {
                file: token.tokenizer.filename,
                line: token.line,
                column: token.column,
                expression: fc.token.tokenizer.input.substring(i1, i2)
              };
            }
            op_index++;
          }
          break;
        case 93: // OPCODE_SUPER_CALL
          if ((call_super != null) && (call_supername != null)) {
            sup = call_super;
            f = null;
            while ((f == null) && (sup.class != null)) {
              sup = sup.class;
              f = sup[call_supername];
            }
            if ((f != null) && f instanceof Routine) {
              args = arg1[op_index];
              cs = call_stack[call_stack_index] || (call_stack[call_stack_index] = {});
              call_stack_index++;
              cs.object = object;
              cs.super = call_super;
              cs.supername = call_supername;
              cs.routine = routine;
              cs.op_index = op_index + 1;
              locals_offset += routine.locals_size;
              routine = f;
              opcodes = f.opcodes;
              arg1 = f.arg1;
              op_index = 0;
              length = opcodes.length;
              call_super = sup;
              if (routine.uses_arguments) {
                argv = stack.slice(stack_index - args + 1, stack_index + 1);
              }
              if (args < f.num_args) {
                for (i = w = ref13 = args + 1, ref14 = f.num_args; w <= ref14; i = w += 1) {
                  stack[++stack_index] = 0;
                }
              } else if (args > f.num_args) {
                stack_index -= args - f.num_args;
              }
              stack[++stack_index] = args;
              if (routine.uses_arguments) {
                stack[++stack_index] = argv;
              }
            } else {
              args = arg1[op_index];
              stack_index -= args;
              stack[++stack_index] = 0;
              op_index++;
            }
          } else {
            args = arg1[op_index];
            stack_index -= args;
            stack[++stack_index] = 0;
            op_index++;
          }
          break;
        case 94: // OPCODE_RETURN
          local_index -= arg1[op_index];
          if (call_stack_index <= 0) {
            op_index = length;
          } else {
            cs = call_stack[--call_stack_index];
            object = cs.object;
            call_super = cs.super;
            call_supername = cs.supername;
            routine = cs.routine;
            op_index = cs.op_index;
            opcodes = routine.opcodes;
            arg1 = routine.arg1;
            locals_offset -= routine.locals_size;
            length = opcodes.length;
          }
          break;
        case 100: // OPCODE_UNARY_FUNC
          v = arg1[op_index](stack[stack_index]);
          stack[stack_index] = isFinite(v) ? v : 0;
          op_index++;
          break;
        case 101: // OPCODE_BINARY_FUNC
          v = arg1[op_index](stack[stack_index - 1], stack[stack_index]);
          stack[--stack_index] = isFinite(v) ? v : 0;
          op_index++;
          break;
        case 110: // OPCODE_AFTER
          t = this.runner.createThread(stack[stack_index - 1], stack[stack_index], false);
          stack[--stack_index] = t;
          op_index += 1;
          break;
        // add thread to the runner thread list
        case 111: // OPCODE_EVERY
          t = this.runner.createThread(stack[stack_index - 1], stack[stack_index], true);
          stack[--stack_index] = t;
          op_index += 1;
          break;
        // add thread to the runner thread list
        case 112: // OPCODE_DO
          t = this.runner.createThread(stack[stack_index], 0, false);
          stack[stack_index] = t;
          op_index += 1;
          break;
        // add thread to the runner thread list
        case 113: // OPCODE_SLEEP
          sleep_time = isFinite(stack[stack_index]) ? stack[stack_index] : 0;
          this.runner.sleep(sleep_time);
          op_index += 1;
          restore_op_index = op_index;
          op_index = length; // stop the thread
          break;
        case 200: // COMPILED
          stack_index = arg1[op_index](stack, stack_index, locals, locals_offset, object, global);
          op_index++;
          break;
        default:
          throw `Unsupported operation: ${opcodes[op_index]}`;
      }
    }
    if (restore_op_index >= 0) {
      this.op_index = restore_op_index;
      this.routine = routine;
      this.stack_index = stack_index;
      this.local_index = local_index;
      this.object = object;
      this.call_stack_index = call_stack_index;
      this.call_super = call_super;
      this.call_supername = call_supername;
      this.locals_offset = locals_offset;
      this.done = false;
    } else {
      this.op_index = 0;
      this.done = true;
      if (this.routine.callback != null) {
        this.routine.callback(stack[stack_index]);
        this.routine.callback = null;
      }
    }
    // console.info """stack_index: #{stack_index}"""
    // console.info stack
    if (this.log) {
      console.info("total operations: " + op_count);
      console.info(`stack_index: ${stack_index}`);
      console.info(`result: ${stack[stack_index]}`);
    }
    return stack[stack_index];
  }

};


this.Program = class Program {
  constructor() {
    this.statements = [];
  }

  add(statement) {
    return this.statements.push(statement);
  }

  isAssignment() {
    return this.statements.length > 0 && this.statements[this.statements.length - 1] instanceof Program.Assignment;
  }

};

this.Program.Expression = class Expression {
  constructor() {}

};

this.Program.Assignment = class Assignment {
  constructor(token1, field1, expression1, local) {
    this.token = token1;
    this.field = field1;
    this.expression = expression1;
    this.local = local;
  }

};

this.Program.SelfAssignment = class SelfAssignment {
  constructor(token1, field1, operation, expression1) {
    this.token = token1;
    this.field = field1;
    this.operation = operation;
    this.expression = expression1;
  }

};

this.Program.Value = (function() {
  class Value {
    constructor(token1, type, value1) {
      this.token = token1;
      this.type = type;
      this.value = value1;
    }

  };

  Value.TYPE_NUMBER = 1;

  Value.TYPE_STRING = 2;

  Value.TYPE_ARRAY = 3;

  Value.TYPE_OBJECT = 4;

  Value.TYPE_FUNCTION = 5;

  Value.TYPE_CLASS = 6;

  return Value;

}).call(this);

this.Program.CreateFieldAccess = function(token, expression, field) {
  if (expression instanceof Program.Field) {
    expression.appendField(field);
    return expression;
  } else {
    return new Program.Field(token, expression, [field]);
  }
};

this.Program.Variable = class Variable {
  constructor(token1, identifier) {
    this.token = token1;
    this.identifier = identifier;
  }

};

this.Program.Field = class Field {
  constructor(token1, expression1, chain) {
    this.token = token1;
    this.expression = expression1;
    this.chain = chain;
    this.token = this.expression.token;
  }

  appendField(field) {
    return this.chain.push(field);
  }

};

this.Program.BuildOperations = function(ops, terms) {
  var i, o, o1, o2, prec, t1, t2;
  while (ops.length > 1) {
    i = 0;
    prec = 0;
    while (i < ops.length - 1) {
      o1 = ops[i];
      o2 = ops[i + 1];
      if (Program.Precedence[o2.operation] <= Program.Precedence[o1.operation]) {
        break;
      }
      i++;
    }
    t1 = terms[i];
    t2 = terms[i + 1];
    o = new Program.Operation(ops[i].token, ops[i].operation, t1, t2);
    terms.splice(i, 2, o);
    ops.splice(i, 1);
  }
  return new Program.Operation(ops[0].token, ops[0].operation, terms[0], terms[1]);
};

this.Program.Operation = class Operation {
  constructor(token1, operation, term1, term2) {
    this.token = token1;
    this.operation = operation;
    this.term1 = term1;
    this.term2 = term2;
  }

};

this.Program.Negate = class Negate {
  constructor(token1, expression1) {
    this.token = token1;
    this.expression = expression1;
  }

};

this.Program.Not = class Not {
  constructor(token1, expression1) {
    this.token = token1;
    this.expression = expression1;
  }

};

this.Program.Braced = class Braced {
  constructor(token1, expression1) {
    this.token = token1;
    this.expression = expression1;
  }

};

this.Program.Return = class Return {
  constructor(token1, expression1) {
    this.token = token1;
    this.expression = expression1;
  }

};

this.Program.Condition = class Condition {
  constructor(token1, chain) {
    this.token = token1;
    this.chain = chain;
  }

};

this.Program.For = class For {
  constructor(token1, iterator, range_from, range_to, range_by, sequence) {
    this.token = token1;
    this.iterator = iterator;
    this.range_from = range_from;
    this.range_to = range_to;
    this.range_by = range_by;
    this.sequence = sequence;
  }

};

this.Program.ForIn = class ForIn {
  constructor(token1, iterator, list, sequence) {
    this.token = token1;
    this.iterator = iterator;
    this.list = list;
    this.sequence = sequence;
  }

};

this.Program.toString = function(value, nesting = 0) {
  var i, j, k, key, len, pref, ref, s, v;
  if (value instanceof Routine) {
    if (nesting === 0) {
      return value.source || "[function]";
    } else {
      return "[function]";
    }
  } else if (typeof value === "function") {
    return "[native function]";
  } else if (typeof value === "string") {
    return `"${value}"`;
  } else if (Array.isArray(value)) {
    if (nesting >= 1) {
      return "[list]";
    }
    s = "[";
    for (i = j = 0, len = value.length; j < len; i = ++j) {
      v = value[i];
      s += Program.toString(v, nesting + 1) + (i < value.length - 1 ? "," : "");
    }
    return s + "]";
  } else if (typeof value === "object") {
    if (nesting >= 1) {
      return "[object]";
    }
    s = "object\n";
    pref = "";
    for (i = k = 1, ref = nesting; k <= ref; i = k += 1) {
      pref += "  ";
    }
    for (key in value) {
      v = value[key];
      s += pref + `  ${key} = ${Program.toString(v, nesting + 1)}\n`;
    }
    return s + pref + "end";
  }
  return value || 0;
};

this.Program.While = class While {
  constructor(token1, condition, sequence) {
    this.token = token1;
    this.condition = condition;
    this.sequence = sequence;
  }

};

this.Program.Break = class Break {
  constructor(token1) {
    this.token = token1;
    this.nopop = true;
  }

};

this.Program.Continue = class Continue {
  constructor(token1) {
    this.token = token1;
    this.nopop = true;
  }

};

this.Program.Function = class Function {
  constructor(token1, args, sequence, end) {
    this.token = token1;
    this.args = args;
    this.sequence = sequence;
    this.source = "function" + this.token.tokenizer.input.substring(this.token.index, end.index + 2);
  }

};

this.Program.FunctionCall = class FunctionCall {
  constructor(token1, expression1, args) {
    this.token = token1;
    this.expression = expression1;
    this.args = args;
  }

};

this.Program.CreateObject = class CreateObject {
  constructor(token1, fields) {
    this.token = token1;
    this.fields = fields;
  }

};

this.Program.CreateClass = class CreateClass {
  constructor(token1, ext, fields) {
    this.token = token1;
    this.ext = ext;
    this.fields = fields;
  }

};

this.Program.NewCall = class NewCall {
  constructor(token1, expression1) {
    this.token = token1;
    this.expression = expression1;
    if (!(this.expression instanceof Program.FunctionCall)) {
      this.expression = new Program.FunctionCall(this.token, this.expression, []);
    }
  }

};

this.Program.After = class After {
  constructor(token1, delay, sequence, end, multiplier) {
    this.token = token1;
    this.delay = delay;
    this.sequence = sequence;
    this.multiplier = multiplier;
    this.source = "after " + this.token.tokenizer.input.substring(this.token.index, end.index + 2);
  }

};

this.Program.Every = class Every {
  constructor(token1, delay, sequence, end, multiplier) {
    this.token = token1;
    this.delay = delay;
    this.sequence = sequence;
    this.multiplier = multiplier;
    this.source = "every " + this.token.tokenizer.input.substring(this.token.index, end.index + 2);
  }

};

this.Program.Do = class Do {
  constructor(token1, sequence, end) {
    this.token = token1;
    this.sequence = sequence;
    this.source = "do " + this.token.tokenizer.input.substring(this.token.index, end.index + 2);
  }

};

this.Program.Sleep = class Sleep {
  constructor(token1, delay, multiplier) {
    this.token = token1;
    this.delay = delay;
    this.multiplier = multiplier;
  }

};

this.Program.Delete = class Delete {
  constructor(token1, field1) {
    this.token = token1;
    this.field = field1;
  }

};

this.Program.Precedence = {
  "^": 21,
  "/": 20,
  "*": 19,
  "%": 18,
  "+": 17,
  "-": 17,
  "<": 16,
  "<=": 15,
  ">": 14,
  ">=": 13,
  "==": 12,
  "!=": 11,
  "<<": 10,
  ">>": 9,
  "&": 8,
  "|": 7,
  "and": 6,
  "or": 5
};


this.Routine = class Routine {
  constructor(num_args) {
    this.num_args = num_args;
    this.ops = [];
    this.opcodes = [];
    this.arg1 = [];
    this.ref = [];
    this.label_count = 0;
    this.labels = {};
    this.transpile = false;
    this.import_refs = [];
    this.import_values = [];
    this.import_self = -1;
  }

  clone() {
    var r;
    r = new Routine(this.num_args);
    r.opcodes = this.opcodes;
    r.arg1 = this.arg1;
    r.ref = this.ref;
    r.locals_size = this.locals_size;
    r.uses_arguments = this.uses_arguments;
    return r;
  }

  createLabel(str = "label") {
    var name;
    return name = ":" + str + "_" + this.label_count++;
  }

  setLabel(name) {
    return this.labels[name] = this.opcodes.length;
  }

  optimize() {
    if (this.transpile) {
      new Transpiler().transpile(this);
    }
  }

  removeable(index) {
    var label, ref1, value;
    ref1 = this.labels;
    for (label in ref1) {
      value = ref1[label];
      if (value === index) {
        return false;
      }
    }
    return true;
  }

  remove(index) {
    var label, ref1, value;
    ref1 = this.labels;
    for (label in ref1) {
      value = ref1[label];
      if (value === index) {
        return false;
      } else if (value > index) {
        this.labels[label] -= 1;
      }
    }
    this.opcodes.splice(index, 1);
    this.arg1.splice(index, 1);
    this.ref.splice(index, 1);
    return true;
  }

  resolveLabels() {
    var i, j, ref1, ref2, ref3, results;
    results = [];
    for (i = j = 0, ref1 = this.opcodes.length - 1; (0 <= ref1 ? j <= ref1 : j >= ref1); i = 0 <= ref1 ? ++j : --j) {
      if ((ref2 = this.opcodes[i]) === OPCODES.JUMP || ref2 === OPCODES.JUMPY || ref2 === OPCODES.JUMPN || ref2 === OPCODES.JUMPY_NOPOP || ref2 === OPCODES.JUMPN_NOPOP) {
        if (this.labels[this.arg1[i]]) {
          results.push(this.arg1[i] = this.labels[this.arg1[i]]);
        } else {
          results.push(void 0);
        }
      } else if ((ref3 = this.opcodes[i]) === OPCODES.FORLOOP_CONTROL || ref3 === OPCODES.FORLOOP_INIT || ref3 === OPCODES.FORIN_CONTROL || ref3 === OPCODES.FORIN_INIT) {
        if (this.labels[this.arg1[i][1]]) {
          results.push(this.arg1[i][1] = this.labels[this.arg1[i][1]]);
        } else {
          results.push(void 0);
        }
      } else {
        results.push(void 0);
      }
    }
    return results;
  }

  OP(code, ref, v1 = 0) {
    this.opcodes.push(code);
    this.arg1.push(v1);
    return this.ref.push(ref);
  }

  OP_INSERT(code, ref, v1 = 0, index) {
    var label, ref1, value;
    this.opcodes.splice(index, 0, code);
    this.arg1.splice(index, 0, v1);
    this.ref.splice(index, 0, ref);
    ref1 = this.labels;
    for (label in ref1) {
      value = ref1[label];
      if (value >= index) {
        this.labels[label] += 1;
      }
    }
  }

  TYPE(ref) {
    return this.OP(OPCODES.TYPE, ref);
  }

  VARIABLE_TYPE(variable, ref) {
    return this.OP(OPCODES.VARIABLE_TYPE, ref, variable);
  }

  PROPERTY_TYPE(ref) {
    return this.OP(OPCODES.PROPERTY_TYPE, ref);
  }

  LOAD_THIS(ref) {
    return this.OP(OPCODES.LOAD_THIS, ref);
  }

  LOAD_GLOBAL(ref) {
    return this.OP(OPCODES.LOAD_GLOBAL, ref);
  }

  LOAD_VALUE(value, ref) {
    return this.OP(OPCODES.LOAD_VALUE, ref, value);
  }

  LOAD_LOCAL(index, ref) {
    return this.OP(OPCODES.LOAD_LOCAL, ref, index);
  }

  LOAD_VARIABLE(variable, ref) {
    return this.OP(OPCODES.LOAD_VARIABLE, ref, variable);
  }

  LOAD_LOCAL_OBJECT(index, ref) {
    return this.OP(OPCODES.LOAD_LOCAL_OBJECT, ref, index);
  }

  LOAD_VARIABLE_OBJECT(variable, ref) {
    return this.OP(OPCODES.LOAD_VARIABLE_OBJECT, ref, variable);
  }

  POP(ref) {
    return this.OP(OPCODES.POP, ref);
  }

  LOAD_PROPERTY(ref) {
    return this.OP(OPCODES.LOAD_PROPERTY, ref);
  }

  LOAD_PROPERTY_OBJECT(ref) {
    return this.OP(OPCODES.LOAD_PROPERTY_OBJECT, ref);
  }

  CREATE_OBJECT(ref) {
    return this.OP(OPCODES.CREATE_OBJECT, ref);
  }

  MAKE_OBJECT(ref) {
    return this.OP(OPCODES.MAKE_OBJECT, ref);
  }

  CREATE_ARRAY(ref) {
    return this.OP(OPCODES.CREATE_ARRAY, ref);
  }

  CREATE_CLASS(parent_var, ref) {
    return this.OP(OPCODES.CREATE_CLASS, ref, parent_var);
  }

  UPDATE_CLASS(variable, ref) {
    return this.OP(OPCODES.UPDATE_CLASS, ref, variable);
  }

  NEW_CALL(args, ref) {
    return this.OP(OPCODES.NEW_CALL, ref, args);
  }

  ADD(ref, self = 0) {
    return this.OP(OPCODES.ADD, ref, self);
  }

  SUB(ref, self = 0) {
    return this.OP(OPCODES.SUB, ref, self);
  }

  MUL(ref) {
    return this.OP(OPCODES.MUL, ref);
  }

  DIV(ref) {
    return this.OP(OPCODES.DIV, ref);
  }

  MODULO(ref) {
    return this.OP(OPCODES.MODULO, ref);
  }

  BINARY_AND(ref) {
    return this.OP(OPCODES.BINARY_AND, ref);
  }

  BINARY_OR(ref) {
    return this.OP(OPCODES.BINARY_OR, ref);
  }

  SHIFT_LEFT(ref) {
    return this.OP(OPCODES.SHIFT_LEFT, ref);
  }

  SHIFT_RIGHT(ref) {
    return this.OP(OPCODES.SHIFT_RIGHT, ref);
  }

  NEGATE(ref) {
    return this.OP(OPCODES.NEGATE, ref);
  }

  LOAD_PROPERTY_ATOP(ref) {
    return this.OP(OPCODES.LOAD_PROPERTY_ATOP, ref);
  }

  EQ(ref) {
    return this.OP(OPCODES.EQ, ref);
  }

  NEQ(ref) {
    return this.OP(OPCODES.NEQ, ref);
  }

  LT(ref) {
    return this.OP(OPCODES.LT, ref);
  }

  GT(ref) {
    return this.OP(OPCODES.GT, ref);
  }

  LTE(ref) {
    return this.OP(OPCODES.LTE, ref);
  }

  GTE(ref) {
    return this.OP(OPCODES.GTE, ref);
  }

  NOT(ref) {
    return this.OP(OPCODES.NOT, ref);
  }

  FORLOOP_INIT(iterator, ref) {
    return this.OP(OPCODES.FORLOOP_INIT, ref, iterator);
  }

  FORLOOP_CONTROL(args, ref) {
    return this.OP(OPCODES.FORLOOP_CONTROL, ref, args);
  }

  FORIN_INIT(args, ref) {
    return this.OP(OPCODES.FORIN_INIT, ref, args);
  }

  FORIN_CONTROL(args, ref) {
    return this.OP(OPCODES.FORIN_CONTROL, ref, args);
  }

  JUMP(index, ref) {
    return this.OP(OPCODES.JUMP, ref, index);
  }

  JUMPY(index, ref) {
    return this.OP(OPCODES.JUMPY, ref, index);
  }

  JUMPN(index, ref) {
    return this.OP(OPCODES.JUMPN, ref, index);
  }

  JUMPY_NOPOP(index, ref) {
    return this.OP(OPCODES.JUMPY_NOPOP, ref, index);
  }

  JUMPN_NOPOP(index, ref) {
    return this.OP(OPCODES.JUMPN_NOPOP, ref, index);
  }

  STORE_LOCAL(index, ref) {
    return this.OP(OPCODES.STORE_LOCAL, ref, index);
  }

  STORE_VARIABLE(field, ref) {
    return this.OP(OPCODES.STORE_VARIABLE, ref, field);
  }

  CREATE_PROPERTY(ref) {
    return this.OP(OPCODES.CREATE_PROPERTY, ref);
  }

  STORE_PROPERTY(ref) {
    return this.OP(OPCODES.STORE_PROPERTY, ref);
  }

  LOAD_ROUTINE(value, ref) {
    return this.OP(OPCODES.LOAD_ROUTINE, ref, value);
  }

  FUNCTION_CALL(args, ref) {
    return this.OP(OPCODES.FUNCTION_CALL, ref, args);
  }

  FUNCTION_APPLY_VARIABLE(args, ref) {
    return this.OP(OPCODES.FUNCTION_APPLY_VARIABLE, ref, args);
  }

  FUNCTION_APPLY_PROPERTY(args, ref) {
    return this.OP(OPCODES.FUNCTION_APPLY_PROPERTY, ref, args);
  }

  SUPER_CALL(args, ref) {
    return this.OP(OPCODES.SUPER_CALL, ref, args);
  }

  RETURN(ref) {
    return this.OP(OPCODES.RETURN, ref);
  }

  AFTER(ref) {
    return this.OP(OPCODES.AFTER, ref);
  }

  EVERY(ref) {
    return this.OP(OPCODES.EVERY, ref);
  }

  DO(ref) {
    return this.OP(OPCODES.DO, ref);
  }

  SLEEP(ref) {
    return this.OP(OPCODES.SLEEP, ref);
  }

  DELETE(ref) {
    return this.OP(OPCODES.DELETE, ref);
  }

  UNARY_OP(f, ref) {
    return this.OP(OPCODES.UNARY_OP, ref, f);
  }

  BINARY_OP(f, ref) {
    return this.OP(OPCODES.BINARY_OP, ref, f);
  }

  toString() {
    var i, j, len, op, ref1, s;
    s = "";
    ref1 = this.opcodes;
    for (i = j = 0, len = ref1.length; j < len; i = ++j) {
      op = ref1[i];
      s += OPCODES[op];
      if (this.arg1[i] != null) {
        //if typeof @arg1[i] != "function"
        s += ` ${this.arg1[i]}`;
      }
      s += "\n";
    }
    return s;
  }

  exportArg(arg) {
    if (arg == null) {
      return 0;
    } else if (arg instanceof Routine) {
      return arg.export();
    } else if (typeof arg === "function") {
      return arg.name;
    } else {
      return arg;
    }
  }

  export() {
    var args, i, j, ref1, res;
    args = [];
    for (i = j = 0, ref1 = this.arg1.length - 1; j <= ref1; i = j += 1) {
      args[i] = this.exportArg(this.arg1[i]);
    }
    res = {
      num_args: this.num_args,
      ops: this.opcodes,
      args: args,
      import_refs: this.import_refs,
      import_values: this.import_values,
      import_self: this.import_self,
      locals_size: this.locals_size
    };
    return res;
  }

  import(src) {
    var i, j, ref, ref1, token;
    this.num_args = src.num_args;
    this.opcodes = src.ops;
    this.arg1 = src.args;
    this.import_refs = src.import_refs;
    this.import_values = src.import_values;
    this.import_self = src.import_self;
    this.locals_size = src.locals_size;
    token = {
      line: 0,
      column: 0,
      start: 0,
      length: 0,
      index: 0,
      tokenizer: {
        filename: "filename",
        input: ""
      }
    };
    ref = {
      expression: {
        token: token
      },
      token: token
    };
    for (i = j = 0, ref1 = this.opcodes.length - 1; j <= ref1; i = j += 1) {
      if (this.opcodes[i] === 100) {
        this.arg1[i] = Compiler.predefined_unary_functions[this.arg1[i]];
      } else if (this.opcodes[i] === 101) {
        this.arg1[i] = Compiler.predefined_binary_functions[this.arg1[i]];
      } else if (typeof this.arg1[i] === "object" && !Array.isArray(this.arg1[i])) {
        this.arg1[i] = new Routine(0).import(this.arg1[i]);
      }
      this.ref[i] = ref;
    }
    return this;
  }

};

this.OPCODES_CLASS = class OPCODES_CLASS {
  constructor() {
    this.table = {};
    this.set("TYPE", 1);
    this.set("VARIABLE_TYPE", 2);
    this.set("PROPERTY_TYPE", 3);
    this.set("LOAD_IMPORT", 4);
    this.set("LOAD_THIS", 5);
    this.set("LOAD_GLOBAL", 6);
    this.set("LOAD_VALUE", 10);
    this.set("LOAD_LOCAL", 11);
    this.set("LOAD_VARIABLE", 12);
    this.set("LOAD_LOCAL_OBJECT", 13);
    this.set("LOAD_VARIABLE_OBJECT", 14);
    this.set("POP", 15);
    this.set("LOAD_PROPERTY", 16);
    this.set("LOAD_PROPERTY_OBJECT", 17);
    this.set("CREATE_OBJECT", 18);
    this.set("MAKE_OBJECT", 19);
    this.set("CREATE_ARRAY", 20);
    this.set("STORE_LOCAL", 21);
    this.set("STORE_VARIABLE", 23);
    this.set("CREATE_PROPERTY", 24);
    this.set("STORE_PROPERTY", 25);
    this.set("DELETE", 26);
    this.set("UPDATE_CLASS", 27);
    this.set("CREATE_CLASS", 28);
    this.set("NEW_CALL", 29);
    this.set("ADD", 30);
    this.set("SUB", 31);
    this.set("MUL", 32);
    this.set("DIV", 33);
    this.set("MODULO", 34);
    this.set("BINARY_AND", 35);
    this.set("BINARY_OR", 36);
    this.set("SHIFT_LEFT", 37);
    this.set("SHIFT_RIGHT", 38);
    this.set("NEGATE", 39);
    this.set("EQ", 40);
    this.set("NEQ", 41);
    this.set("LT", 42);
    this.set("GT", 43);
    this.set("LTE", 44);
    this.set("GTE", 45);
    this.set("NOT", 50);
    this.set("LOAD_PROPERTY_ATOP", 68);
    this.set("JUMP", 80);
    this.set("JUMPY", 81);
    this.set("JUMPN", 82);
    this.set("JUMPY_NOPOP", 83);
    this.set("JUMPN_NOPOP", 84);
    this.set("LOAD_ROUTINE", 89);
    this.set("FUNCTION_CALL", 90);
    this.set("FUNCTION_APPLY_VARIABLE", 91);
    this.set("FUNCTION_APPLY_PROPERTY", 92);
    this.set("SUPER_CALL", 93);
    this.set("RETURN", 94);
    this.set("FORLOOP_INIT", 95);
    this.set("FORLOOP_CONTROL", 96);
    this.set("FORIN_INIT", 97);
    this.set("FORIN_CONTROL", 98);
    this.set("UNARY_OP", 100);
    this.set("BINARY_OP", 101);
    this.set("COMPILED", 200);
    this.set("AFTER", 110);
    this.set("EVERY", 111);
    this.set("DO", 112);
    this.set("SLEEP", 113);
  }

  set(op, code) {
    this[op] = code;
    return this[code] = op;
  }

};

this.OPCODES = new this.OPCODES_CLASS;


this.Runner = class Runner {
  constructor(microvm) {
    this.microvm = microvm;
  }

  init() {
    this.initialized = true;
    this.system = this.microvm.context.global.system;
    this.system.preemptive = 1;
    this.system.threads = [];
    this.main_thread = new Thread(this);
    this.threads = [this.main_thread];
    this.current_thread = this.main_thread;
    this.thread_index = 0;
    this.microvm.context.global.print = this.microvm.context.meta.print;
    this.microvm.context.global.random = new Random(0);
    this.microvm.context.global.Function = {
      bind: function(obj) {
        var rc;
        if (this instanceof Routine) {
          rc = this.clone();
          rc.object = obj;
          return rc;
        } else {
          return this;
        }
      }
    };
    this.microvm.context.global.List = {
      sortList: (f) => {
        var funk;
        if ((f != null) && f instanceof Program.Function) {
          funk = function(a, b) {
            return f.call(this.microvm.context.global, [a, b], true);
          };
        } else if ((f != null) && typeof f === "function") {
          funk = f;
        }
        return this.sort(funk);
      },
      "+": function(a, b, self) {
        if (!self) { // not +=, clone array a
          a = [...a];
        }
        if (Array.isArray(b)) {
          return a.concat(b);
        } else {
          a.push(b);
          return a;
        }
      },
      "-": function(a, b, self) {
        var index;
        if (!self) { // not -=, clone array a
          a = [...a];
        }
        index = a.indexOf(b);
        if (index >= 0) {
          a.splice(index, 1);
        }
        return a;
      }
    };
    this.microvm.context.global.Object = {};
    this.microvm.context.global.String = {
      fromCharCode: function(...args) { return String.fromCharCode(...args) },
      "+": function(a, b) {
        return a + b;
      }
    };
    this.microvm.context.global.Number = {
      parse: function(s) {
        var res;
        res = Number.parseFloat(s);
        if (isFinite(res)) {
          return res;
        } else {
          return 0;
        }
      },
      toString: function() {
        return this.toString();
      }
    };
    this.fps = 60;
    this.fps_max = 60;
    this.cpu_load = 0;
    this.microvm.context.meta.print("microScript 2.0");
    return this.triggers_controls_update = true;
  }

  run(src, filename, callback) {
    var compiler, err, id, j, len, parser, program, ref, result, w;
    if (!this.initialized) {
      this.init();
    }
    parser = new Parser(src, filename);
    parser.parse();
    if (parser.error_info != null) {
      err = parser.error_info;
      err.type = "compile";
      throw err;
    }
    if (parser.warnings.length > 0) {
      ref = parser.warnings;
      for (j = 0, len = ref.length; j < len; j++) {
        w = ref[j];
        id = filename + "-" + w.line + "-" + w.column;
        switch (w.type) {
          case "assigning_api_variable":
            if (this.microvm.context.warnings.assigning_api_variable[id] == null) {
              this.microvm.context.warnings.assigning_api_variable[id] = {
                file: filename,
                line: w.line,
                column: w.column,
                expression: w.identifier
              };
            }
            break;
          case "assignment_as_condition":
            if (this.microvm.context.warnings.assignment_as_condition[id] == null) {
              this.microvm.context.warnings.assignment_as_condition[id] = {
                file: filename,
                line: w.line,
                column: w.column
              };
            }
        }
      }
    }
    program = parser.program;
    compiler = new Compiler(program);
    result = null;
    compiler.routine.callback = function(res) {
      if (callback != null) {
        return callback(Program.toString(res));
      } else {
        return result = res;
      }
    };
    this.main_thread.addCall(compiler.routine);
    this.tick();
    return result;
  }

  call(name, args) {
    var f, routine;
    if (name === "draw" || name === "update" || name === "serverUpdate") {
      if (this.microvm.context.global[name] != null) {
        this.main_thread.addCall(`${name}()`);
      }
      return;
    }
    if (this.microvm.context.global[name] != null) {
      if ((args == null) || !args.length) {
        return this.main_thread.addCall(`${name}()`);
      } else {
        routine = this.microvm.context.global[name];
        if (routine instanceof Routine) {
          f = this.main_thread.processor.routineAsFunction(routine, this.microvm.context);
          return f(...args);
        } else if (typeof routine === "function") {
          return routine(...args);
        }
      }
    } else {
      return 0;
    }
  }

  toString(obj) {
    return Program.toString(obj);
  }

  process(thread, time_limit) {
    var processor;
    processor = thread.processor;
    processor.time_limit = time_limit;
    this.current_thread = thread;
    return processor.run(this.microvm.context);
  }

  tick() {
    var dt, frame_time, i, index, j, k, len, load, margin, processing, processor, ref, ref1, t, time, time_limit, time_out;
    if (this.system.fps != null) {
      this.fps = this.fps * .9 + this.system.fps * .1;
    }
    this.fps_max = Math.max(this.fps, this.fps_max);
    frame_time = Math.min(16, Math.floor(1000 / this.fps_max));
    if (this.fps < 59) {
      margin = 10;
    } else {
      margin = Math.floor(1000 / this.fps * .8);
    }
    time = Date.now();
    time_limit = time + 100; // allow more time to prevent interrupting main_thread in the middle of a draw()
    time_out = this.system.preemptive ? time_limit : 2e308;
    processor = this.main_thread.processor;
    if (!processor.done) {
      if (this.main_thread.sleep_until != null) {
        if (Date.now() >= this.main_thread.sleep_until) {
          delete this.main_thread.sleep_until;
          this.process(this.main_thread, time_out);
        }
      } else {
        this.process(this.main_thread, time_out);
      }
    }
    while (processor.done && Date.now() < time_out && this.main_thread.loadNext()) {
      this.process(this.main_thread, time_out);
    }
    time_limit = time + margin; // secondary threads get remaining time
    time_out = this.system.preemptive ? time_limit : 2e308;
    processing = true;
    while (processing) {
      processing = false;
      ref = this.threads;
      for (j = 0, len = ref.length; j < len; j++) {
        t = ref[j];
        if (t !== this.main_thread) {
          if (t.paused || t.terminated) {
            continue;
          }
          processor = t.processor;
          if (!processor.done) {
            if (t.sleep_until != null) {
              if (Date.now() >= t.sleep_until) {
                delete t.sleep_until;
                this.process(t, time_out);
                processing = true;
              }
            } else {
              this.process(t, time_out);
              processing = true;
            }
          } else if (t.start_time != null) {
            if (t.repeat) {
              while (time >= t.start_time && !(t.paused || t.terminated)) {
                if (time >= t.start_time + 150) {
                  t.start_time = time + t.delay;
                } else {
                  t.start_time += t.delay;
                }
                processor.load(t.routine);
                this.process(t, time_out);
                processing = true;
              }
            } else {
              if (time >= t.start_time) {
                delete t.start_time;
                processor.load(t.routine);
                this.process(t, time_out);
                processing = true;
              }
            }
          } else {
            t.terminated = true;
          }
        }
      }
      if (Date.now() > time_limit) {
        break;
      }
    }
    for (i = k = ref1 = this.threads.length - 1; k >= 1; i = k += -1) {
      t = this.threads[i];
      if (t.terminated) {
        this.threads.splice(i, 1);
        index = this.system.threads.indexOf(t.interface);
        if (index >= 0) {
          this.system.threads.splice(index, 1);
        }
      }
    }
    t = Date.now() - time;
    dt = time_limit - time;
    load = t / dt * 100;
    this.cpu_load = this.cpu_load * .9 + load * .1;
    this.system.cpu_load = Math.min(100, Math.round(this.cpu_load));
  }

  createThread(routine, delay, repeat) {
    var i, j, ref, t;
    t = new Thread(this);
    t.routine = routine;
    this.threads.push(t);
    t.start_time = Date.now() + delay - 1000 / this.fps;
    if (repeat) {
      t.repeat = repeat;
      t.delay = delay;
    }
    this.system.threads.push(t.interface);
    for (i = j = 0, ref = routine.import_values.length - 1; j <= ref; i = j += 1) {
      if (routine.import_values[i] === routine) {
        routine.import_values[i] = t.interface;
      }
    }
    return t.interface;
  }

  sleep(value) {
    if (this.current_thread != null) {
      return this.current_thread.sleep_until = Date.now() + Math.max(0, value);
    }
  }

};

this.Thread = class Thread {
  constructor(runner) {
    this.runner = runner;
    this.loop = false;
    this.processor = new Processor(this.runner);
    this.paused = false;
    this.terminated = false;
    this.next_calls = [];
    this.interface = {
      pause: () => {
        return this.pause();
      },
      resume: () => {
        return this.resume();
      },
      stop: () => {
        return this.stop();
      },
      status: "running"
    };
  }

  addCall(call) {
    if (this.next_calls.indexOf(call) < 0) {
      return this.next_calls.push(call);
    }
  }

  loadNext() {
    var compiler, f, parser, program;
    if (this.next_calls.length > 0) {
      f = this.next_calls.splice(0, 1)[0];
      if (f instanceof Routine) {
        this.processor.load(f);
      } else {
        parser = new Parser(f, "");
        parser.parse();
        program = parser.program;
        compiler = new Compiler(program);
        this.processor.load(compiler.routine);
        if ((f === "update()" || f === "serverUpdate()") && (this.runner.updateControls != null)) {
          this.runner.updateControls();
        }
      }
      return true;
    } else {
      return false;
    }
  }

  pause() {
    if (this.interface.status === "running") {
      this.interface.status = "paused";
      this.paused = true;
      return 1;
    } else {
      return 0;
    }
  }

  resume() {
    if (this.interface.status === "paused") {
      this.interface.status = "running";
      this.paused = false;
      return 1;
    } else {
      return 0;
    }
  }

  stop() {
    this.interface.status = "stopped";
    this.terminated = true;
    return 1;
  }

};


this.Token = class Token {
  constructor(tokenizer, type, value, string_value) {
    this.tokenizer = tokenizer;
    this.type = type;
    this.value = value;
    this.string_value = string_value;
    this.line = this.tokenizer.line;
    this.column = this.tokenizer.column;
    this.start = this.tokenizer.token_start;
    this.length = this.tokenizer.index - this.start;
    this.index = this.tokenizer.index;
    if (this.type === Token.TYPE_IDENTIFIER && Token.predefined.hasOwnProperty(this.value)) {
      this.type = Token.predefined[this.value];
      this.reserved_keyword = true;
    }
    this.is_binary_operator = (this.type >= 30 && this.type <= 39) || (this.type >= 200 && this.type <= 201) || (this.type >= 2 && this.type <= 7);
  }

  toString() {
    return this.value + " : " + this.type;
  }

};

this.Token.TYPE_EQUALS = 1;

this.Token.TYPE_DOUBLE_EQUALS = 2;

this.Token.TYPE_GREATER = 3;

this.Token.TYPE_GREATER_OR_EQUALS = 4;

this.Token.TYPE_LOWER = 5;

this.Token.TYPE_LOWER_OR_EQUALS = 6;

this.Token.TYPE_UNEQUALS = 7;

this.Token.TYPE_IDENTIFIER = 10;

this.Token.TYPE_NUMBER = 11;

this.Token.TYPE_STRING = 12;

this.Token.TYPE_OPEN_BRACE = 20;

this.Token.TYPE_CLOSED_BRACE = 21;

// @Token.TYPE_OPEN_CURLY_BRACE = 22
// @Token.TYPE_CLOSED_CURLY_BRACE = 23
this.Token.TYPE_OPEN_BRACKET = 24;

this.Token.TYPE_CLOSED_BRACKET = 25;

this.Token.TYPE_COMMA = 26;

this.Token.TYPE_DOT = 27;

this.Token.TYPE_PLUS = 30;

this.Token.TYPE_MINUS = 31;

this.Token.TYPE_MULTIPLY = 32;

this.Token.TYPE_DIVIDE = 33;

this.Token.TYPE_POWER = 34;

this.Token.TYPE_MODULO = 35;

this.Token.TYPE_BINARY_AND = 36;

this.Token.TYPE_BINARY_OR = 37;

this.Token.TYPE_SHIFT_LEFT = 38;

this.Token.TYPE_SHIFT_RIGHT = 39;

this.Token.TYPE_PLUS_EQUALS = 40;

this.Token.TYPE_MINUS_EQUALS = 41;

this.Token.TYPE_MULTIPLY_EQUALS = 42;

this.Token.TYPE_DIVIDE_EQUALS = 43;

this.Token.TYPE_MODULO_EQUALS = 44;

this.Token.TYPE_AND_EQUALS = 45;

this.Token.TYPE_OR_EQUALS = 46;

this.Token.TYPE_RETURN = 50;

this.Token.TYPE_BREAK = 51;

this.Token.TYPE_CONTINUE = 52;

this.Token.TYPE_FUNCTION = 60;

this.Token.TYPE_AFTER = 61;

this.Token.TYPE_EVERY = 62;

this.Token.TYPE_DO = 63;

this.Token.TYPE_SLEEP = 64;

this.Token.TYPE_LOCAL = 70;

this.Token.TYPE_OBJECT = 80;

this.Token.TYPE_CLASS = 90;

this.Token.TYPE_EXTENDS = 91;

this.Token.TYPE_NEW = 92;

this.Token.TYPE_FOR = 100;

this.Token.TYPE_TO = 101;

this.Token.TYPE_BY = 102;

this.Token.TYPE_IN = 103;

this.Token.TYPE_WHILE = 104;

this.Token.TYPE_IF = 105;

this.Token.TYPE_THEN = 106;

this.Token.TYPE_ELSE = 107;

this.Token.TYPE_ELSIF = 108;

this.Token.TYPE_END = 120;

this.Token.TYPE_AND = 200;

this.Token.TYPE_OR = 201;

this.Token.TYPE_NOT = 202;

this.Token.TYPE_ERROR = 404;

this.Token.predefined = {};

this.Token.predefined["return"] = this.Token.TYPE_RETURN;

this.Token.predefined["break"] = this.Token.TYPE_BREAK;

this.Token.predefined["continue"] = this.Token.TYPE_CONTINUE;

this.Token.predefined["function"] = this.Token.TYPE_FUNCTION;

this.Token.predefined["for"] = this.Token.TYPE_FOR;

this.Token.predefined["to"] = this.Token.TYPE_TO;

this.Token.predefined["by"] = this.Token.TYPE_BY;

this.Token.predefined["in"] = this.Token.TYPE_IN;

this.Token.predefined["while"] = this.Token.TYPE_WHILE;

this.Token.predefined["if"] = this.Token.TYPE_IF;

this.Token.predefined["then"] = this.Token.TYPE_THEN;

this.Token.predefined["else"] = this.Token.TYPE_ELSE;

this.Token.predefined["elsif"] = this.Token.TYPE_ELSIF;

this.Token.predefined["end"] = this.Token.TYPE_END;

this.Token.predefined["object"] = this.Token.TYPE_OBJECT;

this.Token.predefined["class"] = this.Token.TYPE_CLASS;

this.Token.predefined["extends"] = this.Token.TYPE_EXTENDS;

this.Token.predefined["new"] = this.Token.TYPE_NEW;

this.Token.predefined["and"] = this.Token.TYPE_AND;

this.Token.predefined["or"] = this.Token.TYPE_OR;

this.Token.predefined["not"] = this.Token.TYPE_NOT;

this.Token.predefined["after"] = this.Token.TYPE_AFTER;

this.Token.predefined["every"] = this.Token.TYPE_EVERY;

this.Token.predefined["do"] = this.Token.TYPE_DO;

this.Token.predefined["sleep"] = this.Token.TYPE_SLEEP;

this.Token.predefined["delete"] = this.Token.TYPE_DELETE;

this.Token.predefined["local"] = this.Token.TYPE_LOCAL;


this.Tokenizer = class Tokenizer {
  constructor(input, filename) {
    this.input = input;
    this.filename = filename;
    this.index = 0;
    this.line = 1;
    this.column = 0;
    this.last_column = 0;
    this.buffer = [];
    this.chars = {};
    this.chars["("] = Token.TYPE_OPEN_BRACE;
    this.chars[")"] = Token.TYPE_CLOSED_BRACE;
    this.chars["["] = Token.TYPE_OPEN_BRACKET;
    this.chars["]"] = Token.TYPE_CLOSED_BRACKET;
    this.chars["{"] = Token.TYPE_OPEN_CURLY_BRACE;
    this.chars["}"] = Token.TYPE_CLOSED_CURLY_BRACE;
    this.chars["^"] = Token.TYPE_POWER;
    this.chars[","] = Token.TYPE_COMMA;
    this.chars["."] = Token.TYPE_DOT;
    this.doubles = {};
    this.doubles[">"] = [Token.TYPE_GREATER, Token.TYPE_GREATER_OR_EQUALS];
    this.doubles["<"] = [Token.TYPE_LOWER, Token.TYPE_LOWER_OR_EQUALS];
    this.doubles["="] = [Token.TYPE_EQUALS, Token.TYPE_DOUBLE_EQUALS];
    this.doubles["+"] = [Token.TYPE_PLUS, Token.TYPE_PLUS_EQUALS];
    this.doubles["-"] = [Token.TYPE_MINUS, Token.TYPE_MINUS_EQUALS];
    this.doubles["*"] = [Token.TYPE_MULTIPLY, Token.TYPE_MULTIPLY_EQUALS];
    this.doubles["/"] = [Token.TYPE_DIVIDE, Token.TYPE_DIVIDE_EQUALS];
    this.doubles["%"] = [Token.TYPE_MODULO, Token.TYPE_MODULO_EQUALS];
    this.doubles["&"] = [Token.TYPE_BINARY_AND, Token.TYPE_AND_EQUALS];
    this.doubles["|"] = [Token.TYPE_BINARY_OR, Token.TYPE_OR_EQUALS];
    this.shifts = {
      "<": Token.TYPE_SHIFT_LEFT,
      ">": Token.TYPE_SHIFT_RIGHT
    };
    this.letter_regex = RegExp(/^\p{L}/, 'u');
  }

  pushBack(token) {
    return this.buffer.splice(0, 0, token);
  }

  finished() {
    return this.index >= this.input.length && this.buffer.length === 0;
  }

  nextChar(ignore_comments = false) {
    var c, endseq;
    c = this.input.charAt(this.index++);
    if (c === "\n") {
      this.line += 1;
      this.last_column = this.column;
      this.column = 0;
    } else if (c === "/" && !ignore_comments) {
      if (this.input.charAt(this.index) === "/") {
        while (true) {
          c = this.input.charAt(this.index++);
          if (c === "\n" || this.index >= this.input.length) {
            break;
          }
        }
        this.line += 1;
        this.last_column = this.column;
        this.column = 0;
        return this.nextChar();
      } else if (this.input.charAt(this.index) === "*") {
        endseq = 0;
        while (true) {
          c = this.input.charAt(this.index++);
          if (c === "\n") {
            this.line += 1;
            this.last_column = this.column;
            this.column = 0;
            endseq = 0;
          } else if (c === "*") {
            endseq = 1;
          } else if (c === "/" && endseq === 1) {
            break;
          } else {
            endseq = 0;
          }
          if (this.index >= this.input.length) {
            break;
          }
        }
        return this.nextChar();
      }
    } else {
      this.column += 1;
    }
    return c;
  }

  rewind() {
    this.index -= 1;
    this.column -= 1;
    if (this.input.charAt(this.index) === "\n") {
      this.line -= 1;
      return this.column = this.last_column;
    }
  }

  next() {
    var c, code;
    if (this.buffer.length > 0) {
      return this.buffer.splice(0, 1)[0];
    }
    while (true) {
      if (this.index >= this.input.length) {
        return null;
      }
      c = this.nextChar();
      code = c.charCodeAt(0);
      if (code > 32 && code !== 160) {
        break;
      }
    }
    this.token_start = this.index - 1;
    if (this.doubles[c] != null) {
      return this.parseDouble(c, this.doubles[c]);
    }
    if (this.chars[c] != null) {
      return new Token(this, this.chars[c], c);
    }
    if (c === "!") {
      return this.parseUnequals(c);
    } else if (code >= 48 && code <= 57) {
      return this.parseNumber(c);
    } else if ((code >= 65 && code <= 90) || (code >= 97 && code <= 122) || code === 95 || this.letter_regex.test(c)) {
      return this.parseIdentifier(c);
    } else if (c === '"') {
      return this.parseString(c, '"');
    } else if (c === "'") {
      return this.parseString(c, "'");
    } else {
      return this.error("Syntax Error");
    }
  }

  changeNumberToIdentifier() {
    var i, j, ref, results, token, v;
    token = this.next();
    if ((token != null) && token.type === Token.TYPE_NUMBER) {
      v = token.string_value.split(".");
      results = [];
      for (i = j = ref = v.length - 1; j >= 0; i = j += -1) {
        if (v[i].length > 0) {
          this.pushBack(new Token(this, Token.TYPE_IDENTIFIER, v[i]));
        }
        if (i > 0) {
          results.push(this.pushBack(new Token(this, Token.TYPE_DOT, ".")));
        } else {
          results.push(void 0);
        }
      }
      return results;
    } else if ((token != null) && token.type === Token.TYPE_STRING) {
      return this.pushBack(new Token(this, Token.TYPE_IDENTIFIER, token.value));
    } else {
      return this.pushBack(token);
    }
  }

  parseDouble(c, d) {
    if ((this.shifts[c] != null) && this.index < this.input.length && this.input.charAt(this.index) === c) {
      this.nextChar();
      return new Token(this, this.shifts[c], c + c);
    } else if (this.index < this.input.length && this.input.charAt(this.index) === "=") {
      this.nextChar();
      return new Token(this, d[1], c + "=");
    } else {
      return new Token(this, d[0], c);
    }
  }

  parseEquals(c) {
    if (this.index < this.input.length && this.input.charAt(this.index) === "=") {
      this.nextChar();
      return new Token(this, Token.TYPE_DOUBLE_EQUALS, "==");
    } else {
      return new Token(this, Token.TYPE_EQUALS, "=");
    }
  }

  parseGreater(c) {
    if (this.index < this.input.length && this.input.charAt(this.index) === "=") {
      this.nextChar();
      return new Token(this, Token.TYPE_GREATER_OR_EQUALS, ">=");
    } else {
      return new Token(this, Token.TYPE_GREATER_OR_EQUALS, ">");
    }
  }

  parseLower(c) {
    if (this.index < this.input.length && this.input.charAt(this.index) === "=") {
      this.nextChar();
      return new Token(this, Token.TYPE_LOWER_OR_EQUALS, "<=");
    } else {
      return new Token(this, Token.TYPE_LOWER, "<");
    }
  }

  parseUnequals(c) {
    if (this.index < this.input.length && this.input.charAt(this.index) === "=") {
      this.nextChar();
      return new Token(this, Token.TYPE_UNEQUALS, "!=");
    } else {
      return this.error("Expected inequality !=");
    }
  }

  parseIdentifier(s) {
    var c, code;
    while (true) {
      if (this.index >= this.input.length) {
        return new Token(this, Token.TYPE_IDENTIFIER, s);
      }
      c = this.nextChar();
      code = c.charCodeAt(0);
      if ((code >= 65 && code <= 90) || (code >= 97 && code <= 122) || code === 95 || (code >= 48 && code <= 57) || this.letter_regex.test(c)) {
        s += c;
      } else {
        this.rewind();
        return new Token(this, Token.TYPE_IDENTIFIER, s);
      }
    }
  }

  parseNumber(s) {
    var c, code, exp, pointed;
    pointed = false;
    exp = false;
    while (true) {
      if (this.index >= this.input.length) {
        return new Token(this, Token.TYPE_NUMBER, Number.parseFloat(s), s);
      }
      c = this.nextChar();
      code = c.charCodeAt(0);
      if (c === "." && !pointed && !exp) {
        pointed = true;
        s += c;
      } else if (code >= 48 && code <= 57) {
        s += c;
      } else if ((c === "e" || c === "E") && !exp && this.index < this.input.length) {
        exp = true;
        s += c;
        c = this.nextChar();
        if (c === "+" || c === "-") {
          s += c;
        } else {
          this.rewind();
        }
      } else if ((c === "x" || c === "X") && s === "0") {
        return this.parseHexNumber("0x");
      } else {
        this.rewind();
        return new Token(this, Token.TYPE_NUMBER, Number.parseFloat(s), s);
      }
    }
  }

  parseHexNumber(s) {
    var c;
    while (true) {
      if (this.index >= this.input.length) {
        return new Token(this, Token.TYPE_NUMBER, Number.parseInt(s), s);
      }
      c = this.nextChar();
      if (/[a-fA-F0-9]/.test(c)) {
        s += c;
      } else {
        this.rewind();
        return new Token(this, Token.TYPE_NUMBER, Number.parseInt(s), s);
      }
    }
  }

  parseString(s, close = '"') {
    var c, code, count_close, n;
    if (close === '"') {
      if (this.input.charAt(this.index) === '"' && this.input.charAt(this.index + 1) === '"' && this.input.charAt(this.index + 2) !== '"') {
        close = '"""';
        this.nextChar(true);
        this.nextChar(true);
      }
    }
    count_close = 0;
    while (true) {
      if (this.index >= this.input.length) {
        return this.error("Unclosed string value");
      }
      c = this.nextChar(true);
      code = c.charCodeAt(0);
      if (c === "\\") {
        n = this.nextChar(true);
        switch (n) {
          case "n":
            s += "\n";
            break;
          case "\\":
            s += "\\";
            break;
          case close:
            s += close;
            break;
          default:
            s += "\\" + n;
        }
      } else if (c === close) {
        n = this.nextChar(true);
        if (n === close) {
          s += c;
        } else {
          this.rewind();
          s += c;
          return new Token(this, Token.TYPE_STRING, s.substring(1, s.length - 1));
        }
      } else {
        if (close === '"""' && c === '"') {
          count_close += 1;
          if (count_close === 3) {
            return new Token(this, Token.TYPE_STRING, s.substring(1, s.length - 2));
          }
        } else {
          count_close = 0;
        }
        s += c;
      }
    }
  }

  error(s) {
    throw s;
  }

};


var Transpiler;

Transpiler = (function() {
  function Transpiler() {}

  Transpiler.prototype.transpile = function(r) {
    var i, j, l, op, ref, results;
    results = [];
    for (i = l = 0, ref = r.opcodes.length - 1; l <= ref; i = l += 1) {
      op = OPCODES[r.opcodes[i]];
      if (this.transpilable(op, r.arg1[i])) {
        j = i + 1;
        while (j < r.opcodes.length && r.removeable(j) && this.transpilable(OPCODES[r.opcodes[j]], r.arg1[j])) {
          j += 1;
        }
        j -= 1;
        if (j - i >= 2) {
          results.push(this.transpileSegment(r, i, j));
        } else {
          results.push(void 0);
        }
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  Transpiler.prototype.transpileSegment = function(r, i, j) {
    var comp, err, index, k, l, m, ref, ref1, ref2, ref3, s;
    this.vcount = 0;
    this.stack = new Stack();
    this.locals = {};
    this.variables = {};
    s = "f = function(stack,stack_index,locals,locals_offset,object,global) {\n";
    for (k = l = ref = i, ref1 = j; l <= ref1; k = l += 1) {
      console.info(OPCODES[r.opcodes[k]] + " " + r.arg1[k]);
      comp = this[OPCODES[r.opcodes[k]]](r.arg1[k]);
      if (comp) {
        s += comp + "\n";
      }
    }
    for (index in this.stack.touched) {
      if (this.stack.touched[index]) {
        if (index < 0) {
          s += "stack[stack_index-" + (Math.abs(index)) + "] = " + this.stack.stack[index] + " ;\n";
        } else if (index > 0) {
          s += "stack[stack_index+" + index + "] = " + this.stack.stack[index] + " ;\n";
        } else {
          s += "stack[stack_index] = " + this.stack.stack[index] + " ;\n";
        }
      }
    }
    if (this.stack.index < 0) {
      s += "stack_index -= " + (Math.abs(this.stack.index)) + " ;\n";
    } else if (this.stack.index > 0) {
      s += "stack_index += " + this.stack.index + " ;\n";
    }
    s += "return stack_index ;\n}";
    console.info(s);
    try {
      eval(s);
    } catch (error) {
      err = error;
      console.error(s);
      console.error(err);
    }
    r.opcodes[i] = 200;
    r.arg1[i] = f;
    for (k = m = ref2 = i + 1, ref3 = j; m <= ref3; k = m += 1) {
      r.remove(i + 1);
    }
  };

  Transpiler.prototype.createVariable = function() {
    return "v" + (this.vcount++);
  };

  Transpiler.prototype.transpilable = function(op, arg) {
    var ref;
    if (op === "LOAD_VALUE") {
      return (ref = typeof arg) === "string" || ref === "number";
    } else {
      return this[op] != null;
    }
  };

  Transpiler.prototype.LOAD_VALUE = function(arg) {
    if (typeof arg === "string") {
      this.stack.push(" \"" + (arg.replace(/"/g, "\\\"")) + "\" ");
    } else if (typeof arg === "number") {
      this.stack.push(arg + "");
    }
    return "";
  };

  Transpiler.prototype.LOAD_LOCAL = function(arg) {
    var v;
    v = this.createVariable();
    this.stack.push(v);
    return "let " + v + " = locals[locals_offset+" + arg + "] ; // LOAD_LOCAL";
  };

  Transpiler.prototype.LOAD_LOCAL_OBJECT = function(arg) {
    var res, v;
    if (this.locals[arg] != null) {
      v = this.locals[arg];
      this.stack.push(v);
      return "if (typeof " + v + " != \"object\") { " + v + " = locals[locals_offset+" + arg + "] = {} } ;";
    } else {
      v = this.createVariable();
      res = "let " + v + " = locals[locals_offset+" + arg + "] ;\nif (typeof " + v + " != \"object\") { " + v + " = locals[locals_offset+" + arg + "] = {} } ;";
      this.stack.push(v);
      this.locals[arg] = v;
      return res;
    }
  };

  Transpiler.prototype.STORE_LOCAL = function(arg) {
    var v;
    v = this.stack.get();
    return "locals[locals_offset+" + arg + "] = " + v + " ; // STORE_LOCAL";
  };

  Transpiler.prototype.POP = function() {
    this.stack.pop();
    return "";
  };

  Transpiler.prototype.CREATE_PROPERTY = function(arg) {
    var res;
    res = (this.stack.get(-2)) + "[" + (this.stack.get(-1)) + "] = " + (this.stack.get()) + " ;";
    this.stack.pop();
    this.stack.pop();
    return res;
  };

  Transpiler.prototype.LOAD_PROPERTY = function(arg) {
    var res, v;
    v = this.createVariable();
    res = "let " + v + " = " + (this.stack.get(-1)) + "[" + (this.stack.get()) + "] ; // LOAD_PROPERTY\nif (" + v + " == null) { " + v + " = 0 ; }";
    this.stack.pop();
    this.stack.pop();
    this.stack.push(v);
    return res;
  };

  Transpiler.prototype.LOAD_PROPERTY_ATOP = function(arg) {
    var res, v;
    v = this.createVariable();
    res = "let " + v + " = " + (this.stack.get(-1)) + "[" + (this.stack.get()) + "] ; // LOAD_PROPERTY_ATOP\nif (" + v + " == null) { " + v + " = 0 ; }";
    this.stack.push(v);
    return res;
  };

  Transpiler.prototype.NEW_OBJECT = function() {
    var v;
    v = this.createVariable();
    this.stack.push(v);
    return "let " + v + " = {} ;";
  };

  Transpiler.prototype.NEW_ARRAY = function() {
    var v;
    v = this.createVariable();
    this.stack.push(v);
    return "let " + v + " = [] ;";
  };

  Transpiler.prototype.MAKE_OBJECT = function() {
    var res, v;
    v = this.createVariable();
    res = "let " + v + " = " + (this.stack.get()) + " ;\nif (typeof " + v + " != \"object\") " + v + " = {} ; ";
    this.stack.pop();
    this.stack.push(v);
    return res;
  };

  Transpiler.prototype.STORE_VARIABLE = function(arg) {
    if (this.variables[arg] != null) {
      return this.variables[arg] + " = object[\"" + arg + "\"] = " + (this.stack.get()) + " ; // STORE_VARIABLE";
    } else {
      return "object[\"" + arg + "\"] = " + (this.stack.get()) + " ; // STORE_VARIABLE";
    }
  };

  Transpiler.prototype.STORE_PROPERTY = function(arg) {
    var res, v;
    v = this.createVariable();
    res = "let " + v + " = " + (this.stack.get(-2)) + "[" + (this.stack.get(-1)) + "] = " + (this.stack.get(0)) + " ; // STORE_PROPERTY";
    this.stack.pop();
    this.stack.pop();
    this.stack.pop();
    this.stack.push(v);
    return res;
  };

  return Transpiler;

})();

this.Stack = (function() {
  function Stack() {
    this.stack = ["stack[stack_index]"];
    this.index = 0;
    this.touched = {};
  }

  Stack.prototype.push = function(value) {
    this.stack[++this.index] = value;
    return this.touched[this.index] = true;
  };

  Stack.prototype.pop = function() {
    var res;
    if (this.index >= 0) {
      res = this.stack.splice(this.index, 1)[0];
    } else if (this.stack[this.index] != null) {
      res = this.stack[this.index];
    } else {
      res = "stack[stack_index-" + this.index + "]";
    }
    this.index -= 1;
    return res;
  };

  Stack.prototype.get = function(index) {
    var i;
    if (index == null) {
      index = 0;
    }
    i = this.index + index;
    if (i >= 0) {
      return this.stack[i];
    } else if (this.stack[i] != null) {
      return this.stack[i];
    } else {
      return "stack[stack_index-" + (-i) + "]";
    }
  };

  return Stack;

})();


var Random;

Random = (function() {
  function Random(_seed, hash) {
    this._seed = _seed != null ? _seed : Math.random();
    if (hash == null) {
      hash = true;
    }
    if (this._seed === 0) {
      this._seed = Math.random();
    }
    if (this._seed < 1) {
      this._seed *= 1 << 30;
    }
    this.a = 13971;
    this.b = 12345;
    this.size = 1 << 30;
    this.mask = this.size - 1;
    this.norm = 1 / this.size;
    if (hash) {
      this.nextSeed();
      this.nextSeed();
      this.nextSeed();
    }
  }

  Random.prototype.next = function() {
    this._seed = (this._seed * this.a + this.b) & this.mask;
    return this._seed * this.norm;
  };

  Random.prototype.nextInt = function(num) {
    return Math.floor(this.next() * num);
  };

  Random.prototype.nextSeed = function() {
    return this._seed = (this._seed * this.a + this.b) & this.mask;
  };

  Random.prototype.seed = function(_seed) {
    this._seed = _seed != null ? _seed : Math.random();
    if (this._seed < 1) {
      this._seed *= 1 << 30;
    }
    this.nextSeed();
    this.nextSeed();
    return this.nextSeed();
  };

  Random.prototype.clone = function(seed) {
    if (seed != null) {
      return new Random(seed);
    } else {
      seed = this._seed;
      return new Random(seed, false);
    }
  };

  return Random;

})();

this.MicroVM = class MicroVM {
  constructor(meta = {}, global = {}, namespace1 = "/microstudio", preserve_ls = false) {
    var ctx, err;
    this.namespace = namespace1;
    this.preserve_ls = preserve_ls;
    if (meta.print == null) {
      meta.print = (text) => {
        if (typeof text === "object" && (this.runner != null)) {
          text = this.runner.toString(text);
        }
        return console.info(text);
      };
    }
    Array.prototype.insert = function(e) {
      this.splice(0, 0, e);
      return e;
    };
    Array.prototype.insertAt = function(e, i) {
      if (i >= 0 && i < this.length) {
        this.splice(i, 0, e);
      } else {
        this.push(e);
      }
      return e;
    };
    Array.prototype.remove = function(i) {
      if (i >= 0 && i < this.length) {
        return this.splice(i, 1)[0];
      } else {
        return 0;
      }
    };
    Array.prototype.removeAt = function(i) {
      if (i >= 0 && i < this.length) {
        return this.splice(i, 1)[0];
      } else {
        return 0;
      }
    };
    Array.prototype.removeElement = function(e) {
      var index;
      index = this.indexOf(e);
      if (index >= 0) {
        return this.splice(index, 1)[0];
      } else {
        return 0;
      }
    };
    Array.prototype.contains = function(e) {
      if (this.indexOf(e) >= 0) {
        return 1;
      } else {
        return 0;
      }
    };
    meta.round = function(x) {
      return Math.round(x);
    };
    meta.floor = function(x) {
      return Math.floor(x);
    };
    meta.ceil = function(x) {
      return Math.ceil(x);
    };
    meta.abs = function(x) {
      return Math.abs(x);
    };
    meta.min = function(x, y) {
      return Math.min(x, y);
    };
    meta.max = function(x, y) {
      return Math.max(x, y);
    };
    meta.sqrt = function(x) {
      return Math.sqrt(x);
    };
    meta.pow = function(x, y) {
      return Math.pow(x, y);
    };
    meta.sin = function(x) {
      return Math.sin(x);
    };
    meta.cos = function(x) {
      return Math.cos(x);
    };
    meta.tan = function(x) {
      return Math.tan(x);
    };
    meta.acos = function(x) {
      return Math.acos(x);
    };
    meta.asin = function(x) {
      return Math.asin(x);
    };
    meta.atan = function(x) {
      return Math.atan(x);
    };
    meta.atan2 = function(y, x) {
      return Math.atan2(y, x);
    };
    meta.sind = function(x) {
      return Math.sin(x / 180 * Math.PI);
    };
    meta.cosd = function(x) {
      return Math.cos(x / 180 * Math.PI);
    };
    meta.tand = function(x) {
      return Math.tan(x / 180 * Math.PI);
    };
    meta.acosd = function(x) {
      return Math.acos(x) * 180 / Math.PI;
    };
    meta.asind = function(x) {
      return Math.asin(x) * 180 / Math.PI;
    };
    meta.atand = function(x) {
      return Math.atan(x) * 180 / Math.PI;
    };
    meta.atan2d = function(y, x) {
      return Math.atan2(y, x) * 180 / Math.PI;
    };
    meta.log = function(x) {
      return Math.log(x);
    };
    meta.exp = function(x) {
      return Math.exp(x);
    };
    meta.random = new Random(0);
    meta.PI = Math.PI;
    meta.true = 1;
    meta.false = 0;
    global.system = {
      time: Date.now,
      language: navigator.language,
      update_rate: 60,
      inputs: {
        keyboard: 1,
        mouse: 1,
        touch: "ontouchstart" in window ? 1 : 0,
        gamepad: 0
      },
      prompt: (text, callback) => {
        return setTimeout((() => {
          var args, result;
          global.mouse.pressed = 0;
          global.touch.touching = 0;
          result = window.prompt(text);
          if ((callback != null) && typeof callback === "function") {
            args = [(result != null ? 1 : 0), result];
            this.context.timeout = Date.now() + 1000;
            return callback.apply(null, args);
          }
        }), 0);
      },
      say: (text) => {
        return setTimeout((() => {
          return window.alert(text);
        }), 0);
      }
    };
    try {
      global.system.inputs.keyboard = window.matchMedia("(pointer:fine)").matches ? 1 : 0;
      global.system.inputs.mouse = window.matchMedia("(any-hover:none)").matches ? 0 : 1;
    } catch (error1) {
      err = error1;
    }
    this.storage_service = this.createStorageService();
    global.storage = this.storage_service.api;
    meta.global = global;
    this.context = {
      meta: meta,
      global: global,
      local: global,
      object: global,
      breakable: 0,
      continuable: 0,
      returnable: 0,
      stack_size: 0
    };
    ctx = this.context;
    Array.prototype.sortList = function(f) {
      var funk;
      if ((f != null) && f instanceof Program.Function) {
        funk = function(a, b) {
          return f.call(ctx, [a, b], true);
        };
      } else if ((f != null) && typeof f === "function") {
        funk = f;
      }
      return this.sort(funk);
    };
    this.clearWarnings();
    this.runner = new Runner(this);
  }

  clearWarnings() {
    return this.context.warnings = {
      using_undefined_variable: {},
      assigning_field_to_undefined: {},
      invoking_non_function: {},
      assigning_api_variable: {},
      assignment_as_condition: {}
    };
  }

  setMeta(key, value) {
    return this.context.meta[key] = value;
  }

  setGlobal(key, value) {
    return this.context.global[key] = value;
  }

  run(program, timeout = 3000, filename = "", callback) {
    var err, res;
    this.program = program;
    this.error_info = null;
    this.context.timeout = Date.now() + timeout;
    this.context.stack_size = 0;
    try {
      res = this.runner.run(this.program, filename, callback);
      this.storage_service.check();
      if (res != null) {
        return this.runner.toString(res);
      } else {
        return null;
      }
    } catch (error1) {
      err = error1;
      if ((err.type != null) && (err.line != null) && (err.error != null)) {
        this.error_info = err;
      } else if ((this.context.location != null) && (this.context.location.token != null)) {
        this.error_info = {
          error: this.context.location.token.error_text || err,
          file: filename,
          line: this.context.location.token.line,
          column: this.context.location.token.column
        };
        console.info(`Error at line: ${this.context.location.token.line} column: ${this.context.location.token.column}`);
      } else {
        this.error_info = {
          error: err,
          file: filename
        };
      }
      console.error(err);
      return this.storage_service.check();
    }
  }

  call(name, args = [], timeout = 3000) {
    var err, res;
    this.error_info = null;
    this.context.timeout = Date.now() + timeout;
    this.context.stack_size = 0;
    try {
      res = this.runner.call(name, args);
      this.storage_service.check();
      return res;
    } catch (error1) {
      err = error1;
      console.error(err);
      if ((this.context.location != null) && (this.context.location.token != null)) {
        this.error_info = {
          error: this.context.location.token.error_text || err,
          line: this.context.location.token.line,
          column: this.context.location.token.column,
          file: this.context.location.token.file
        };
      } else {
        this.error_info = {
          error: err
        };
      }
      if ((this.context.location != null) && (this.context.location.token != null)) {
        console.info(`Error at line: ${this.context.location.token.line} column: ${this.context.location.token.column}`);
      }
      return this.storage_service.check();
    }
  }

  createStorageService() {
    var err, error, ls, namespace, s, service, storage, write_storage;
    try {
      ls = window.localStorage;
    } catch (error1) {
      error = error1; // in incognito mode, embedded by an iframe, localStorage isn't available
      console.info("localStorage not available");
      return service = {
        api: {
          set: function() {},
          get: function() {
            return 0;
          }
        },
        check: function() {}
      };
    }
    if (!this.preserve_ls) {
      try {
        delete window.localStorage;
      } catch (error1) {
        err = error1;
      }
    }
    storage = {};
    write_storage = false;
    namespace = this.namespace;
    try {
      s = ls.getItem(`ms${namespace}`);
      if (s) {
        storage = JSON.parse(s);
      }
    } catch (error1) {
      err = error1;
    }
    return service = {
      api: {
        set: (name, value) => {
          value = this.storableObject(value);
          if ((name != null) && (value != null)) {
            storage[name] = value;
            write_storage = true;
          }
          return value;
        },
        get: (name) => {
          if (name != null) {
            if (storage[name] != null) {
              return storage[name];
            } else {
              return 0;
            }
          } else {
            return 0;
          }
        }
      },
      check: () => {
        if (write_storage) {
          write_storage = false;
          try {
            return ls.setItem(`ms${namespace}`, JSON.stringify(storage));
          } catch (error1) {
            err = error1;
          }
        }
      }
    };
  }

  storableObject(value) {
    var referenced;
    referenced = [this.context.global.screen, this.context.global.system, this.context.global.keyboard, this.context.global.audio, this.context.global.gamepad, this.context.global.touch, this.context.global.mouse, this.context.global.sprites, this.context.global.maps];
    return this.makeStorableObject(value, referenced);
  }

  makeStorableObject(value, referenced) {
    var i, j, key, len, res, v;
    if (value == null) {
      return value;
    }
    if (typeof value === "function" || ((typeof Program !== "undefined" && Program !== null) && value instanceof Program.Function) || ((typeof Routine !== "undefined" && Routine !== null) && value instanceof Routine)) {
      return void 0;
    } else if (typeof value === "object") {
      if (referenced.indexOf(value) >= 0) {
        return void 0;
      }
      referenced = referenced.slice();
      referenced.push(value);
      if (Array.isArray(value)) {
        res = [];
        for (i = j = 0, len = value.length; j < len; i = ++j) {
          v = value[i];
          v = this.makeStorableObject(v, referenced);
          if (v != null) {
            res[i] = v;
          }
        }
        return res;
      } else {
        res = {};
        for (key in value) {
          v = value[key];
          if (key === "class") {
            continue;
          }
          v = this.makeStorableObject(v, referenced);
          if (v != null) {
            res[key] = v;
          }
        }
        return res;
      }
    } else {
      return value;
    }
  }

};

this.Watcher = class Watcher {
  constructor(runtime) {
    this.runtime = runtime;
    this.vm = this.runtime.vm;
  }

  update() {
    if (this.watching_variables) {
      return this.step();
    }
  }

  watch(variables) {
    this.watching = true;
    this.watching_variables = variables;
    this.exclusion_list = [this.vm.context.global.screen, this.vm.context.global.system, this.vm.context.global.keyboard, this.vm.context.global.audio, this.vm.context.global.gamepad, this.vm.context.global.touch, this.vm.context.global.mouse, this.vm.context.global.sprites, this.vm.context.global.maps, this.vm.context.global.sounds, this.vm.context.global.music, this.vm.context.global.assets, this.vm.context.global.asset_manager, this.vm.context.global.fonts, this.vm.context.global.storage];
    if (this.vm.context.global.Function != null) {
      this.exclusion_list.push(this.vm.context.global.Function);
    }
    if (this.vm.context.global.String != null) {
      this.exclusion_list.push(this.vm.context.global.String);
    }
    if (this.vm.context.global.List != null) {
      this.exclusion_list.push(this.vm.context.global.List);
    }
    if (this.vm.context.global.Number != null) {
      this.exclusion_list.push(this.vm.context.global.Number);
    }
    if (this.vm.context.global.Object != null) {
      this.exclusion_list.push(this.vm.context.global.Object);
    }
    if (this.vm.context.global.Image != null) {
      this.exclusion_list.push(this.vm.context.global.Image);
    }
    if (this.vm.context.global.Sound != null) {
      this.exclusion_list.push(this.vm.context.global.Sound);
    }
    if (this.vm.context.global.Sprite != null) {
      this.exclusion_list.push(this.vm.context.global.Sprite);
    }
    if (this.vm.context.global.Map != null) {
      this.exclusion_list.push(this.vm.context.global.Map);
    }
    if (this.vm.context.global.random != null) {
      this.exclusion_list.push(this.vm.context.global.random);
    }
    if (this.vm.context.global.print != null) {
      this.exclusion_list.push(this.vm.context.global.print);
    }
    return this.step();
  }

  stop() {
    return this.watching = false;
  }

  step(variables = this.watching_variables) {
    var index, j, len, res, v, value, vs;
    if (!this.watching) {
      return;
    }
    res = {};
    for (j = 0, len = variables.length; j < len; j++) {
      v = variables[j];
      if (v === "global") {
        value = this.vm.context.global;
      } else {
        vs = v.split(".");
        value = this.vm.context.global;
        index = 0;
        while (index < vs.length && (value != null)) {
          value = value[vs[index++]];
        }
      }
      if ((value != null) && this.exclusion_list.indexOf(value) < 0) {
        res[v] = this.exploreValue(value, 1, 10);
      }
    }
    return this.runtime.listener.postMessage({
      name: "watch_update",
      data: res
    });
  }

  exploreValue(value, depth = 1, array_max = 10) {
    var i, j, key, len, res, v;
    if (value == null) {
      return {
        type: "number",
        value: 0
      };
    }
    if (typeof value === "function" || value instanceof Program.Function || (typeof Routine !== "undefined" && Routine !== null) && value instanceof Routine) {
      return {
        type: "function",
        value: ""
      };
    } else if (typeof value === "object") {
      if (Array.isArray(value)) {
        if (depth === 0) {
          return {
            type: "list",
            value: "",
            length: value.length
          };
        }
        res = [];
        for (i = j = 0, len = value.length; j < len; i = ++j) {
          v = value[i];
          if (i >= 100) {
            break;
          }
          if (this.exclusion_list.indexOf(v) < 0) {
            res[i] = this.exploreValue(v, depth - 1, array_max);
          }
        }
        return res;
      } else {
        if (depth === 0) {
          v = "";
          if (value.classname) {
            v = "class " + value.classname;
          }
          if ((value.class != null) && (value.class.classname != null)) {
            v = value.class.classname;
          }
          return {
            type: "object",
            value: v
          };
        }
        res = {};
        for (key in value) {
          v = value[key];
          if (this.exclusion_list.indexOf(v) < 0) {
            res[key] = this.exploreValue(v, depth - 1, array_max);
          }
        }
        return res;
      }
    } else if (typeof value === "string") {
      return {
        type: "string",
        value: value.length < 43 ? value : value.substring(0, 40) + "..."
      };
    } else if (typeof value === "number") {
      return {
        type: "number",
        value: isFinite(value) ? value : 0
      };
    } else if (typeof value === "boolean") {
      return {
        type: "number",
        value: value ? 1 : 0
      };
    } else {
      return {
        type: "unknown",
        value: value
      };
    }
  }

};

this.AssetManager = class AssetManager {
  constructor(runtime) {
    this.runtime = runtime;
    this.interface = {
      loadFont: (font) => {
        return this.loadFont(font);
      },
      loadModel: (path, scene, callback) => {
        return this.loadModel(path, scene, callback);
      },
      loadImage: (path, callback) => {
        return this.loadImage(path, callback);
      },
      loadJSON: (path, callback) => {
        return this.loadJSON(path, callback);
      },
      loadText: (path, callback) => {
        return this.loadText(path, callback);
      },
      loadCSV: (path, callback) => {
        return this.loadCSV(path, callback);
      },
      loadMarkdown: (path, callback) => {
        return this.loadMarkdown(path, callback);
      },
      wasmInstance: (path, callback) => {
        return this.wasmInstance(path, callback);
      }
    };
  }

  getInterface() {
    return this.interface;
  }

  loadFont(font) {
    var err, file, name, split;
    if (typeof font !== "string") {
      return;
    }
    file = font.replace(/\//g, "-");
    split = file.split("-");
    name = split[split.length - 1];
    try {
      font = new FontFace(name, `url(assets/${file}.ttf)`);
      return font.load().then(() => {
        return document.fonts.add(font);
      });
    } catch (error) {
      err = error;
      return console.error(err);
    }
  }

  loadModel(path, scene, callback) {
    var loader;
    if (typeof BABYLON === "undefined" || BABYLON === null) {
      return;
    }
    loader = {
      ready: 0
    };
    if (this.runtime.assets[path] != null) {
      path = this.runtime.assets[path].file;
    } else {
      path = path.replace(/\//g, "-");
      path += ".glb";
    }
    return BABYLON.SceneLoader.LoadAssetContainer("", `assets/${path}`, scene, (container) => {
      loader.container = container;
      loader.ready = 1;
      if (callback) {
        return callback(container);
      }
    });
  }

  loadImage(path, callback) {
    var img, loader;
    loader = {
      ready: 0
    };
    if (this.runtime.assets[path] != null) {
      path = this.runtime.assets[path].file;
    }
    img = new Image;
    img.src = `assets/${path}`;
    img.onload = () => {
      var i;
      i = new msImage(img);
      loader.image = i;
      loader.ready = 1;
      if (callback) {
        return callback(i);
      }
    };
    return loader;
  }

  loadJSON(path, callback) {
    var loader;
    path = path.replace(/\//g, "-");
    path = `assets/${path}.json`;
    loader = {
      ready: 0
    };
    fetch(path).then((result) => {
      return result.json().then((data) => {
        loader.data = data;
        loader.ready = 1;
        if (callback) {
          return callback(data);
        }
      });
    });
    return loader;
  }

  loadText(path, callback, ext = "txt") {
    var loader;
    path = path.replace(/\//g, "-");
    path = `assets/${path}.${ext}`;
    loader = {
      ready: 0
    };
    fetch(path).then((result) => {
      return result.text().then((text) => {
        loader.text = text;
        loader.ready = 1;
        if (callback) {
          return callback(text);
        }
      });
    });
    return loader;
  }

  loadCSV(path, callback) {
    return this.loadText(path, callback, "csv");
  }

  loadMarkdown(path, callback) {
    return this.loadText(path, callback, "md");
  }

  wasmInstance(path, callback) {
    var loader;
    path = path.replace(/\//g, "-");
    path = `assets/${path}.wasm`;
    loader = {
      ready: 0
    };
    fetch(path).then((response) => {
      return response.arrayBuffer().then((buffer) => {
        return WebAssembly.instantiate(buffer).then((result) => {
          loader.instance = result.instance;
          loader.ready = 1;
          if (callback) {
            return callback(loader.instance);
          }
        });
      });
    });
    return loader;
  }

};

var WebSocket;

WebSocket = require("ws");

this.MPServer = class MPServer {
  constructor() {
    var impl;
    impl = new MPServerImpl(this);
    this.send = function(data) {
      var err;
      try {
        impl.sendMessage(data);
        return "sent";
      } catch (error) {
        err = error;
        console.error(err);
        return err.toString();
      }
    };
    this.close = function() {
      var err;
      try {
        return impl.close();
      } catch (error) {
        err = error;
        return console.error(err);
      }
    };
    this.new_connections = [];
    this.active_connections = [];
    this.closed_connections = [];
    this.messages = [];
    player.runtime.addServer(impl);
  }

};

this.MPServerImpl = class MPServerImpl {
  constructor(_interface) {
    this.interface = _interface;
    this.interface.status = "starting";
    this.reconnect_delay = 1000;
    this.clients = {};
    this.clients_connected = [];
    this.clients_disconnected = {};
    this.client_id = 1;
    this.start();
  }

  start() {
    var err;
    try {
      this.server = new WebSocket.Server({
        port: server_port
      });
      return this.server.on("connection", (socket, request) => {
        return this.clientConnected(socket);
      });
    } catch (error) {
      err = error;
      return console.error(err);
    }
  }

  clientConnected(socket) {
    var client;
    client = new MPClient(this, socket, this.client_id);
    this.clients_connected.push(client);
    this.clients[this.client_id] = client;
    return this.client_id++;
  }

  clientMessage(msg) {
    var client;
    if (msg.client_id == null) {
      return;
    }
    client = this.clients[msg.client_id];
    if (client != null) {
      return client.message(msg.data);
    }
  }

  clientDisconnected(client) {
    delete this.clients[client.client_id];
    return this.clients_disconnected[client.client_id] = true;
  }

  sendMessage(data) {
    return this.send({
      name: "mp_server_message",
      data: data
    });
  }

  send(data) {
    return this.socket.send(JSON.stringify(data));
  }

  update() {
    var c, client, closed_connections, connection, i, id, j, k, l, len, len1, len2, m, messages, n, new_connections, ref, ref1, ref2, ref3, ref4;
    new_connections = [];
    closed_connections = [];
    for (i = j = ref = this.interface.active_connections.length - 1; j >= 0; i = j += -1) {
      c = this.interface.active_connections[i];
      if (this.clients_disconnected[c.id]) {
        this.interface.active_connections.splice(i, 1);
        closed_connections.push(c);
      }
    }
    ref1 = this.clients_connected;
    for (k = 0, len = ref1.length; k < len; k++) {
      c = ref1[k];
      new_connections.push(c.interface);
      this.interface.active_connections.push(c.interface);
    }
    this.interface.new_connections = new_connections;
    this.interface.closed_connections = closed_connections;
    this.clients_disconnected = {};
    this.clients_connected = [];
    ref2 = this.clients;
    for (id in ref2) {
      client = ref2[id];
      client.update();
    }
    messages = [];
    ref3 = this.interface.active_connections;
    for (l = 0, len1 = ref3.length; l < len1; l++) {
      connection = ref3[l];
      ref4 = connection.messages;
      for (n = 0, len2 = ref4.length; n < len2; n++) {
        m = ref4[n];
        messages.push(m);
      }
    }
    this.interface.messages = messages;
  }

  close() {
    return this.socket.close();
  }

};

this.MPClient = class MPClient {
  constructor(server, socket1, client_id) {
    this.server = server;
    this.socket = socket1;
    this.client_id = client_id;
    this.interface = {
      id: this.client_id,
      status: "connected",
      messages: [],
      send: (data) => {
        return this.sendMessage(data);
      },
      disconnect: () => {
        return this.disconnect();
      }
    };
    this.message_buffer = [];
    this.socket.onmessage = (msg) => {
      var err;
      try {
        // console.info msg.data
        msg = JSON.parse(msg.data);
        switch (msg.name) {
          case "mp_update":
            this.interface.status = "running";
            return player.runtime.timer();
          case "mp_client_connection":
            return this.clientConnected(msg);
          case "mp_client_message":
            return this.clientMessage(msg);
          case "mp_client_disconnected":
            return this.disconnected();
        }
      } catch (error) {
        err = error;
        return console.error(err);
      }
    };
    this.socket.onclose = () => {
      return this.server.clientDisconnected(this);
    };
  }

  clientConnected(msg) {}

  clientMessage(msg) {
    return this.message_buffer.push(msg.data);
  }

  sendMessage(data) {
    var err;
    try {
      return this.socket.send(JSON.stringify({
        name: "mp_server_message",
        data: data
      }));
    } catch (error) {
      err = error;
      return console.error(err);
    }
  }

  disconnect() {
    var err;
    try {
      return this.socket.close();
    } catch (error) {
      err = error;
      return console.error(err);
    }
  }

  message(msg) {
    return this.message_buffer.push(msg.data);
  }

  disconnected() {
    return this.interface.status = "disconnected";
  }

  update() {
    var j, len, m, messages, ref;
    messages = [];
    ref = this.message_buffer;
    for (j = 0, len = ref.length; j < len; j++) {
      m = ref[j];
      messages.push({
        connection: this.interface,
        data: m
      });
    }
    this.interface.messages = messages;
    return this.message_buffer = [];
  }

};

this.Runtime = class Runtime {
  constructor(url1, sources, resources, listener) {
    this.url = url1;
    this.sources = sources;
    this.resources = resources;
    this.listener = listener;
    this.sprites = {};
    this.maps = {};
    this.sounds = {};
    this.music = {};
    this.assets = {};
    this.asset_manager = new AssetManager(this);
    this.previous_init = null;
    this.report_errors = true;
    this.log = (text) => {
      return this.listener.log(text);
    };
    this.update_memory = {};
    this.servers = [];
  }

  addServer(server) {
    return this.servers.push(server);
  }

  updateSource(file, src, reinit = false) {
    var err, init;
    if (this.vm == null) {
      return false;
    }
    if (src === this.update_memory[file]) {
      return false;
    }
    this.update_memory[file] = src;
    try {
      this.vm.run(src, 3000, file);
      this.listener.postMessage({
        name: "compile_success",
        file: file
      });
      this.reportWarnings();
      if (this.vm.error_info != null) {
        err = this.vm.error_info;
        err.type = "init";
        err.file = file;
        this.listener.reportError(err);
        return false;
      }
      if (this.vm.runner.getFunctionSource != null) {
        init = this.vm.runner.getFunctionSource("serverInit");
        if ((init != null) && init !== this.previous_init && reinit) {
          this.previous_init = init;
          this.vm.call("serverInit");
          if (this.vm.error_info != null) {
            err = this.vm.error_info;
            err.type = "serverInit";
            this.listener.reportError(err);
          }
        }
      }
      return true;
    } catch (error) {
      err = error;
      if (this.report_errors) {
        console.error(err);
        err.file = file;
        this.listener.reportError(err);
        return false;
      }
    }
  }

  start() {
    var j, key, len, m, name, ref, ref1, value;
    if (window.ms_async_load) {
      this.startReady();
    }
    if (Array.isArray(this.resources.maps)) {
      ref = this.resources.maps;
      for (j = 0, len = ref.length; j < len; j++) {
        m = ref[j];
        name = m.file.split(".")[0].replace(/-/g, "/");
        this.maps[name] = LoadMap(this.url + `maps/${m.file}?v=${m.version}`, () => {
          return this.checkStartReady();
        });
        this.maps[name].name = name;
      }
    } else if (this.resources.maps != null) {
      if (window.player == null) {
        window.player = this.listener;
      }
      ref1 = this.resources.maps;
      for (key in ref1) {
        value = ref1[key];
        this.updateMap(key, 0, value);
      }
    }
    this.checkStartReady();
  }

  checkStartReady() {
    var count, key, ready, ref, value;
    count = 0;
    ready = 0;
    ref = this.maps;
    for (key in ref) {
      value = ref[key];
      count += 1;
      if (value.ready) {
        ready += 1;
      }
    }
    if (ready < count) {
      if (!window.ms_async_load) {
        return;
      }
    } else {
      if (window.ms_async_load && (this.vm != null)) {
        this.vm.context.global.system.loading = 100;
      }
    }
    if (!this.started) {
      return this.startReady();
    }
  }

  startReady() {
    var err, file, global, init, j, len, lib, meta, namespace, ref, ref1, src;
    this.started = true;
    meta = {
      print: (text) => {
        if ((typeof text === "object" || typeof text === "function") && (this.vm != null)) {
          text = this.vm.runner.toString(text);
        }
        return this.listener.log(text);
      }
    };
    global = {
      sprites: this.sprites,
      sounds: this.sounds,
      music: this.music,
      assets: this.assets,
      asset_manager: this.asset_manager.getInterface(),
      maps: this.maps,
      Map: MicroMap
    };
    ref = window.ms_libs;
    for (j = 0, len = ref.length; j < len; j++) {
      lib = ref[j];
      switch (lib) {
        case "matterjs":
          global.Matter = Matter;
          break;
        case "cannonjs":
          global.CANNON = CANNON;
      }
    }
    namespace = location.pathname + "[server]";
    this.vm = new MicroVM(meta, global, namespace, location.hash === "#transpiler");
    this.vm.context.global.Server = MPServer;
    this.vm.context.global.system.pause = () => {
      return this.listener.codePaused();
    };
    this.vm.context.global.system.exit = () => {
      return this.exit();
    };
    if (!window.ms_async_load) {
      this.vm.context.global.system.loading = 100;
    }
    this.vm.context.global.system.javascript = System.javascript;
    System.runtime = this;
    ref1 = this.sources;
    for (file in ref1) {
      src = ref1[file];
      this.updateSource(file, src, false);
    }
    if (this.vm.runner.getFunctionSource != null) {
      init = this.vm.runner.getFunctionSource("serverInit");
      if (init != null) {
        this.previous_init = init;
        this.vm.call("serverInit");
        if (this.vm.error_info != null) {
          err = this.vm.error_info;
          err.type = "serverInit";
          this.listener.reportError(err);
        }
      }
    } else {
      this.vm.call("serverInit");
      if (this.vm.error_info != null) {
        err = this.vm.error_info;
        err.type = "serverInit";
        this.listener.reportError(err);
      }
    }
    this.dt = 1000 / 60;
    this.last_time = Date.now();
    this.current_frame = 0;
    this.floating_frame = 0;
    this.clock_interval = setInterval((() => {
      return this.clock();
    }), 16);
    this.watcher = new Watcher(this);
    return this.listener.postMessage({
      name: "started"
    });
  }

  updateMaps() {
    var key, map, ref;
    ref = this.maps;
    for (key in ref) {
      map = ref[key];
      map.needs_update = true;
    }
  }

  runCommand(command, callback) {
    var err, res, warnings;
    try {
      warnings = this.vm.context.warnings;
      this.vm.clearWarnings();
      res = this.vm.run(command, void 0, void 0, callback);
      this.reportWarnings();
      this.vm.context.warnings = warnings;
      if (this.vm.error_info != null) {
        err = this.vm.error_info;
        err.type = "exec";
        this.listener.reportError(err);
      }
      this.watcher.update();
      if (callback == null) {
        return res;
      } else if (res != null) {
        callback(res);
      }
      return null;
    } catch (error) {
      err = error;
      return this.listener.reportError(err);
    }
  }

  projectFileUpdated(type, file, version, data, properties) {
    switch (type) {
      case "maps":
        return this.updateMap(file, version, data);
      case "ms":
        return this.updateCode(file, version, data);
    }
  }

  projectFileDeleted(type, file) {
    switch (type) {
      case "maps":
        return delete this.maps[file.substring(0, file.length - 5).replace(/-/g, "/")];
    }
  }

  projectOptionsUpdated(msg) {}

  updateMap(name, version, data) {
    var m, url;
    name = name.replace(/-/g, "/");
    if (data != null) {
      m = this.maps[name];
      if (m != null) {
        UpdateMap(m, data);
        return m.needs_update = true;
      } else {
        m = new MicroMap(1, 1, 1, 1);
        UpdateMap(m, data);
        this.maps[name] = m;
        return this.maps[name].name = name;
      }
    } else {
      url = this.url + `maps/${name}.json?v=${version}`;
      m = this.maps[name];
      if (m != null) {
        return m.loadFile(url);
      } else {
        this.maps[name] = LoadMap(url);
        return this.maps[name].name = name;
      }
    }
  }

  updateCode(name, version, data) {
    var req, url;
    if (data != null) {
      this.sources[name] = data;
      if ((this.vm != null) && data !== this.update_memory[name]) {
        this.vm.clearWarnings();
      }
      return this.updateSource(name, data, true);
    } else {
      url = this.url + `ms/${name}.ms?v=${version}`;
      req = new XMLHttpRequest();
      req.onreadystatechange = (event) => {
        if (req.readyState === XMLHttpRequest.DONE) {
          if (req.status === 200) {
            this.sources[name] = req.responseText;
            return this.updateSource(name, this.sources[name], true);
          }
        }
      };
      req.open("GET", url);
      return req.send();
    }
  }

  stop() {
    this.stopped = true;
    clearInterval(this.clock_interval);
    return this.audio.cancelBeeps();
  }

  stepForward() {
    if (this.stopped) {
      this.updateCall();
      if (this.vm.runner.tick != null) {
        this.vm.runner.tick();
      }
      return this.watcher.update();
    }
  }

  resume() {
    if (this.stopped) {
      this.stopped = false;
      return this.clock_interval = setInterval((() => {
        return this.clock();
      }), 16);
    }
  }

  clock() {
    return this.timer();
  }

  timer() {
    var ds, dt, fps, i, j, ref, time;
    if (this.stopped) {
      return;
    }
    time = Date.now();
    if (Math.abs(time - this.last_time) > 160) {
      this.last_time = time - 16;
    }
    dt = time - this.last_time;
    this.dt = this.dt * .9 + dt * .1;
    this.last_time = time;
    this.vm.context.global.system.fps = Math.round(fps = 1000 / this.dt);
    this.floating_frame += this.dt * 60 / 1000;
    ds = Math.min(10, Math.round(this.floating_frame - this.current_frame));
    for (i = j = 1, ref = ds; j <= ref; i = j += 1) {
      this.updateCall();
      if (this.vm.runner.tick != null) {
        this.vm.runner.tick();
      }
    }
    this.current_frame += ds;
    if (ds > 0) {
      return this.watcher.update();
    }
  }

  updateControls() {
    var j, len, ref, results, s;
    ref = this.servers;
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      s = ref[j];
      results.push(s.update());
    }
    return results;
  }

  updateCall() {
    var err;
    if (this.vm.runner.triggers_controls_update) {
      if (this.vm.runner.updateControls == null) {
        this.vm.runner.updateControls = () => {
          return this.updateControls();
        };
      }
    } else {
      this.updateControls();
    }
    try {
      this.vm.call("serverUpdate");
      this.reportWarnings();
      if (this.vm.error_info != null) {
        err = this.vm.error_info;
        err.type = "serverUpdate";
        return this.listener.reportError(err);
      }
    } catch (error) {
      err = error;
      if (this.report_errors) {
        return this.listener.reportError(err);
      }
    }
  }

  reportWarnings() {
    var key, ref, ref1, ref2, ref3, value;
    if (this.vm != null) {
      ref = this.vm.context.warnings.invoking_non_function;
      for (key in ref) {
        value = ref[key];
        if (!value.reported) {
          value.reported = true;
          this.listener.reportError({
            error: "",
            type: "non_function",
            expression: value.expression,
            line: value.line,
            column: value.column,
            file: value.file
          });
        }
      }
      ref1 = this.vm.context.warnings.using_undefined_variable;
      for (key in ref1) {
        value = ref1[key];
        if (!value.reported) {
          value.reported = true;
          this.listener.reportError({
            error: "",
            type: "undefined_variable",
            expression: value.expression,
            line: value.line,
            column: value.column,
            file: value.file
          });
        }
      }
      ref2 = this.vm.context.warnings.assigning_field_to_undefined;
      for (key in ref2) {
        value = ref2[key];
        if (!value.reported) {
          value.reported = true;
          this.listener.reportError({
            error: "",
            type: "assigning_undefined",
            expression: value.expression,
            line: value.line,
            column: value.column,
            file: value.file
          });
        }
      }
      ref3 = this.vm.context.warnings.assigning_api_variable;
      for (key in ref3) {
        value = ref3[key];
        if (!value.reported) {
          value.reported = true;
          this.listener.reportError({
            error: "",
            type: "assigning_api_variable",
            expression: value.expression,
            line: value.line,
            column: value.column,
            file: value.file
          });
        }
      }
    }
  }

  exit() {
    var err;
    this.stop();
    try {
      // microStudio embedded exit
      this.listener.exit();
    } catch (error) {
      err = error;
    }
    try {
      // TODO: Cordova exit, this might work
      if ((navigator.app != null) && (navigator.app.exitApp != null)) {
        navigator.app.exitApp();
      }
    } catch (error) {
      err = error;
    }
    try {
      // TODO: Electron exit, may already be covered by window.close()

      // Windowed mode exit
      return window.close();
    } catch (error) {
      err = error;
    }
  }

};

this.System = {
  javascript: function(s) {
    var err, f, res;
    try {
      f = eval(`res = function(global) { ${s} }`);
      res = f.call(player.runtime.vm.context.global, player.runtime.vm.context.global);
    } catch (error) {
      err = error;
      console.error(err);
    }
    if (res != null) {
      return res;
    } else {
      return 0;
    }
  }
};

this.Watcher = class Watcher {
  constructor(runtime) {
    this.runtime = runtime;
    this.vm = this.runtime.vm;
  }

  update() {
    if (this.watching_variables) {
      return this.step();
    }
  }

  watch(variables) {
    this.watching = true;
    this.watching_variables = variables;
    this.exclusion_list = [this.vm.context.global.screen, this.vm.context.global.system, this.vm.context.global.keyboard, this.vm.context.global.audio, this.vm.context.global.gamepad, this.vm.context.global.touch, this.vm.context.global.mouse, this.vm.context.global.sprites, this.vm.context.global.maps, this.vm.context.global.sounds, this.vm.context.global.music, this.vm.context.global.assets, this.vm.context.global.asset_manager, this.vm.context.global.fonts, this.vm.context.global.storage];
    if (this.vm.context.global.Function != null) {
      this.exclusion_list.push(this.vm.context.global.Function);
    }
    if (this.vm.context.global.String != null) {
      this.exclusion_list.push(this.vm.context.global.String);
    }
    if (this.vm.context.global.List != null) {
      this.exclusion_list.push(this.vm.context.global.List);
    }
    if (this.vm.context.global.Number != null) {
      this.exclusion_list.push(this.vm.context.global.Number);
    }
    if (this.vm.context.global.Object != null) {
      this.exclusion_list.push(this.vm.context.global.Object);
    }
    if (this.vm.context.global.Image != null) {
      this.exclusion_list.push(this.vm.context.global.Image);
    }
    if (this.vm.context.global.Sound != null) {
      this.exclusion_list.push(this.vm.context.global.Sound);
    }
    if (this.vm.context.global.Sprite != null) {
      this.exclusion_list.push(this.vm.context.global.Sprite);
    }
    if (this.vm.context.global.Map != null) {
      this.exclusion_list.push(this.vm.context.global.Map);
    }
    if (this.vm.context.global.random != null) {
      this.exclusion_list.push(this.vm.context.global.random);
    }
    if (this.vm.context.global.print != null) {
      this.exclusion_list.push(this.vm.context.global.print);
    }
    return this.step();
  }

  stop() {
    return this.watching = false;
  }

  step(variables = this.watching_variables) {
    var index, j, len, res, v, value, vs;
    if (!this.watching) {
      return;
    }
    res = {};
    for (j = 0, len = variables.length; j < len; j++) {
      v = variables[j];
      if (v === "global") {
        value = this.vm.context.global;
      } else {
        vs = v.split(".");
        value = this.vm.context.global;
        index = 0;
        while (index < vs.length && (value != null)) {
          value = value[vs[index++]];
        }
      }
      if ((value != null) && this.exclusion_list.indexOf(value) < 0) {
        res[v] = this.exploreValue(value, 1, 10);
      }
    }
    return this.runtime.listener.postMessage({
      name: "watch_update",
      data: res
    });
  }

  exploreValue(value, depth = 1, array_max = 10) {
    var i, j, key, len, res, v;
    if (value == null) {
      return {
        type: "number",
        value: 0
      };
    }
    if (typeof value === "function" || value instanceof Program.Function || (typeof Routine !== "undefined" && Routine !== null) && value instanceof Routine) {
      return {
        type: "function",
        value: ""
      };
    } else if (typeof value === "object") {
      if (Array.isArray(value)) {
        if (depth === 0) {
          return {
            type: "list",
            value: "",
            length: value.length
          };
        }
        res = [];
        for (i = j = 0, len = value.length; j < len; i = ++j) {
          v = value[i];
          if (i >= 100) {
            break;
          }
          if (this.exclusion_list.indexOf(v) < 0) {
            res[i] = this.exploreValue(v, depth - 1, array_max);
          }
        }
        return res;
      } else {
        if (depth === 0) {
          v = "";
          if (value.classname) {
            v = "class " + value.classname;
          }
          if ((value.class != null) && (value.class.classname != null)) {
            v = value.class.classname;
          }
          return {
            type: "object",
            value: v
          };
        }
        res = {};
        for (key in value) {
          v = value[key];
          if (this.exclusion_list.indexOf(v) < 0) {
            res[key] = this.exploreValue(v, depth - 1, array_max);
          }
        }
        return res;
      }
    } else if (typeof value === "string") {
      return {
        type: "string",
        value: value.length < 43 ? value : value.substring(0, 40) + "..."
      };
    } else if (typeof value === "number") {
      return {
        type: "number",
        value: isFinite(value) ? value : 0
      };
    } else if (typeof value === "boolean") {
      return {
        type: "number",
        value: value ? 1 : 0
      };
    } else {
      return {
        type: "unknown",
        value: value
      };
    }
  }

};

this.MicroMap = (function() {
  function MicroMap(width, height, block_width, block_height) {
    this.width = width;
    this.height = height;
    this.block_width = block_width;
    this.block_height = block_height;
    this.sprites = window.player.runtime.sprites;
    this.map = [];
    this.ready = true;
    this.clear();
  }

  MicroMap.prototype.clear = function() {
    var i, j, k, l, ref1, ref2;
    for (j = k = 0, ref1 = this.height - 1; k <= ref1; j = k += 1) {
      for (i = l = 0, ref2 = this.width - 1; l <= ref2; i = l += 1) {
        this.map[i + j * this.width] = null;
      }
    }
  };

  MicroMap.prototype.set = function(x, y, ref) {
    if (x >= 0 && x < this.width && y >= 0 && y < this.height) {
      if (typeof ref === "string") {
        ref = ref.replace(/\//g, "-");
      }
      this.map[x + y * this.width] = ref;
      return this.needs_update = true;
    }
  };

  MicroMap.prototype.get = function(x, y) {
    var c;
    if (x < 0 || y < 0 || x >= this.width || y >= this.height) {
      return 0;
    }
    c = this.map[x + y * this.width];
    if (typeof c === "string") {
      c = c.replace(/-/g, "/");
    }
    return c || 0;
  };

  MicroMap.prototype.getCanvas = function() {
    if ((this.canvas == null) || this.needs_update) {
      this.update();
    }
    return this.canvas;
  };

  MicroMap.prototype.draw = function(context, x, y, w, h) {
    var a, c, ctx, k, len, len1, ref1, time;
    if ((this.animated != null) && this.animated.length > 0) {
      time = Date.now();
      if ((this.buffer == null) || this.buffer.width !== this.block_width * this.width || this.buffer.height !== this.block_height * this.height) {
        console.info("creating buffer");
        this.buffer = document.createElement("canvas");
        this.buffer.width = this.block_width * this.width;
        this.buffer.height = this.block_height * this.height;
      }
      ctx = this.buffer.getContext("2d");
      ctx.clearRect(0, 0, this.buffer.width, this.buffer.height);
      ctx.drawImage(this.getCanvas(), 0, 0);
      ref1 = this.animated;
      for (k = 0, len1 = ref1.length; k < len1; k++) {
        a = ref1[k];
        len = a.sprite.frames.length;
        c = a.sprite.frames[Math.floor(time / 1000 * a.sprite.fps) % len].canvas;
        if (a.tx != null) {
          ctx.drawImage(c, a.tx, a.ty, this.block_width, this.block_height, a.x, a.y, this.block_width, this.block_height);
        } else {
          ctx.drawImage(c, a.x, a.y, this.block_width, this.block_height);
        }
      }
      context.drawImage(this.buffer, x, y, w, h);
    } else {
      context.drawImage(this.getCanvas(), x, y, w, h);
    }
  };

  MicroMap.prototype.update = function() {
    var a, c, context, i, index, j, k, l, ref1, ref2, s, sprite, tx, ty, xy;
    this.needs_update = false;
    if (this.canvas == null) {
      this.canvas = document.createElement("canvas");
    }
    if (this.canvas.width !== this.width * this.block_width || this.canvas.height !== this.height * this.block_height) {
      this.canvas.width = this.width * this.block_width;
      this.canvas.height = this.height * this.block_height;
    }
    context = this.canvas.getContext("2d");
    context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.animated = [];
    for (j = k = 0, ref1 = this.height - 1; k <= ref1; j = k += 1) {
      for (i = l = 0, ref2 = this.width - 1; l <= ref2; i = l += 1) {
        index = i + (this.height - 1 - j) * this.width;
        s = this.map[index];
        if ((s != null) && s.length > 0) {
          s = s.split(":");
          sprite = this.sprites[s[0]];
          if (sprite == null) {
            sprite = this.sprites[s[0].replace(/-/g, "/")];
          }
          if ((sprite != null) && (sprite.frames[0] != null)) {
            if (sprite.frames.length > 1) {
              a = {
                x: this.block_width * i,
                y: this.block_height * j,
                w: this.block_width,
                h: this.block_height,
                sprite: sprite
              };
              if (s[1] != null) {
                xy = s[1].split(",");
                a.tx = xy[0] * this.block_width;
                a.ty = xy[1] * this.block_height;
              }
              this.animated.push(a);
              continue;
            }
            if (s[1] != null) {
              xy = s[1].split(",");
              tx = xy[0] * this.block_width;
              ty = xy[1] * this.block_height;
              c = sprite.frames[0].canvas;
              if ((c != null) && c.width > 0 && c.height > 0) {
                context.drawImage(c, tx, ty, this.block_width, this.block_height, this.block_width * i, this.block_height * j, this.block_width, this.block_height);
              }
            } else {
              c = sprite.frames[0].canvas;
              if ((c != null) && c.width > 0 && c.height > 0) {
                context.drawImage(c, this.block_width * i, this.block_height * j);
              }
            }
          }
        }
      }
    }
  };

  MicroMap.prototype.loadFile = function(url) {
    var req;
    req = new XMLHttpRequest();
    req.onreadystatechange = (function(_this) {
      return function(event) {
        if (req.readyState === XMLHttpRequest.DONE) {
          if (req.status === 200) {
            _this.load(req.responseText, _this.sprites);
            return _this.update();
          }
        }
      };
    })(this);
    req.open("GET", url);
    return req.send();
  };

  MicroMap.prototype.load = function(data, sprites) {
    var i, j, k, l, ref1, ref2, s;
    data = JSON.parse(data);
    this.width = data.width;
    this.height = data.height;
    this.block_width = data.block_width;
    this.block_height = data.block_height;
    for (j = k = 0, ref1 = data.height - 1; k <= ref1; j = k += 1) {
      for (i = l = 0, ref2 = data.width - 1; l <= ref2; i = l += 1) {
        s = data.data[i + j * data.width];
        if (s > 0) {
          this.map[i + j * data.width] = data.sprites[s];
        } else {
          this.map[i + j * data.width] = null;
        }
      }
    }
  };

  MicroMap.prototype.clone = function() {
    var i, j, k, l, map, ref1, ref2;
    map = new MicroMap(this.width, this.height, this.block_width, this.block_height, this.sprites);
    for (j = k = 0, ref1 = this.height - 1; k <= ref1; j = k += 1) {
      for (i = l = 0, ref2 = this.width - 1; l <= ref2; i = l += 1) {
        map.map[i + j * this.width] = this.map[i + j * this.width];
      }
    }
    map.needs_update = true;
    return map;
  };

  MicroMap.prototype.copyFrom = function(map) {
    var i, j, k, l, ref1, ref2;
    this.width = map.width;
    this.height = map.height;
    this.block_width = map.block_width;
    this.block_height = map.block_height;
    for (j = k = 0, ref1 = this.height - 1; k <= ref1; j = k += 1) {
      for (i = l = 0, ref2 = this.width - 1; l <= ref2; i = l += 1) {
        this.map[i + j * this.width] = map.map[i + j * this.width];
      }
    }
    this.update();
    return this;
  };

  return MicroMap;

})();

this.LoadMap = function(url, loaded) {
  var map, req;
  map = new MicroMap(1, 1, 1, 1);
  map.ready = false;
  req = new XMLHttpRequest();
  req.onreadystatechange = (function(_this) {
    return function(event) {
      if (req.readyState === XMLHttpRequest.DONE) {
        map.ready = true;
        if (req.status === 200) {
          UpdateMap(map, req.responseText);
        }
        map.needs_update = true;
        if (loaded != null) {
          return loaded();
        }
      }
    };
  })(this);
  req.open("GET", url);
  req.send();
  return map;
};

this.UpdateMap = function(map, data) {
  var i, j, k, l, ref1, ref2, s;
  data = JSON.parse(data);
  map.width = data.width;
  map.height = data.height;
  map.block_width = data.block_width;
  map.block_height = data.block_height;
  for (j = k = 0, ref1 = data.height - 1; k <= ref1; j = k += 1) {
    for (i = l = 0, ref2 = data.width - 1; l <= ref2; i = l += 1) {
      s = data.data[i + j * data.width];
      if (s > 0) {
        map.map[i + j * data.width] = data.sprites[s];
      } else {
        map.map[i + j * data.width] = null;
      }
    }
  }
  map.needs_update = true;
  return map;
};

this.SaveMap = function(map) {
  var data, i, index, j, k, l, list, m, n, o, ref1, ref2, ref3, ref4, s, table;
  index = 1;
  list = [0];
  table = {};
  for (j = k = 0, ref1 = map.height - 1; k <= ref1; j = k += 1) {
    for (i = l = 0, ref2 = map.width - 1; l <= ref2; i = l += 1) {
      s = map.map[i + j * map.width];
      if ((s != null) && s.length > 0 && (table[s] == null)) {
        list.push(s);
        table[s] = index++;
      }
    }
  }
  m = [];
  for (j = n = 0, ref3 = map.height - 1; n <= ref3; j = n += 1) {
    for (i = o = 0, ref4 = map.width - 1; o <= ref4; i = o += 1) {
      s = map.map[i + j * map.width];
      m[i + j * map.width] = (s != null) && s.length > 0 ? table[s] : 0;
    }
  }
  data = {
    width: map.width,
    height: map.height,
    block_width: map.block_width,
    block_height: map.block_height,
    sprites: list,
    data: m
  };
  return JSON.stringify(data);
};

this.Watch = (function() {
  function Watch(app) {
    var fn, i, len, ref, t;
    this.app = app;
    this.runwindow = this.app.runwindow;
    this.runwindow.addMessageListener("watch_update", (function(_this) {
      return function(msg) {
        return _this.watchUpdate(msg);
      };
    })(this));
    this.types = ["number", "string", "function", "object", "list"];
    ref = this.types;
    fn = (function(_this) {
      return function(t) {
        _this["filtered_type_" + t] = false;
        return document.getElementById("debug-watch-type-" + t).addEventListener("click", function() {
          _this["filtered_type_" + t] = !_this["filtered_type_" + t];
          if (_this["filtered_type_" + t]) {
            document.getElementById("debug-watch-type-" + t).classList.add("filtered");
          } else {
            document.getElementById("debug-watch-type-" + t).classList.remove("filtered");
          }
          return _this.updateFilters();
        });
      };
    })(this);
    for (i = 0, len = ref.length; i < len; i++) {
      t = ref[i];
      fn(t);
    }
    document.getElementById("debug-watch-filter").addEventListener("input", (function(_this) {
      return function() {
        _this.text_filter = document.getElementById("debug-watch-filter").value;
        return _this.updateFilters();
      };
    })(this));
    this.reset();
    this.app.runwindow.addListener((function(_this) {
      return function(event) {
        return _this.runtimeEvent(event);
      };
    })(this));
  }

  Watch.prototype.reset = function() {
    this.watch_lines = {};
    this.watch_list = ["global"];
    this.text_filter = "";
    document.getElementById("debug-watch-filter").value = "";
    return document.getElementById("debug-watch-content").innerHTML = "";
  };

  Watch.prototype.start = function() {
    this.started = true;
    return this.runwindow.postMessage({
      name: "watch",
      list: this.watch_list
    });
  };

  Watch.prototype.stop = function() {
    this.started = false;
    return this.runwindow.postMessage({
      name: "stop_watching"
    });
  };

  Watch.prototype.addWatch = function(w) {
    console.info("adding watch: " + w);
    this.watch_list.push(w);
    this.watch_list_updated = true;
    return this.start();
  };

  Watch.prototype.removeWatch = function(w) {
    var index;
    console.info("removing watch: " + w);
    index = this.watch_list.indexOf(w);
    if (w.indexOf(".") > 0) {
      delete this.watch_lines[w];
    }
    if (index >= 0) {
      this.watch_list.splice(index, 1);
      return this.start();
    }
  };

  Watch.prototype.watchUpdate = function(msg) {
    var alive, data, e, key, ref, ref1, set_key, set_value, value;
    if (!this.started) {
      return;
    }
    data = msg.data;
    alive = {};
    for (set_key in data) {
      set_value = data[set_key];
      if (set_key !== "global") {
        if (this.watch_lines.hasOwnProperty(set_key)) {
          alive[set_key] = true;
          this.watch_lines[set_key].updateContents(set_value);
        }
      }
    }
    e = document.getElementById("debug-watch-content");
    ref = data.global;
    for (key in ref) {
      value = ref[key];
      if (this.watch_lines.hasOwnProperty(key)) {
        this.watch_lines[key].updateValue(value);
      } else {
        this.watch_lines[key] = new WatchLine(this, e, key, value);
      }
      alive[key] = true;
    }
    if (!this.watch_list_updated) {
      ref1 = this.watch_lines;
      for (key in ref1) {
        value = ref1[key];
        if (!alive[key]) {
          value.remove();
          e.removeChild(value.element);
          delete this.watch_lines[key];
        }
      }
    }
    this.watch_list_updated = false;
  };

  Watch.prototype.isFiltered = function(w) {
    var v;
    v = w.value;
    if (this["filtered_type_" + v.type]) {
      return true;
    }
    if ((this.text_filter != null) && this.text_filter.length > 0 && w.prefixed.indexOf(this.text_filter) < 0) {
      return true;
    }
    return false;
  };

  Watch.prototype.updateFilters = function() {
    var key, ref, results, value;
    ref = this.watch_lines;
    results = [];
    for (key in ref) {
      value = ref[key];
      results.push(value.filterUpdate());
    }
    return results;
  };

  Watch.prototype.runtimeEvent = function(event) {
    switch (event) {
      case "play":
      case "reload":
        return this.reset();
      case "started":
        if (!this.app.appui.debug_splitbar.closed2) {
          this.reset();
          return this.start();
        }
        break;
      case "exit":
        this.started = false;
        return this.reset();
    }
  };

  return Watch;

})();

this.WatchLine = (function() {
  function WatchLine(watch, parent_element, variable, value1, prefix) {
    this.watch = watch;
    this.parent_element = parent_element;
    this.variable = variable;
    this.value = value1;
    this.prefix = prefix;
    this.prefixed = this.prefix != null ? this.prefix + "." + this.variable : this.variable;
    this.element = document.createElement("div");
    this.element.classList.add("watch-line");
    this.element.innerHTML = "<div class=\"watch-line-name\"><i class=\"fa\"></i> " + this.variable + "</div>\n<div class=\"watch-line-value\">" + (this.textValue()) + "</div>";
    this.element.classList.add(this.value.type);
    this.parent_element.appendChild(this.element);
    this.element.querySelector(".watch-line-value").addEventListener("click", (function(_this) {
      return function() {
        return _this.editValue();
      };
    })(this));
    this.element.querySelector("i").addEventListener("click", (function(_this) {
      return function() {
        var ref;
        if ((ref = _this.value.type) === "object" || ref === "list") {
          if (!_this.open) {
            _this.open = true;
            _this.watch.addWatch(_this.prefixed);
            _this.watch.watch_lines[_this.prefixed] = _this;
            _this.element.classList.add("open");
            if (_this.content != null) {
              return _this.content.style.display = "block";
            }
          } else {
            _this.open = false;
            _this.watch.removeWatch(_this.prefixed);
            _this.element.classList.remove("open");
            _this.watch_lines = {};
            if (_this.content != null) {
              _this.element.removeChild(_this.content);
              return _this.content = null;
            }
          }
        }
      };
    })(this));
    this.hidden = false;
    this.filterUpdate();
    this.watch_lines = {};
  }

  WatchLine.prototype.remove = function() {
    this.watch.removeWatch(this.prefixed);
    this.watch_lines = {};
    if (this.content != null) {
      this.element.removeChild(this.content);
      this.content = null;
    }
    this.element.classList.remove("open");
    return this.open = false;
  };

  WatchLine.prototype.textValue = function() {
    switch (this.value.type) {
      case "string":
        return '"' + this.value.value + '"';
      case "function":
        return "function()";
      case "list":
        return "[list:" + this.value.length + "]";
      case "object":
        return this.value.value || "object .. end";
      default:
        return this.value.value;
    }
  };

  WatchLine.prototype.updateValue = function(value) {
    var ref;
    if (value.type !== this.value.type) {
      this.element.classList.remove(this.value.type);
      this.element.classList.add(value.type);
      this.value.type = value.type;
      if ((this.content != null) && ((ref = this.value.type) !== "object" && ref !== "list")) {
        this.remove();
      }
    }
    if (value.value !== this.value.value || value.length !== this.value.length) {
      this.value.value = value.value;
      this.value.length = value.length;
      return this.element.querySelector(".watch-line-value").innerText = this.textValue();
    }
  };

  WatchLine.prototype.updateContents = function(data) {
    var active, key, ref, results, value;
    if (!this.open) {
      return;
    }
    if (!this.content) {
      this.content = document.createElement("div");
      this.content.classList.add("watch-line-content");
      this.element.appendChild(this.content);
    }
    active = {};
    for (key in data) {
      value = data[key];
      if (this.watch_lines.hasOwnProperty(key)) {
        this.watch_lines[key].updateValue(value);
      } else {
        this.watch_lines[key] = new WatchLine(this.watch, this.content, key, value, this.prefixed);
      }
      active[key] = true;
    }
    ref = this.watch_lines;
    results = [];
    for (key in ref) {
      value = ref[key];
      if (!active[key]) {
        delete this.watch_lines[key];
        value.remove();
        if (this.content != null) {
          results.push(this.content.removeChild(value.element));
        } else {
          results.push(void 0);
        }
      } else {
        results.push(void 0);
      }
    }
    return results;
  };

  WatchLine.prototype.filterUpdate = function() {
    var key, ref, results, value;
    if (this.hidden !== this.watch.isFiltered(this)) {
      this.hidden = !this.hidden;
      this.element.style.display = this.hidden ? "none" : "block";
    }
    ref = this.watch_lines;
    results = [];
    for (key in ref) {
      value = ref[key];
      results.push(value.filterUpdate());
    }
    return results;
  };

  WatchLine.prototype.editValue = function() {
    var input;
    if (this.value.type === "number" || this.value.type === "string") {
      input = document.createElement("input");
      input.type = "text";
      input.value = this.value.value;
      this.element.appendChild(input);
      input.addEventListener("blur", (function(_this) {
        return function() {
          return _this.element.removeChild(input);
        };
      })(this));
      input.addEventListener("keydown", (function(_this) {
        return function(event) {
          var err;
          if (event.key === "Enter") {
            event.preventDefault();
            if (input.value !== _this.value.value) {
              try {
                if (_this.value.type === "number") {
                  if (isFinite(parseFloat(input.value))) {
                    _this.watch.app.runwindow.runCommand(_this.prefixed + " = " + input.value, function() {});
                  }
                } else if (_this.value.type === "string") {
                  _this.watch.app.runwindow.runCommand(_this.prefixed + " = \"" + input.value + "\" ", function() {});
                }
              } catch (error) {
                err = error;
                console.error(err);
              }
            }
            return input.blur();
          }
        };
      })(this));
      return input.focus();
    }
  };

  return WatchLine;

})();

this.Player = class Player {
  constructor(listener) {
    this.listener = listener;
    //src = document.getElementById("code").innerText
    this.source_count = 0;
    this.sources = {};
    this.resources = resources;
    this.request_id = 1;
    this.pending_requests = {};
    this.sources.main = server_code;
    // player = new Player() must return before the server is started
    // to ensure global.player is defined
    setTimeout((() => {
      return this.start();
    }), 1);
  }

  start() {
    this.runtime = new Runtime("", this.sources, resources, this);
    this.terminal = new Terminal(this);
    this.terminal.start();
    this.runtime.start();
    return setInterval((() => {
      return this.runtime.clock();
    }), 16);
  }

  runCommand(cmd) {}

  reportError(err) {
    return this.terminal.error(err);
  }

  log(text) {
    return this.terminal.echo(text);
  }

  exit() {}

  call(name, args) {
    if ((this.runtime != null) && (this.runtime.vm != null)) {
      return this.runtime.vm.call(name, args);
    }
  }

  setGlobal(name, value) {
    if ((this.runtime != null) && (this.runtime.vm != null)) {
      return this.runtime.vm.context.global[name] = value;
    }
  }

  exec(command, callback) {
    if (this.runtime != null) {
      return this.runtime.runCommand(command, callback);
    }
  }

  postMessage(message) {
    return console.info(JSON.stringify(message));
  }

};

this.Terminal = class Terminal {
  constructor(runwindow) {
    this.runwindow = runwindow;
  }

  start() {}

  validateLine(v) {}

  setTrailingCaret() {}

  echo(text, scroll = false, classname) {
    return console.info(text);
  }

  error(text, scroll = false) {
    return console.error(text);
  }

  clear() {}

};



for (const prop in this) {
  global[prop] = this[prop] ;
}

var fs = require("fs") ;
fs.readFile("./config.json",(err,data)=> {
  global.server_port = 3000 ;
  if (! err) {
    console.info("config.json loaded") ;
    try {
      var config = JSON.parse(data) ;
      global.server_port = config.port || 3000 ;
    } catch (err) {
      console.info("could not parse config file") ;
    }
  } else {
    console.info("could not read config file") ;
  }
  console.info( "starting with port set to: "+global.server_port ) ;
  start() ;
}) ;